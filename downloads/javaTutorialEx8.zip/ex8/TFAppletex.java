// <applet code="TFApplet" width=300 height=300></applet>
import java.awt.*;
import java.applet.*;

public class TFApplet extends Applet {
	Button button1;
	String s = "Press button";
	TextField tf;

	public void init(){
		button1 = new Button("Password");
		tf  = new TextField(20);
		tf.setText("Enter stuff here");
		
		add (button1);
		add(tf);
	}

	public void paint(Graphics g){
		// Draw the value stored in the variable s
		g.drawString(s,100,100);
	}










public boolean action(Event evt,Object arg){
	s = tf.getText();
	if (s.equals("test"))
		s = "hello";

	repaint();	
	return true;
}



















} 
