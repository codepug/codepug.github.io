#include "XUtility.h"

void drawString(char c[],int x, int y) {
  WinDrawChars (c, (Word)strlen(c), x, y);
}

void drawInt(int num, int x, int y){
	char ddate[15];
	char tmp[15];
	StrCopy(ddate,StrIToA(tmp,num));
	drawString(ddate, x, y);
}

void drawRect(int x, int y, int w, int h) {
	WinDrawLine(x,y,x+w,y); // htop
	WinDrawLine(x,y,x,y+h); // vleft
	WinDrawLine(x+w,y,x+w,y+h); // vright
	WinDrawLine(x+w,y+h,x,y+h);
}

void draw3DRect(int x, int y, int w, int h) {
	WinDrawLine(x,y,x+w,y); // htop
	WinDrawLine(x,y,x,y+h); // vleft
	WinDrawLine(x+w,y,x+w,y+h); // vright
	WinDrawLine(x+w,y+h,x,y+h);

	WinDrawGrayLine(x,y+h+1,x+w,y+h+1); // htop
	WinDrawGrayLine(x+w+1,y,x+w+1,y+h); // htop
}

//void repaint(){
//	paint();
//}

void clearScreen(){
	RectangleType r = {0,0,160,160};
	WinEraseRectangle(&r,0);
}

void clearScreenLower(){
	RectangleType r = {16,16,144,144};
	WinEraseRectangle(&r,0);
}