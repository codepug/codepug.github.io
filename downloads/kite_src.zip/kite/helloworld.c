#include <System/SysAll.h>
#include <UI/UIAll.h>
#include "helloworld_rcp.h"

// Global Variables
int objID;
	// Init()
	Boolean StartApplication(void) {
		reset();
  		//FrmGotoForm(MainForm);
  		FrmGotoForm(InitForm);

//		repaint();
  		return false;
   	} 

	// Destroy()
	void StopApplication(void) {
	  	FrmCloseAllForms();
	} 

	void repaint() {
		int i = 0;
		//draw3DRect(1,21,65,18);
		drawDice(30,65);
		drawDice(85,65);
	}

	int mouseUp(){
		repaint();
		return 0;
	}

	int mouseDown(SWord x, SWord y){
		return 0;
	}

	int mouseDrag(SWord x, SWord y){ 
		return 0;
	}

	void reset(){
	  	/* Seed the random function */
	  	SysRandom(TimGetSeconds());
	}

	int drawDice(int x, int y){
		int w = 30, 
		    h = 30,
		    z = 3;
		int roll;

		RectangleType r = {x,y-h/2,w+w/2,h+h/2};
		WinEraseRectangle(&r,0);
		
		WinDrawLine(x,y,x,y+h); // vright
		WinDrawLine(x,y,x+w,y); // vright
		WinDrawLine(x,y+h,x+w,y+h); // vright
		WinDrawLine(x+w,y,x+w,y+h); // vright
		
		WinDrawLine(x,y,x+w/z,y-h/z); // vright
		WinDrawLine(x+w/z,y-h/z,x+w+w/z,y-h/z); // vright
		WinDrawLine(x+w,y,x+w+w/z,y-h/z); // vright
		WinDrawLine(x+w,y+h,x+w+w/z,y+h-h/z); // vright
		WinDrawLine(x+w+w/z,y-h/z,x+w+w/z,y+h-h/z); // vright

		roll = SysRandom(0)%6+1;
		switch (roll){
			case 1:
				drawDot(x+w/2,y+h/2);
				break;
			case 2:
				drawDot(x+w-w/4,y+h/4);
				drawDot(x+w/4,y+h-h/4);
				break;
			case 3:
				drawDot(x+w/6,y+h/6);
				drawDot(x+w/2,y+h/2);
				drawDot(x+w-w/6,y+h-h/6);
				break;
			case 4:
				drawDot(x+w/5,y+h/5);
				drawDot(x+w-w/5,y+h/5);
				drawDot(x+w/5,y+h-h/5);
				drawDot(x+w-w/5,y+h-h/5);
				break;
			case 5:
				drawDot(x+w/6,y+h/6);
				drawDot(x+w-w/6,y+h/6);
				drawDot(x+w/2,y+h/2);
				drawDot(x+w-w/6,y+h-h/6);
				drawDot(x+w/6,y+h-h/6);
				break;
			case 6:
				drawDot(x+w/6,y+h/6);
				drawDot(x+w-w/6,y+h/6);
				drawDot(x+w/6,y+h-h/6);
				drawDot(x+w-w/6,y+h-h/6);
				drawDot(x+w/6,y+h/2);
				drawDot(x+w-w/6,y+h/2);

				break;
		}

	}

	int drawDot(int x, int y){
		WinDrawLine(x-1,y-1,x+1,y-1);
		WinDrawLine(x-2,y,x+2,y);
		WinDrawLine(x-2,y+1,x+2,y+1);
		WinDrawLine(x-1,y+2,x+1,y+2);
	}


// Event Handlers
	Boolean MainFormHandleEvent(EventPtr event) {
	  FormPtr frm;      
	  Boolean handled = false;
     	//  FrmDrawForm(frm);

	  switch (event->eType) {
	    	case frmOpenEvent:
	      	frm = FrmGetActiveForm();
		    	  FrmDrawForm(frm);
	      	handled = true;
			repaint();
	      	break;
		//case penUpEvent:
		//	mouseUp();
		//	break;
		//case penDownEvent:
		//		mouseDown(event->screenX,event->screenY);
		//	break;
		//case penMoveEvent:
		//	if (event->screenY > 20 && event->screenY < 155)
		//		if (event->screenX > 3 && event->screenX < 154)
		//			mouseDrag(event->screenX,event->screenY);
		//	break;
		case menuEvent:
			switch (event->data.menu.itemID){
				case 5002:
					//reset();
					//clearScreenLower();
					repaint();
					break;
				case 5001:
				frm = FrmInitForm(AboutForm);
				FrmDoDialog(frm);
				FrmDeleteForm(frm);
				break;
			}
			break;
		case ctlSelectEvent:
			objID = event->data.ctlSelect.controlID;
			if (objID == b_rollAgain){
				repaint();
			}
			break;
	  } // event->eType
	  return handled;
	} 

	Boolean InitFormHandleEvent(EventPtr event) {
	  FormPtr frm;      
	  Boolean handled = false;

	  switch (event->eType) {
	    	case frmOpenEvent:
	      	frm = FrmGetActiveForm();
		    	  FrmDrawForm(frm);
	      	handled = true;
	      	break;
		case menuEvent:
			switch (event->data.menu.itemID){
				case 5001:
				frm = FrmInitForm(AboutForm);
				FrmDoDialog(frm);
				FrmDeleteForm(frm);
				break;
			}
			break;
		case penDownEvent:
			//FrmGotoForm(MainForm);
		//		mouseDown(event->screenX,event->screenY);
			break;
	  } // event->eType
	  return handled;
	} 

	Boolean ApplicationHandleEvent(EventPtr event) {
  		FormPtr frm;
  		Int     formId;
  		Boolean handled = false;

  		if (event->eType == frmLoadEvent) {
  	  		// get the form ID number
    			formId = event->data.frmLoad.formID;
   
			// load the form (get it's pointer)
    			frm = FrmInitForm(formId);
    
			// make the form active
    			FrmSetActiveForm(frm);

			switch (formId) {
				case MainForm:
			      FrmSetEventHandler(frm, MainFormHandleEvent);
	      		//FrmDrawForm(frm);
				//repaint();
			      break;
				case InitForm:
			      FrmSetEventHandler(frm, InitFormHandleEvent);
				break;
			}
		  	handled = true;
		}
		return handled;
	} 


// Palm Main()
	DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
	  	EventType event;
		Word error;


	  	if (cmd == sysAppLaunchCmdNormalLaunch) 
    			if (0 == StartApplication()) {
	      		do {
	        			EvtGetEvent(&event, evtWaitForever);
		        		if (!SysHandleEvent(&event)) 
						if (!MenuHandleEvent(0,&event,&error))
					          	// Check if the form was changed
          						if (!ApplicationHandleEvent(&event))
            						// Handle events for the current form
						            FrmDispatchEvent(&event);

		      	} while (event.eType != appStopEvent);
			      //StopApplication();
    			}
		return 0;
	} 
