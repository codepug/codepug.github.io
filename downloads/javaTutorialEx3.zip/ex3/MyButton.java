//<applet code="MyButton" width=200 height=70></applet>
import java.awt.*;
import java.applet.*;

public class MyButton extends Applet {
	boolean b;
public void init(){
	setBackground(Color.yellow);
	b = false;	
}

public boolean mouseDown(Event evt, int x, int y){
	b = false;

	if (x > 10 && x < 180)
		if (y > 10 && y < 50)
			b = true;

	repaint();
	return true;
}
public void paint(Graphics g){
	g.setColor(Color.blue);
	g.fill3DRect(10,10,170,40,true);

	g.setColor(Color.white);
	if (!b) {
		g.drawString("Click here for a suprise.",25,30);
	} else {
		g.drawString("Surprise!",50,30);    
	}	
}
} // end class









