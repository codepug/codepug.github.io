// This code borrowed from online tutorial
//
//
//
#ifndef _MIDIHEADER
	#define _MIDIHEADER
	#include <mmsystem.h>


	extern int         PlayingMIDI ;

	void PlayMidi (HWND main_window_handle ,char *FileName);
	void StopMidi ();
	void UnloadMidi ();
#endif

//MCIDEVICEID gDeviceID = -1;
//int         Playing = 0;

MCIDEVICEID 		gDeviceID = -1;
int         		PlayingMIDI = 0;
extern HINSTANCE 	ThisInstance;

void PlayMidi (HWND main_window_handle ,char *FileName)
{
  char              PathName [2048];
  MCI_OPEN_PARMS    OpenStructure;
  MCI_PLAY_PARMS    PlayStructure;

  if (gDeviceID != -1) {
    mciSendCommand (gDeviceID, MCI_STOP, 0, 0);
    mciSendCommand (gDeviceID, MCI_CLOSE, 0, 0);
    gDeviceID = -1;
  }

  //Append full path to filename
  strcpy (PathName, FileName);

  OpenStructure.lpstrDeviceType = "sequencer";
  OpenStructure.lpstrElementName = PathName;
  mciSendCommand (0, MCI_OPEN, MCI_OPEN_TYPE | MCI_OPEN_ELEMENT, (DWORD)&OpenStructure);
  gDeviceID = OpenStructure.wDeviceID;

  PlayingMIDI = -1;

  PlayStructure.dwCallback = (DWORD)main_window_handle;
  mciSendCommand (gDeviceID, MCI_PLAY, MCI_NOTIFY, (DWORD)&PlayStructure);
}

void StopMidi ()
{
	if (gDeviceID != -1)
	{
    	mciSendCommand (gDeviceID, MCI_STOP, 0, 0);
    	mciSendCommand (gDeviceID, MCI_CLOSE, 0, 0);
    	gDeviceID = -1;
    	PlayingMIDI = 0;
  	}
}

void UnloadMidi ()
{
	if (gDeviceID != -1)
	{
    	mciSendCommand (gDeviceID, MCI_STOP, 0, 0);
    	mciSendCommand (gDeviceID, MCI_CLOSE, 0, 0);
		PlayingMIDI = 0;
  	}
}


