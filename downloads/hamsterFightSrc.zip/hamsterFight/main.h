/*<---------------------------------------------------------------------->*/
// Hamster Fight, vers. 2.0a
// Author: CodePug
// File(s) not authored: Midi.h, midi.c
// Website: www.codepug.com
// Last updated: 2/7/2003
// Compiler: Win32 LCC
// Java-like skeleton header file for double buffered game application
/*<---------------------------------------------------------------------->*/

#ifndef _MAIN_H				// If we haven't included this file
#define _MAIN_H				// Set a flag saying we included it

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include "hamster1res.h"
#include "xgraphics.h"
/*<---------------------------------------------------------------------->*/
HINSTANCE       hInst;			// Instance handle
HWND            hwndMain;		// Main window

HDC             h, g, temp;
RECT            screenSize;
int             GAMESPEED = 100;

void            init();
void            deinit();
void            paint();
void            GameLoop();
void keyDown(int key);
void keyUp(int key);
void mouseDown(int x, int y);
//////////// Method Prototypes ////////////////
//
HDC             getGraphics(HWND myHwnd);
BOOL            setScreenSize(int width, int height);
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);
void reset();
/*<---------------------------------------------------------------------->*/
static BOOL     InitApplication(void){
   WNDCLASS        wc;

   memset(&wc, 0, sizeof(WNDCLASS));
   wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
   wc.lpfnWndProc = (WNDPROC) MainWndProc;
   wc.hInstance = hInst;
   wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
   wc.lpszClassName = "hamster1WndClass";
   wc.lpszMenuName = MAKEINTRESOURCE(IDMAINMENU);
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDAPPLICON));
   if (!RegisterClass(&wc))
	  return 0;
   return 1;
}

/*<---------------------------------------------------------------------->*/
HWND            Createhamster1WndClassWnd(void){
   return CreateWindow("hamster1WndClass",
					   "Hamster Fight v1 by www.codepug.com",
					   WS_MINIMIZEBOX | WS_CLIPSIBLINGS |
					   WS_CLIPCHILDREN | WS_MAXIMIZEBOX | WS_CAPTION |
					   WS_BORDER | WS_SYSMENU | WS_THICKFRAME, 100, 100, 700,
					   440, NULL, NULL, hInst, NULL);
}

/*<---------------------------------------------------------------------->*/
// Add menu commands here
void            MainWndProc_OnCommand(HWND hwnd, int id, HWND hwndCtl,
									  UINT codeNotify){
   switch (id)  {
   	case IDM_OPEN:
		// Not in template
		reset();
		break;
	case IDM_ABOUT:
		MessageBox(hwnd,"Created by www.codepug.com, C.2002-2003","About Hamster Fight",MB_OK);
		break;
   case IDM_EXIT:
	  PostMessage(hwnd, WM_CLOSE, 0, 0);
	  break;
   }
}

/*<---------------------------------------------------------------------->*/
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam,
							 LPARAM lParam)
{
   switch (msg)
   {
/*@@3->@@*/
   case WM_KEYDOWN:
	   keyDown((int)wParam);
	   break;
   case WM_KEYUP:
	   keyUp((int)wParam);
	   break;
   case WM_LBUTTONDOWN:
	   mouseDown(LOWORD(lParam), HIWORD(lParam));
	   break;
   case WM_COMMAND:
	  HANDLE_WM_COMMAND(hwnd, wParam, lParam, MainWndProc_OnCommand);
	  break;
   case WM_DESTROY:
	  deinit();
	  PostQuitMessage(0);
	  break;
   default:
	  return DefWindowProc(hwnd, msg, wParam, lParam);
   }
/*@@3<-@@*/
   return 0;
}

/*@@2<-@@*/

/*<---------------------------------------------------------------------->*/
int WINAPI      WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
						LPSTR lpCmdLine, INT nCmdShow)
{
   MSG             msg;
   HANDLE          hAccelTable;

   hInst = hInstance;
   if (!InitApplication())
	  return 0;
   hAccelTable = LoadAccelerators(hInst, MAKEINTRESOURCE(IDACCEL));
   if ((hwndMain = Createhamster1WndClassWnd()) == (HWND) 0)
	  return 0;


   // Load double buffering graphics contexts for g, temp, and h
   getGraphics(hwndMain);

   // Call init method to load starting data
   init();
	ShowWindow(hwndMain, SW_SHOW);

   // Begin loop
   GameLoop();

   // ReleaseDC(hwndMain,h);
   return msg.wParam;
}

// Repeating action of game code here
void            GameLoop() {
   MSG             msg;
   PeekMessage(&msg, NULL, 0U, 0U, PM_NOREMOVE);

   while (msg.message != WM_QUIT) {
	  if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE)) {
		 // Process message
		 TranslateMessage(&msg);
		 DispatchMessage(&msg);
	  } else if (RenderNextFrame((int) GAMESPEED)) {
		 // Calculate the fps of our app
		 CalculateFrameRate((HWND) hwndMain);
		 paint();

		 // Update screen from offscreenImg
		 BitBlt(g,0,0,screenSize.right,screenSize.bottom,h,0,0,SRCCOPY);
	  }
   }	// end while
} // end GameLoop

HDC             getGraphics(HWND myHwnd){
   // Global dependencies
   // RECT screenSize;
   // HDC g, h, temp; // (screen, offscreen, & temp graphics)
   HBITMAP         hBitmap;

   // Get window size
   GetClientRect(myHwnd, &screenSize);

   g = GetDC(myHwnd);
   h = CreateCompatibleDC(g);
   temp = CreateCompatibleDC(g);

   // Standardize pixel PLAYERs for both screens
   SetMapMode(h, GetMapMode(g));
   SetMapMode(temp, GetMapMode(g));

   // Create DIB Sections for offscreenGraphics & paint to offscreen Graphics
   hBitmap = CreateCompatibleBitmap(g, screenSize.right, screenSize.bottom);

   SelectObject(h, hBitmap);

   // Cleanup
   DeleteObject(hBitmap);

   // Return offscreenGraphics h
   return h;
}

BOOL            setScreenSize(int width, int height) {
   screenSize.left = 0;
   screenSize.right = width;
   screenSize.top = 0;
   screenSize.bottom = height;
   SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, screenSize.right,
				screenSize.bottom, SWP_SHOWWINDOW);
   return TRUE;
}

#endif
