/*----------------------------------------------------->*/
// Hamster Fight, vers. 2.0a
// Author: CodePug
// Website: www.codepug.com
// Started: 9/12/2002
// Last updated: 2/7/2003
// Compiler: Win32 LCC
// Todo: animated sprite flipping, push back after hit, no jump when in air
/*<---------------------------------------------------------------------->*/
#include "hamster1res.h"
#include "main.h"
#include "midi.h"
#include "xsprite.h"

SPRITE player1Stand, player1Walk, player1Attack, player1Jump, player1Block,
	   player2Stand, player2Walk, player2Attack, player2Jump, player2Block,
	   background, backgroundStart, backgroundGameOver;

BOOL player1LeftKeyDown,
     player1RightKeyDown,
	 player1UpKeyDown,
	 player1DownKeyDown,
	 player1AttackKeyDown;

BOOL player2LeftKeyDown,
     player2RightKeyDown,
	 player2UpKeyDown,
	 player2DownKeyDown,
	 player2AttackKeyDown;

BOOL player1KeepFalling,
	 player2KeepFalling,
	 aiActive;

char player1AttackSnd[256],
     player2AttackSnd[256];

//0 Do nothing
//1 Move towards player
//2 Move away from player
//3 Jump
//4 Block
//5 Attack
int aiMoveMatrix[]={  1, 1, 5, 0, 1, 1,  3,  2, 2, 5, 5, 5, 4,  4,  4, 5, 5, 5, 0};
int	aiMoveRepeat[]={140,20,45,70,50,70,140,100,50,50,70,10,60,160,240,30,25,45,20};
int aiMax = 17;
int aiCurrent=0;
int aiRepeat=0;

int runLevel=-1;
int strikeDistance = 120;

void updatePosition();
void changeRunlevel(int r);
void keyDownRunLevelZero(int key);
void keyUpRunLevelZero(int key);
void aiMove();

void init(){
	// Setup paths for characterimages
	char player1StandImage[256]  = "res\\hamster\\standa.bmp";
	char player1WalkImage[256]   = "res\\hamster\\walka.bmp";
	char player1AttackImage[256] = "res\\hamster\\attack.bmp";
	char player1JumpImage[256]   = "res\\hamster\\jumpa.bmp";
	char player1BlockImage[256]  = "res\\hamster\\block.bmp";

	char player2StandImage[256]  = "res\\worm\\stand.bmp";
	char player2WalkImage[256]   = "res\\worm\\walk.bmp";
	char player2AttackImage[256] = "res\\worm\\attack.bmp";
	char player2JumpImage[256]   = "res\\worm\\jump.bmp";
	char player2BlockImage[256]  = "res\\worm\\block.bmp";

	char backgroundIntroImage[256]         = "res\\locations\\start.bmp";
	char backgroundImage[256]    = "res\\locations\\back.bmp";
	char backgroundGameOverImage[256] = "res\\locations\\gameover.bmp";

	strcpy(player1AttackSnd,"res\\hamster\\attack.wav");
	strcpy(player2AttackSnd,"res\\worm\\attack.wav");

	// Adjust screen size
	setScreenSize(700,440);

	transparentColor = RGB(0,0,0);
	GAMESPEED = 80;

	// Load sprite bitmaps
	player1Stand = createAnimatedSprite(player1StandImage,  TRUE,TRUE,2);
	player1Walk  = createAnimatedSprite(player1WalkImage,   TRUE,TRUE,2);
	player1Attack= createSprite(player1AttackImage,         TRUE,TRUE);
	player1Jump  = createAnimatedSprite(player1JumpImage,   TRUE,TRUE,3);
	player1Block = createSprite(player1BlockImage,          TRUE,TRUE);

	player2Stand = createSprite(player2StandImage,  TRUE,TRUE);
	player2Walk  = createSprite(player2WalkImage,   TRUE,TRUE);
	player2Attack= createSprite(player2AttackImage, TRUE,TRUE);
	player2Jump  = createSprite(player2JumpImage,   TRUE,TRUE);
	player2Block = createSprite(player2BlockImage,  TRUE,TRUE);

	background   =createSprite(backgroundImage,         FALSE,FALSE);
	backgroundStart = createSprite(backgroundIntroImage,FALSE,FALSE);
	backgroundGameOver = createSprite(backgroundGameOverImage,FALSE,FALSE);

	// Set sprite group names
	strcpy(player1Stand.groupName ,"player1");
	strcpy(player1Walk.groupName  ,"player1");
	strcpy(player1Attack.groupName,"player1");
	strcpy(player1Jump.groupName  ,"player1");
	strcpy(player1Block.groupName ,"player1");

	strcpy(player2Stand.groupName ,"player2");
	strcpy(player2Walk.groupName  ,"player2");
	strcpy(player2Attack.groupName,"player2");
	strcpy(player2Jump.groupName  ,"player2");
	strcpy(player2Block.groupName ,"player2");

	strcpy(background.groupName  ,    "location");
	strcpy(backgroundStart.groupName ,"location");
	strcpy(backgroundGameOver.groupName,"location");

	// Add all sprites to our array to be painted
	// First sprite added is on top like console.bmp from oringinal
	addSprite(&player1Stand);
	addSprite(&player1Walk);
	addSprite(&player1Attack);
	addSprite(&player1Jump);
	addSprite(&player1Block);

	addSprite(&player2Stand);
	addSprite(&player2Walk);
	addSprite(&player2Attack);
	addSprite(&player2Jump);
	addSprite(&player2Block);

	addSprite(&background);
	addSprite(&backgroundStart);
	addSprite(&backgroundGameOver);

	// Set autoupdate off
	player1Jump.loopAnimationFreezeWhenDone=TRUE;
	// Set keys and positions
	reset();
}

void deinit(){
	// Turn off background music
	StopMidi();
	UnloadMidi();

	// Give graphics context back to windows
	DeleteObject(h);
	ReleaseDC(hwndMain,g);
	DeleteObject(temp);
	DeleteObject(hFont);

}

// Double buffering automatic in this call
void paint(){

	if (runLevel == 0){
		if (aiActive)
			aiMove();
		updatePosition();
	}

	// Show updated sprites
	paintSprite(h,temp);

	if (runLevel < 0)
		return;

	if (runLevel == 1){
		if (player1Stand.hp > player2Stand.hp)
			drawString("Player1 Wins!",200,30,h);
		else
			drawString("Player2 Wins!",200,30,h);
		return;
	}

	// Draw Hitpoints
	Rectangle(h,104,328,104+player1Stand.hp,344);
	Rectangle(h,475,330,475+player2Stand.hp,346);

}

// Computer player artificial intelligence
void aiMove(){
	int tempInt;
//1 Move towards player
//2 Move away from player
//3 Jump
//4 Block
//5 Attack
//int aiMoveMatrix[]={0,0,0,0,1,1,4,3,2,2,5};
//int	aiMoveRepeat[]={10,30,75,100,50,70,20,50,40,120,10};
//int aiMax = 11;
	// Pick a new action
	if (aiRepeat <= 0){
		// Turn off old command
			keyUp(VK_J);
			keyUp(VK_M);
			keyUp(VK_K);
			keyUp(VK_I);
			keyUp(VK_CONTROL);

		tempInt = rand()%aiMax;
		if (tempInt < 0 || tempInt > aiMax-1)
			return;
		aiRepeat = aiMoveRepeat[tempInt];
		aiCurrent = aiMoveMatrix[tempInt];
		if (aiCurrent == 1){
			if (player1Stand.pos.x < player2Stand.pos.x)
				keyDown(VK_J);
			else
				keyDown(VK_K);
		}
		if (aiCurrent == 4)
			keyDown(VK_M);
		if (aiCurrent == 2)
			if (player1Stand.pos.x > player2Stand.pos.x)
				keyDown(VK_K);
			else
				keyDown(VK_J);

		if (aiCurrent == 3)
			keyDown(VK_I);
		if (aiCurrent == 5)
			keyDown(VK_CONTROL);
	}

	// One less time to do action
	aiRepeat--;

} // end aiMove

void updatePosition(){
	// Check to see if we need to flip players directions
	if (getPositionCenter(&player1Stand).x > getPositionCenter(&player2Stand).x) {
		flipGroup("player1",TRUE);
		flipGroup("player2",TRUE);
	} else {
		flipGroup("player1",FALSE);
		flipGroup("player2",FALSE);
	}

	if (player1RightKeyDown)
		moveSpriteGroup("player1",2,0);
	if (player1LeftKeyDown)
		moveSpriteGroup("player1",-2,0);

	if (player2RightKeyDown)
		moveSpriteGroup("player2",2,0);
	if (player2LeftKeyDown)
		moveSpriteGroup("player2",-2,0);

	// Move everyone back into bounds
	if (getPositionCenter(&player1Stand).x < 0)
		setPositionGroup("player1",-player1Stand.width/2,60);
	if (getPositionCenter(&player1Stand).x > screenSize.right)
		setPositionGroup("player1",screenSize.right-player1Stand.width/2,60);

	if (getPositionCenter(&player2Stand).x < 0)
		setPositionGroup("player2",-player2Stand.width/2,75);
	if (getPositionCenter(&player2Stand).x > screenSize.right)
		setPositionGroup("player2",screenSize.right-player2Stand.width/2,75);

	// Keep track of players jumping
	if (player1KeepFalling){
		// Add bounce
		if (player1Stand.pos.y > -40)
			moveSpriteGroup("player1",0,-4);
		else
			player1KeepFalling = FALSE;
	} else {
		// Add gravity
		if(player1Stand.pos.y < 60)
			moveSpriteGroup("player1",1,7);
		else
			setPositionGroup("player1",player1Stand.pos.x,60);
	}
	if (player2KeepFalling){
		// Add bounce
		if (player2Stand.pos.y > -40)
			moveSpriteGroup("player2",0,-4);
		else
			player2KeepFalling = FALSE;
	} else {
		// Add gravity
		if(player2Stand.pos.y < 75)
			moveSpriteGroup("player2",1,7);
		else
			setPositionGroup("player2",player2Stand.pos.x,75);
	}
	// End process jump key
}

void reset(){
	runLevel = -1;
	aiActive = TRUE;

	// Start or restart background music
	StopMidi();
	PlayMidi(hwndMain,"res\\locations\\background.mid");

	// Deactivate sprite groups and reactivate needed
	deactivateGroup("player1");
	deactivateGroup("player2");
	deactivateGroup("location");
	backgroundStart.isActive = TRUE;

	// Reset pressed keys
	player1LeftKeyDown   = FALSE;
	player1RightKeyDown  = FALSE;
	player1UpKeyDown     = FALSE;
	player1DownKeyDown   = FALSE;
	player1AttackKeyDown = FALSE;

	player2LeftKeyDown   = FALSE;
    player2RightKeyDown  = FALSE;
	player2UpKeyDown     = FALSE;
	player2DownKeyDown   = FALSE;
	player2AttackKeyDown = FALSE;

	// Restore player positions
	setPositionGroup("player1",0,-200);
	setPositionGroup("player2",400,-275);

	// Restore player health
	player1Stand.hp = 100;
	player2Stand.hp = 100;

	// Players aren't jumping
	player1KeepFalling = FALSE;
	player2KeepFalling = FALSE;
}

void mouseDown(int x, int y){
	if (runLevel < 0)
		changeRunlevel(0);

	if (runLevel == 1)
		changeRunlevel(-1);
}

void keyDownRunLevelZero(int key){
		// Player1 controls
	if (key == VK_LEFT){
		if (!player1LeftKeyDown){
			player1LeftKeyDown = TRUE;
			deactivateGroup("player1");
			player1Walk.isActive = TRUE;
		}
	}

	if (key == VK_RIGHT){
		if (!player1RightKeyDown){
			player1RightKeyDown = TRUE;
			deactivateGroup("player1");
			player1Walk.isActive = TRUE;
		}
	}

	if (key == VK_DOWN){
		if (!player1DownKeyDown){
			player1DownKeyDown = TRUE;
			deactivateGroup("player1");
			player1Block.isActive = TRUE;
		}
	}

	if (key == VK_UP){
		if (!player1UpKeyDown){
			player1UpKeyDown = TRUE;
			deactivateGroup("player1");
			player1Jump.isActive = TRUE;
			player1KeepFalling = TRUE;
		}
	}

	if (key == VK_SPACE){
		if (!player1AttackKeyDown){
			PlaySound(player1AttackSnd,NULL,SND_ASYNC);
			player1AttackKeyDown = TRUE;
			deactivateGroup("player1");
			player1Attack.isActive = TRUE;

//Player 1 attack
				// Check the absolute value from the middle of each player
				if (abs(getPositionCenter(&player2Stand).x -getPositionCenter(&player1Stand).x)<strikeDistance){
					player2Stand.hp -= 10;

					// Change current ai action
					aiRepeat = -1;
					// Check to see if player2 is alive
					if(player2Stand.hp <= 0){
						player2Stand.hp = 0;
						changeRunlevel(1);//RUNLEVEL_GAMEOVER;
					}
				}
		}
	}

	// Player2 controls
	if (key == VK_K){
		if (!player2RightKeyDown){
			player2RightKeyDown = TRUE;
			deactivateGroup("player2");
			player2Walk.isActive = TRUE;
		}
	}

	if (key == VK_J){
		if (!player2LeftKeyDown){
			player2LeftKeyDown = TRUE;
			deactivateGroup("player2");
			player2Walk.isActive = TRUE;
		}
	}

	if (key == VK_M){
		if (!player2DownKeyDown){
			player2DownKeyDown = TRUE;
			deactivateGroup("player2");
			player2Block.isActive = TRUE;
		}
	}

	if (key == VK_I){
		if (!player2UpKeyDown){
			player2UpKeyDown = TRUE;
			deactivateGroup("player2");
			player2Jump.isActive = TRUE;
			player2KeepFalling=TRUE;
		}
	}

	if (key == VK_CONTROL){
		if (!player2AttackKeyDown){
			PlaySound(player2AttackSnd,NULL,SND_ASYNC);
			player2AttackKeyDown = TRUE;
			deactivateGroup("player2");
			player2Attack.isActive = TRUE;

			// Player2 attack
			// Check the absolute value from the middle of each player
				if (abs(getPositionCenter(&player2Stand).x -getPositionCenter(&player1Stand).x)<strikeDistance){
					player1Stand.hp -= 10;
					// Check to see if player1 is alive
					if(player1Stand.hp <= 0){
						player1Stand.hp = 0;
						changeRunlevel(1);//RUNLEVEL_GAMEOVER;
					}
				}
		}
	}
} // end keyDownRunLevelZero()

void keyUpRunLevelZero(int key){
	// Player1 controls
	if (key == VK_LEFT){
		player1LeftKeyDown = FALSE;
		deactivateGroup("player1");
		player1Stand.isActive = TRUE;
	}
	if (key == VK_RIGHT){
		player1RightKeyDown = FALSE;
		deactivateGroup("player1");
		player1Stand.isActive = TRUE;
	}

	if (key == VK_DOWN){
		player1DownKeyDown = FALSE;
		deactivateGroup("player1");
		player1Stand.isActive = TRUE;
	}
	if (key == VK_UP){
		player1Jump.currentImagePosition = 0;
		//player1Jump.repeatFrameCount = 0;
		player1Jump.autoUpdateFrame = TRUE;
		player1UpKeyDown = FALSE;
		deactivateGroup("player1");
		player1Stand.isActive = TRUE;
	}

	if (key == VK_SPACE){
		player1AttackKeyDown = FALSE;
		deactivateGroup("player1");
		player1Stand.isActive = TRUE;
	}

	// Player2 controls
	// Move Right
	if (key == VK_K){
		player2RightKeyDown = FALSE;
		deactivateGroup("player2");
		player2Stand.isActive = TRUE;
	}

	// Move Left
	if (key == VK_J){
		player2LeftKeyDown = FALSE;
		deactivateGroup("player2");
		player2Stand.isActive = TRUE;
	}

	// Move Down
	if (key == VK_M){
		player2DownKeyDown = FALSE;
		deactivateGroup("player2");
		player2Stand.isActive = TRUE;
	}

	// Move Up
	if (key == VK_I){
		player2UpKeyDown = FALSE;
		deactivateGroup("player2");
		player2Stand.isActive = TRUE;
	}

    // Attack move
	if (key == VK_CONTROL){
		player2AttackKeyDown = FALSE;
		deactivateGroup("player2");
		player2Stand.isActive = TRUE;
	}
} // end keyUpRunLevelZero()

void keyDown(int key){
	if (runLevel < 0)
		return;
	if (runLevel == 0)
		keyDownRunLevelZero(key);

} // end keydown

/*-----------------------------------------------------------*/
void keyUp(int key){
	if (runLevel == 0)
		keyUpRunLevelZero(key);
} // end keyup

void changeRunlevel(int r){
	runLevel = r;
	if (r < 0)
		reset();

	if (r == 0){
		player1Stand.isActive = TRUE;
		player2Stand.isActive = TRUE;
		deactivateGroup("location");
		background.isActive = TRUE;
	}

	if (r == 1){
		deactivateGroup("player1");
		deactivateGroup("player2");
		deactivateGroup("location");
		backgroundGameOver.isActive = TRUE;
	}
}

