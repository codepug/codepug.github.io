//<applet code="Smiley" width=400 height=400></applet>
import java.awt.*;
import java.applet.*;

public class Smiley extends Applet {
	int a;
	int b;

public void init(){
	setBackground(Color.green);
	a=0;
	b=0;
}

public boolean mouseMove(Event evt, int x, int y){
	a=x-50;
	b=y-50;
	repaint();
	return true;	
}

public void paint(Graphics g){
	g.setColor(Color.red);
	g.drawRect(10,150,100,50);
	
	g.setColor(Color.yellow);
	g.fillOval(a,b,50,50);

	g.setColor(Color.black);
	g.drawOval(a,b,50,50);
	g.fillOval(a+11,b+10,9,9);
	g.fillOval(a+32,b+10,9,9);
	g.drawArc(a+11,b+10,30,30,190,160);
}

}