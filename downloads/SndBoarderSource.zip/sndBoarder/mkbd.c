/*@@ Wedit generated application. Written Fri May 17 09:24:40 2002
 @@header: c:\lcc\mkbdres.h
 @@resources: c:\lcc\mkbd.rc
 Do not edit outside the indicated areas */
/*<---------------------------------------------------------------------->*/
/*<---------------------------------------------------------------------->*/
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <mmsystem.h>
#include "mkbdres.h"
/*<---------------------------------------------------------------------->*/
HINSTANCE hInst;		// Instance handle
HWND hwndMain;		//Main window handle

LRESULT CALLBACK MainWndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam);
BOOL bob;
/*<---------------------------------------------------------------------->*/
/*@@0->@@*/
static BOOL InitApplication(void)
{
	WNDCLASS wc;

	memset(&wc,0,sizeof(WNDCLASS));
	wc.style = CS_HREDRAW|CS_VREDRAW |CS_DBLCLKS ;
	wc.lpfnWndProc = (WNDPROC)MainWndProc;
	wc.hInstance = hInst;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszClassName = "mkbdWndClass";
	wc.lpszMenuName = MAKEINTRESOURCE(IDMAINMENU);
	wc.hCursor = LoadCursor(NULL,IDC_ARROW);
	wc.hIcon = LoadIcon(hInst,MAKEINTRESOURCE(IDAPPLICON));
	if (!RegisterClass(&wc))
		return 0;
/*@@0<-@@*/
	// ---TODO--- Call module specific initialization routines here

	return 1;
}

/*<---------------------------------------------------------------------->*/
/*@@1->@@*/
HWND CreatemkbdWndClassWnd(void)
{
	return CreateWindow("mkbdWndClass","Sound Boarder",
		WS_MINIMIZEBOX|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|WS_MAXIMIZEBOX|WS_CAPTION|WS_BORDER|WS_SYSMENU|WS_THICKFRAME,
		243,111,220,219,
		NULL,
		NULL,
		hInst,
		NULL);
}
/*@@1<-@@*/
/*<---------------------------------------------------------------------->*/
/* --- The following code comes from c:\lcc\lib\wizard\defOnCmd.tpl. */
void MainWndProc_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	switch(id) {
		// ---TODO--- Add new menu commands here
		/*@@NEWCOMMANDS@@*/
		case IDM_EXIT:
		PostMessage(hwnd,WM_CLOSE,0,0);
		break;
	}
}

/*<---------------------------------------------------------------------->*/
/*@@2->@@*/
LRESULT CALLBACK MainWndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam)
{

	switch (msg) {
/*@@3->@@*/
case WM_KEYUP:
	bob = FALSE;
	break;
case WM_KEYDOWN:

		if (VK_RIGHT == (int)wParam){
			PlaySound("boom.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}
		if (VK_LEFT == (int)wParam){
			PlaySound("cymbal.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}
		if (VK_UP == (int)wParam){
			PlaySound("dodo.wav",NULL,SND_ASYNC);

			bob = TRUE;
		}
		if (VK_DOWN == (int)wParam){
			PlaySound("clap.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_NUMPAD0 == (int)wParam){
			PlaySound("s1.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_NUMPAD1 == (int)wParam){
			PlaySound("s2.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_NUMPAD2 == (int)wParam){
			PlaySound("s3.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_NUMPAD3 == (int)wParam){
			PlaySound("s4.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_NUMPAD4 == (int)wParam){
			PlaySound("tomtom.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_NUMPAD5 == (int)wParam){
			PlaySound("cowbell.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_NUMPAD6 == (int)wParam){
			PlaySound("boat.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_NUMPAD7 == (int)wParam){
			PlaySound("bullfrog.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_NUMPAD8 == (int)wParam){
			PlaySound("horn.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_NUMPAD9 == (int)wParam){
			PlaySound("quack.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_0 == (int)wParam){
			PlaySound("s1.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_1 == (int)wParam){
			PlaySound("s2.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_2 == (int)wParam){
			PlaySound("s3.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_3 == (int)wParam){
			PlaySound("s4.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_4 == (int)wParam){
			PlaySound("tomtom.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_5 == (int)wParam){
			PlaySound("cowbell.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_6 == (int)wParam){
			PlaySound("boat.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_7 == (int)wParam){
			PlaySound("bullfrog.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_8 == (int)wParam){
			PlaySound("horn.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_9 == (int)wParam){
			PlaySound("quack.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_P == (int)wParam){
			PlaySound("b.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_K == (int)wParam){
			PlaySound("hc.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

	if (VK_A == (int)wParam){
			PlaySound("c.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		if (VK_S == (int)wParam){
			PlaySound("d.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_D == (int)wParam){
			PlaySound("e.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_F == (int)wParam){
			PlaySound("f.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_G == (int)wParam){
			PlaySound("g.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_H == (int)wParam){
			PlaySound("a.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_J == (int)wParam){
			PlaySound("b.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}


		if (VK_K == (int)wParam){
			PlaySound("hc.wav",NULL,SND_ASYNC);
			bob = TRUE;
		}

		//break;
	case WM_TIMER:
		//if (LOWORD(wParam) == 57){
			if (bob)
			DrawBitmap(hwndMain,LoadBitmap(hInst,MAKEINTRESOURCE(IDBITMAPON)),0,0);
			else
			DrawBitmap(hwndMain,LoadBitmap(hInst,MAKEINTRESOURCE(IDBITMAPOFF)),0,0);

		//}
		break;
	case WM_COMMAND:
		HANDLE_WM_COMMAND(hwnd,wParam,lParam,MainWndProc_OnCommand);
		break;

	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hwnd,msg,wParam,lParam);
	}
/*@@3<-@@*/
	return 0;
}
/*@@2<-@@*/

/*<---------------------------------------------------------------------->*/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, INT nCmdShow)
{
	MSG msg;
	HANDLE hAccelTable;

	hInst = hInstance;
	if (!InitApplication())
		return 0;
	hAccelTable = LoadAccelerators(hInst,MAKEINTRESOURCE(IDACCEL));
	if ((hwndMain = CreatemkbdWndClassWnd()) == (HWND)0)
		return 0;
	bob = FALSE;
	ShowWindow(hwndMain,SW_SHOW);
	SetTimer(hwndMain,57,500,NULL);

	while (GetMessage(&msg,NULL,0,0)) {
		if (!TranslateAccelerator(msg.hwnd,hAccelTable,&msg)) {
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}
	return msg.wParam;
}


void
DrawBitmap ( HWND g,
             HBITMAP hBitmap,
             short xStart, short yStart )
{
	HDC hdc;
    BITMAP          bm;
    HDC             hdcMem;
    POINT           ptSize, ptOrg;

	hdc = GetDC(g);
    hdcMem = CreateCompatibleDC ( hdc );

    SelectObject ( hdcMem, hBitmap );
    SetMapMode ( hdcMem, GetMapMode ( hdc ) );

    GetObject ( hBitmap, sizeof(BITMAP), (LPSTR) &bm );
    ptSize.x = bm.bmWidth;
    ptSize.y = bm.bmHeight;
	//ptSize.x = 100;
	//ptSize.y = 100;
    DPtoLP ( hdc, &ptSize, 1 );

    ptOrg.x = 0;
    ptOrg.y = 0;
    DPtoLP ( hdcMem, &ptOrg, 1 );

    BitBlt ( hdc,
             xStart, yStart,
             ptSize.x, ptSize.y,
             hdcMem,
             ptOrg.x, ptOrg.y,
             SRCCOPY );

   DeleteDC ( hdcMem );
}

