#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <syslog.h>
#include <sys/stat.h>
#define ACTION_TEC_VERIZON
#ifdef ACTION_TEC_VERIZON //if not online, don't answer DNS error msg -- blame stupid Verizon CD
	#include	<sys/socket.h>	/* basic socket definitions */
	#include	<sys/ioctl.h>
	#include <net/if.h>
#endif

#ifdef ACTION_TEC_HURL_DEMO
int findip(char *ip);
int isLocalhost(char *hname);
#endif

#include "dproxy.h"
#include "dns_decode.h"
#include "cache.h"
#include "conf.h"
#include "dns_list.h"
#include "dns_construct.h"
#include "dns_io.h"
#ifdef ACTION_TEC_123
#include <syslog.h>
#define MAX_LMSG_LEN	255

int logger_act (const char *fmt, ...)
{
	static char tmp_text[MAX_LMSG_LEN];
	va_list ap;
    FILE *fp;

	va_start(ap, fmt);
	vsnprintf(tmp_text, MAX_LMSG_LEN-1, fmt, ap);
	tmp_text[MAX_LMSG_LEN-1] = 0;
	va_end(ap);

    fp = fopen ("/var/log/messages", "a+");
    if (fp) {
        fprintf (fp, "%s", tmp_text);
        fclose (fp);
    }
	return 0;
}
#endif ACTION_TEC


#ifdef ACTION_TEC
int is_dns_cache()
{
   struct stat stats;
   if(stat("/var/tmp/dns_cache", &stats) == 0)
       return 1;
   return 0;
}
#endif


#ifdef ACTION_TEC_VERIZON //if not online, don't answer DNS error msg -- blame stupid Verizon CD
struct interface {
	struct interface *next, *prev;
	char name[IFNAMSIZ];	/* interface name        */
	short type;			/* if type               */
	short flags;		/* various flags         */
	int metric;			/* routing metric        */
	int mtu;			/* MTU value             */
	int tx_queue_len;		/* transmit queue length */
	struct ifmap map;		/* hardware setup        */
	struct sockaddr addr;	/* IP address            */
	struct sockaddr dstaddr;	/* P-P IP address        */
	struct sockaddr broadaddr;	/* IP broadcast address  */
	struct sockaddr netmask;	/* IP network mask       */
	struct sockaddr ipxaddr_bb;	/* IPX network address   */
	struct sockaddr ipxaddr_sn;	/* IPX network address   */
	struct sockaddr ipxaddr_e3;	/* IPX network address   */
	struct sockaddr ipxaddr_e2;	/* IPX network address   */
	struct sockaddr ddpaddr;	/* Appletalk DDP address */
	struct sockaddr ecaddr;	/* Econet address        */
	int has_ip;
	int has_ipx_bb;
	int has_ipx_sn;
	int has_ipx_e3;
	int has_ipx_e2;
	int has_ax25;
	int has_ddp;
	int has_econet;
	char hwaddr[32];		/* HW address            */
	int statistics_valid;
//    struct user_net_device_stats stats;		/* statistics            */
	int keepalive;		/* keepalive value for SLIP */
	int outfill;		/* outfill value for SLIP */
};

//#define ACTION_TEC_KPRINTF
#include <fcntl.h>
#define LED_KPRINTF 8
int kprintf (const char *fmt, ...)
{
#ifdef ACTION_TEC_KPRINTF
    static char tmp_text[51];
	va_list ap;
    int fp;

    /* Open /dev/led file for LED Operation */
    fp = open("/dev/led", O_RDWR);

    if(!fp) {
        return -1;
    }


    memset (tmp_text, 0, sizeof (tmp_text));
	va_start(ap, fmt);
	vsnprintf(tmp_text, sizeof (tmp_text)-1, fmt, ap);
    ioctl(fp, LED_KPRINTF, &tmp_text);

    close(fp);
#else
    return 0;
#endif //KPRINTF
}

/* Fetch the interface configuration from the kernel. */
static int if_fetch(struct interface *ife)
{
	struct ifreq ifr;
	int fd;
	char *ifname = ife->name;


//#if HAVE_AFINET
	/* IPv4 address? */
//    fd = get_socket_for_af(AF_INET);
	fd = socket(AF_INET, SOCK_DGRAM, 0);

	if (fd >= 0) {
		strcpy(ifr.ifr_name, ifname);
		ifr.ifr_addr.sa_family = AF_INET;
		if (ioctl(fd, SIOCGIFADDR, &ifr) == 0) {
			ife->has_ip = 1;
			ife->addr = ifr.ifr_addr;
			strcpy(ifr.ifr_name, ifname);
			if (ioctl(fd, SIOCGIFDSTADDR, &ifr) < 0)
				memset(&ife->dstaddr, 0, sizeof(struct sockaddr));
			else
				ife->dstaddr = ifr.ifr_dstaddr;

			strcpy(ifr.ifr_name, ifname);
			if (ioctl(fd, SIOCGIFBRDADDR, &ifr) < 0)
				memset(&ife->broadaddr, 0, sizeof(struct sockaddr));
			else
				ife->broadaddr = ifr.ifr_broadaddr;

			strcpy(ifr.ifr_name, ifname);
			if (ioctl(fd, SIOCGIFNETMASK, &ifr) < 0)
				memset(&ife->netmask, 0, sizeof(struct sockaddr));
			else
				ife->netmask = ifr.ifr_netmask;
		} else
			ife->has_ip	= 0;
		memset(&ife->addr, 0, sizeof(struct sockaddr));
        close (fd);
	}
//#endif


	return 0;
}

#endif

/*****************************************************************************/
/*****************************************************************************/
int dns_main_quit;
int dns_sock;
fd_set rfds;
dns_request_t *dns_request_list;
struct stat conf_stat;
/*****************************************************************************/
int is_connected()
{
#ifdef ACTION_TEC_VERIZON //if not online, don't answer DNS error msg -- blame stupid Verizon CD
    struct interface ife;
    struct sockaddr *p;
debug("x: is connected now true");
return 1;
    strcpy(&ife.name[0],"ppp0");
    if_fetch(&ife);
    if ((ife.has_ip)&&(strncmp(ife.addr.sa_data,"10.64.64.64",strlen("10.64.64.64")))) {
        return 1;
    } else {
        strcpy(&ife.name[0],"nas0");
        if_fetch(&ife);
        if (ife.has_ip) {
            return 1;
        }
    }
    return 0;
#else

  FILE *fp;
  if(!config.ppp_detect)return 1;

  fp = fopen( config.ppp_device_file, "r" );
  if(!fp)return 0;
  fclose(fp);
  return 1;
#endif
}

#ifdef ACTION_TEC_DDM_WHITELIST
#define FILE_WHITELIST_DNS "/var/tmp/whitelist_dns"
int lookup_ddmwhitetable(char *name, char ip[BUF_SIZE])
{
  FILE *fp;
  char cachename[256],cacheip[256];
  char dsl_dom[256],dsl_ip[256];

  fp=fopen(FILE_WHITELIST_DNS,"r");

  if (fp==NULL)
    return 0;

  //check dslmodem
#ifdef ACTION_TEC_QWEST_06
  if (!strcmp (name,"home.domain.actdsltmp")) {
#else
  if (!strcmp (name,"dslmodem.domain_not_set.invalid")) {
#endif
    FILE *fptable;

    fptable = fopen("/var/tmp/whitelist_table","r");
    if (fptable) {
      memset(dsl_ip,0,256);
      fscanf(fptable,"%s\n",dsl_ip);
      fscanf(fptable,"%s\n",dsl_ip);
      strcpy(ip,dsl_ip);
      fclose(fptable);
      return 1;
    }
  }

  memset(dsl_dom,0,256);
  memset(dsl_ip,0,256);
  fscanf(fp,"%s %s\n",dsl_dom,dsl_ip);

  while (!feof(fp)) {
    memset(cachename,0,256);
    memset(cacheip,0,256);
    fscanf(fp,"%s %s\n",cachename,cacheip);
    if (strcmp(cachename,name)==0) {
      strcpy(ip,cacheip);
      fclose(fp);
      return 1;
    }
  }

  strcpy(ip,dsl_ip);

  fclose(fp);
  return 1;
  //return 2;
}
#endif //DDM_WHITELIST

/*****************************************************************************/
int dns_init()
{
  struct sockaddr_in sa;
  struct in_addr ip;

  /* Clear it out */
  memset((void *)&sa, 0, sizeof(sa));

  dns_sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

  /* Error */
  if( dns_sock < 0 ){
	 debug_perror("Could not create socket");
	 exit(1);
  }

  ip.s_addr = INADDR_ANY;
  sa.sin_family = AF_INET;
  memcpy((void *)&sa.sin_addr, (void *)&ip, sizeof(struct in_addr));
  sa.sin_port = htons(PORT);

  /* bind() the socket to the interface */
  if (bind(dns_sock, (struct sockaddr *)&sa, sizeof(struct sockaddr)) < 0){
	 debug_perror("dns_init: bind: Could not bind to port");
	 exit(1);
  }

  dns_main_quit = 0;

  FD_ZERO( &rfds );
  FD_SET( dns_sock, &rfds );

  dns_request_list = NULL;

  cache_purge( config.purge_time );

  return 1;
}
#ifdef ACTION_TEC_PARENTCONTROL
extern int is_logoned (struct in_addr src_addr);
#endif //ACTION_TEC_PARENTCONTROL

/*****************************************************************************/
#ifdef ACTION_TEC_PARENTCONTROL
void dns_handle_new_query(dns_request_t *m, int on_list)
#else
void dns_handle_new_query(dns_request_t *m)
#endif
{
  struct in_addr in;
  int retval = -1;

 //@Duy_test_dslmodem
#ifdef ACTION_TEC_PARENTCONTROL
  int logon_already = 0;
  int time_blocked = 0;
  int cat_blocked = 0;
  int cat = -1;
    //check if the src ip has logon or not
  logon_already = is_logoned (m->src_addr);
  time_blocked = is_time_blocked (inet_ntoa(m->src_addr));

#endif //ACTION_TEC_PARENTCONTROL

  if( m->message.question[0].type == A || m->message.question[0].type == AAA){
#ifdef ACTION_TEC_PARENTCONTROL
      if (logon_already) {
    /* standard query */

        //xuwei: the following
        //retval = 0, cat = -1:  should go get category
        //retval = 0, cat != -1: should go to real DNS
        //retval = 1:            category and IP ready; IP may be LAN ip if blocked
        cat = -1;
        retval = cache_lookup_cat( m->cname, m->ip );
        if(retval == 1){
            debug("Got cat %s\n", m->ip);
            cat = pdns_cat(m->ip);
            cat_blocked = pdns_blocked_cat(inet_ntoa(m->src_addr),cat);
            if(cat_blocked){
                debug("cat %i for %s blocked\n",cat,inet_ntoa(m->src_addr));
                //record the website as blocked
                write_log_pc (m->src_addr, m->cname, 1);

            }
            else{//real ip in cache?
                retval = cache_lookup_name( m->cname, m->ip );

                if(retval){
                    debug("cat %i for %s NOT blocked \n", cat, inet_ntoa (m->src_addr));
                    write_log_pc (m->src_addr, m->cname, 0);
                }
            }
        }
        //else: should go get category
    }
    else {//if not logon yet, set the dns to lan ip and redirect to logon page
//        kprintf ("----skip dns cache\n");
        retval = 1;
    }
#else //not PARENTCONTROL
#ifdef CUSTOME_HURL111
#ifdef ACTION_TEC_HURL_DEMO
        //kprintf("cname=%s",m->cname);
        {
          FILE *fp;
          fp=fopen("/var/tmp/testhurl","w");
          fprintf(fp,"canme=%s",m->cname);
          fclose(fp);
        }

        retval = cache_lookup_name( m->cname, m->ip );

        //kprintf("cname=%s ip=%s\n",m->cname,m->ip);

        if(findip(inet_ntoa (m->src_addr))==0){
            //retval = cache_lookup_name( m->cname, m->ip );
        }
        else if ((isLocalhost(m->cname))==1){

        }
        else
        /*if (strncmp(m->cname,"www.",4)!=0) {
            retval = cache_lookup_name( m->cname, m->ip );

        }
        else*/

#endif
		retval = hurl_cache_lookup_name( m->cname, m->ip );
#else	//not HURL_DEMO
#ifdef ACTION_TEC
#ifdef ACTION_TEC_QWEST_06
        if (!strcmp (m->cname, "clearcache.domain.actdsltmp")) {
            cache_purge (0);
            retval = cache_lookup_name( "home.domain.actdsltmp", m->ip );
        }
#else
	if (!strcmp (m->cname, "clearcache.domain.domain_not_set.invalid")) {
            cache_purge (0);
            retval = cache_lookup_name( "dslmodem.domain_not_set.invalid", m->ip );
        }
#endif
        else
#endif //ACTION_TEC
    retval = cache_lookup_name( m->cname, m->ip );
//#ifdef ACTION_TEC_NO_DNSCACHE //Verizon don't want dns cache, see the comments in cache.c
    if (!is_dns_cache())
    retval = 0;
//    kprintf ("=======force no cache\n");
//#endif //ACTION_TEC_NO_DNSCACHE
#ifdef ACTION_TEC
#ifdef ACTION_TEC_QWEST_06
       if ((strlen (m->cname) > strlen (".domain.actdsltmp")) &&
                  !strcmp (m->cname + strlen (m->cname) - strlen (".domain.actdsltmp"), ".domain.actdsltmp") &&
                  strcmp (m->cname, "home.domain.actdsltmp")) {
#else
	if ((strlen (m->cname) > strlen (".domain.domain_not_set.invalid")) && //for timeout of ".domain_not_set.invalid" patch
                  !strcmp (m->cname + strlen (m->cname) - strlen (".domain_not_set.invalid"), ".domain_not_set.invalid") &&
                  strcmp (m->cname, "dslmodem.domain_not_set.invalid")) {
#endif
            //syslog (LOG_INFO, "***-------change response\n");
            fprintf(stderr,"\nDrop DNS request for %s\n", m->cname);
            return;
        }
#ifdef ACTION_TEC_QWEST_06
if(strcmp(m->cname, "home.domain.actdsltmp") == 0)
#else
if( (strcmp(m->cname, "dslmodem.domain_not_set.invalid") == 0)  || (strncmp(m->cname, "dslmodem.", strlen("dslmodem.")) == 0) )
#endif
{
  //syslog (LOG_INFO, "***Looking up for (home) %s\n", m->cname);
  fprintf(stderr,"\n***Looking up for (home)\n");
  retval = cache_lookup_name( m->cname, m->ip );
}
#endif  //ACTION_TEC

#ifdef ACTION_TEC_DDM_WHITELIST
#ifdef ACTION_TEC_NO_DNSCACHE
#ifdef ACTION_TEC_QWEST_06
if(strcmp(m->cname, "home.domain.actdsltmp") == 0)
#else
if(strcmp(m->cname, "dslmodem.domain_not_set.invalid") == 0)
#endif
{
  retval = cache_lookup_name( m->cname, m->ip );
}
else
#endif
{
      char whitelist_ip[BUF_SIZE];
      int whitelist_ret;
      whitelist_ret = lookup_ddmwhitetable(m->cname,whitelist_ip);
      if (whitelist_ret==1){  //DDM enabled and find dom & ip
	strcpy(m->ip,whitelist_ip);
        retval=1;
      }
      else if (whitelist_ret==2) {  //DDM enable
        retval=0;  //NO DNSCACHE
      }
    }
#endif //DDM_WHITELIST

#endif
#endif //ACTION_TEC_PARENTCONTROL


  }else if( m->message.question[0].type == PTR ){
    /* reverse lookup */
    retval = cache_lookup_ip( m->ip, m->cname );
  }

  debug(".......... %s ---- %s\n", m->cname, m->ip );
retval = 1;
debug("x: return val %d\n",retval);
debug("x: isconnected %d\n",is_connected());
  switch( retval )
    {
    case 0:
      if( is_connected() ){
#ifdef ACTION_TEC_LIMITED_DNSCACHE
                  #define ALLOWED_CACHE_ENTRIES 5
                  static char new_query_count = 0;

                  if (++new_query_count > ALLOWED_CACHE_ENTRIES) {
                          cache_purge(0);
                          new_query_count = 0;
                  }
#endif

#ifdef ACTION_TEC_PARENTCONTROL //xuwei
        if(on_list == 0){
        //send request to DNS1
        debug("Adding to list-> id: %d\n", m->message.header.id);
        dns_request_list = dns_list_add( dns_request_list, m );
        debug("Sent Request To %s\n",config.name_server[0]);
        inet_aton( config.name_server[0], &in );
        dns_write_packet( dns_sock, in, PORT, m );
        //send request to PDNS
        if(cat == -1){
            debug("Sent Request To %s\n",config.name_server_pdns[0]);
            inet_aton( config.name_server_pdns[0], &in );
            dns_write_packet( dns_sock, in, PORT, m );
        }
        }
#else
        debug("Adding to list-> id: %d\n", m->message.header.id);
        dns_request_list = dns_list_add( dns_request_list, m );
        /*!!! relay the query untouched */

	inet_aton( config.name_server[0], &in );
	debug("Sent Request To %s\n",config.name_server[0]);
        dns_write_packet( dns_sock, in, PORT, m );
#endif
      }else{
#ifndef ACTION_TEC_VERIZON //if not online, don't answer DNS error msg -- blame stupid Verizon CD
        debug("Not connected **\n");
        dns_construct_error_reply(m);
        dns_write_packet( dns_sock, m->src_addr, m->src_port, m );
#endif
      }
      break;
    case 1:
#ifdef ACTION_TEC_PARENTCONTROL
      dns_construct_reply( m, logon_already, cat_blocked, time_blocked );
#else
      dns_construct_reply( m );
#endif //ACTION_TEC_PARENTCONTROL
      dns_write_packet( dns_sock, m->src_addr, m->src_port, m );
      debug("Cache hit\n");
#ifdef ACTION_TEC_PARENTCONTROL
      if(on_list){
          debug("remove list %x\n",m->message.header.id);
          dns_request_list = dns_list_remove( dns_request_list, m );
      }
#endif
      break;

    default:
      debug("Unknown query type: %d\n", m->message.question[0].type );
    }

}

/*
#ifdef ACTION_TEC_PARENTCONTROL
int process_cat(dns_request_t *m, dns_request_t *ptr, int cat)
{
    char ip2[BUF_SIZE];
    struct in_addr in;

    if(cache_lookup_name(m->cname, ip2) == 0){//no real IP yet
      //debug("No ip yet; Request To %s\n",config.name_server[0]);
      //inet_aton( config.name_server[0], &in );
      //dns_write_packet( dns_sock, in, PORT, ptr );
    }else if(cache_lookup_cat(m->cname, ip2) == 0){//no cat yet
      //debug("No cat yet; Request To %s\n",config.name_server_pdns[0]);
      //inet_aton( config.name_server_pdns[0], &in );
      //dns_write_packet( dns_sock, in, PORT, ptr );
    }else{ //cat and ip both ready

//      debug("cat and ip both ready; call dns_handle_new_query\n");
//      dns_handle_new_query(ptr);

      if(pdns_blocked_cat(inet_ntoa (ptr->src_addr),cat) == 1)
      {//blocked: reply with LAN IP

        debug("cat %i for %s blocked \n", cat,inet_ntoa (ptr->src_addr));

        //Change to LAN ip
        get_lanip(m->ip);

        // Update HURL index for ptr->src_addr -- redirection
        debug("check logon %s\n", inet_ntoa (ptr->src_addr));
        if(is_logoned (ptr->src_addr)){
            debug("%s logon already\n", inet_ntoa (ptr->src_addr));
            set_gotopage (inet_ntoa (ptr->src_addr), "pc_blocked.html");
        }

        //Reset numread according to original request.
        //m->numread = m->numread_req ;

        //record the website as blocked
        write_log_pc (ptr->src_addr, m->cname, 1);

      }else{//not blocked
        debug("cat %i for %s NOT blocked \n", cat,inet_ntoa (ptr->src_addr));
        //record the website as blocked
        write_log_pc (ptr->src_addr, m->cname, 0);
      }

//      debug("Replying with answer from %s\n", inet_ntoa( m->src_addr ));
//      dns_write_packet( dns_sock, ptr->src_addr, ptr->src_port, m );

      debug("Remove request %X\n",ptr);
      //remove from list and append to cache as normal
      dns_request_list = dns_list_remove( dns_request_list, ptr );

    }
    return 1;
}
#endif
*/

/*****************************************************************************/
void dns_handle_request(dns_request_t *m)
{
  dns_request_t *ptr = NULL;
#ifdef ACTION_TEC_PARENTCONTROL
  int cat;
  struct in_addr in;
#endif

  /* request may be a new query or a answer from the upstream server */
  ptr = dns_list_find_by_id( dns_request_list, m );
  if( ptr != NULL ){
    debug("Found query in list\n");
    /* message may be a response */
    if( m->message.header.flags.f.question == 1 ){
      if( m->message.header.flags.f.rcode == 0 ){ // lookup was succesful
#ifdef ACTION_TEC_PARENTCONTROL //xuwei
          cat = pdns_cat(m->ip); //returned response(ip) is actually category.
          debug("------ip=%s; cat=%i\n", m->ip, cat);

          if(cat == 0){//Real IP: as normal
            debug("Cache append: %s ----> %s\n", m->cname, m->ip );
            cache_name_append( m->cname, m->ip );
          }else{
            //append to /var/cache/dproxy_cat.cache
            debug("Append to dproxy_cat.cache \n");
            strcpy(config.cache_file,config_defaults.cache_file_cat);
            cache_name_append( m->cname, m->ip );
            strcpy(config.cache_file,config_defaults.cache_file);
          }

          dns_handle_new_query(ptr, 1);

#else
        dns_write_packet( dns_sock, ptr->src_addr, ptr->src_port, m );
        debug("Replying with answer from %s\n", inet_ntoa( m->src_addr ));
        dns_request_list = dns_list_remove( dns_request_list, ptr );
    	debug("Cache append: %s ----> %s\n", m->cname, m->ip );
	    cache_name_append( m->cname, m->ip );
#endif
      }
#ifdef ACTION_TEC_PARENTCONTROL
      else if( m->message.header.flags.f.rcode == 5 || m->message.header.flags.f.rcode == 3) //if "refused" response, append to cache 10.10.10.254.
          //This will speed the DNS processing speed considerably.
      {
          debug("Append to cat cache 10.10.10.254\n");
          strcpy(config.cache_file,config_defaults.cache_file_cat);
          cache_name_append(m->cname, PDNS_NORECORD);
          strcpy(config.cache_file,config_defaults.cache_file);
          dns_handle_new_query(ptr, 1);
      }
#endif
    /*if( m->message.header.flags.f.question == 1 ){
      dns_write_packet( dns_sock, ptr->src_addr, ptr->src_port, m );
      debug("Replying with answer from %s\n", inet_ntoa( m->src_addr ));
      dns_request_list = dns_list_remove( dns_request_list, ptr );
      if( m->message.header.flags.f.rcode == 0 ){ // lookup was succesful
	debug("Cache append: %s ----> %s\n", m->cname, m->ip );
	cache_name_append( m->cname, m->ip );
      }*/

    }else{
      debug("Duplicate query\n");
    }
  }else{
#ifdef ACTION_TEC
        static int firstpurge = 1;
        if (firstpurge) {//sometimes hosts has value after normal cache_purge
            firstpurge = 0;
            cache_purge( config.purge_time );
        }
#endif ACTION_TEC
#ifdef ACTION_TEC_PARENTCONTROL
    debug("call dns_handle_new_query\n");
    dns_handle_new_query(m , 0);
#else
    dns_handle_new_query(m);
#endif
  }

}
/*****************************************************************************/
int dns_main_loop()
{
  struct timeval tv;
  fd_set active_rfds;
  int retval;
  dns_request_t m;
  dns_request_t *ptr, *next;
//#ifdef ACTION_TEC_NO_DNSCACHE //keep the purge check time as before
  int purge_time = 5;
//#else
//int purge_time = config.purge_time / 60;
//#endif //ACTION_TEC_NO_DNSCACHE
  struct stat temp_stat;
#ifdef ACTION_TEC_PARENTCONTROL //xuwei
  char ip2[BUF_SIZE];
#endif
#ifdef ACTION_TEC
  int  dns2_is_zero = 0;
#endif

  int next_server_index = 0;
  struct in_addr in;

//  if (is_dns_cache())
//      purge_time = config.purge_time / 60;

  while( !dns_main_quit ){

    /* set the one second time out */
    tv.tv_sec = 1;
    tv.tv_usec = 0;

    /* now copy the main rfds in the active one as it gets modified by select*/
    active_rfds = rfds;

    retval = select( FD_SETSIZE, &active_rfds, NULL, NULL, &tv );

    if (retval){
      /* data is now available */
      dns_read_packet( dns_sock, &m );
      m.time_pending = 0;
      dns_handle_request( &m );
    }else{
      /* If resolv.conf has changed read it again*/
      if( !stat(config.config_file, &temp_stat))
      {
        if( conf_stat.st_ctime != temp_stat.st_ctime)
        {
          conf_load(config.config_file);
	  cache_purge (0);
          conf_stat = temp_stat;
          syslog (LOG_INFO, "config.name_server[0]=%s\n", config.name_server[0]);
#ifdef ACTION_TEC
          if (!strcmp (config.name_server[0], "0.0.0.0") ) {
              syslog (LOG_INFO, "Wrong dns server, reread\n");
              conf_stat.st_ctime--;
              dns2_is_zero = 0;
          }
          else if (dns2_is_zero)
                   dns2_is_zero = 0;
          else if (!strcmp (config.name_server[1], ""))
          {
                   conf_stat.st_ctime--;
                   syslog (LOG_INFO, "name server 2 is NULL, read one more time\n");
                   dns2_is_zero = 1;
          }
#endif //ACTION_TEC
        }
      }
      /* select time out */
      ptr = dns_request_list;
      while( ptr ){
	next = ptr->next;
	/* Resend query to a new nameserver if response
	 * has not been received from the current nameserver */

	ptr->time_pending++;
	if( ptr->time_pending > DNS_TIMEOUT ){
	  debug("Request timed out\n");
#ifdef ACTION_TEC
	  syslog( LOG_ERR, "DNS request timeout: all servers tried.");
#endif
	  /* send error back */
	  dns_construct_error_reply(ptr);
	  dns_write_packet( dns_sock, ptr->src_addr, ptr->src_port, ptr );
	  dns_request_list = dns_list_remove( dns_request_list, ptr );
	}

#ifdef ACTION_TEC_PARENTCONTROL //xuwei: PDNS
  debug("time_pending=%x\n", ptr->time_pending);
//  debug("pdns 1:%s;2:%s;3:%s;4:%s;5:%s\n",config.name_server_pdns[0],config.name_server_pdns[1],
//        config.name_server_pdns[2],config.name_server_pdns[3],config.name_server_pdns[4]);

  if(cache_lookup_cat( ptr->cname, ip2 )){
      debug("Got CAT already for %s\n", ptr->cname);
  }
  else
  {
	if( ( ptr->time_pending % DNS_SERVER_TIMEOUT == 0) &&
	    ( ptr->time_pending < DNS_TIMEOUT) )
	{
        /* Send a request to the next nameserver */
        next_server_index = ptr->time_pending/DNS_SERVER_TIMEOUT;

        /* If already the maximum number of supported servers have
	    been tried out then remove the request from the list and
	    send a response  back */
        if(next_server_index >= MAX_NAME_SERVER ||
        (config.name_server_pdns[next_server_index][0]  == '\0' ))
        {

	  	/* send error back */
		debug("All PDNS Servers Tried: No Response\n");
/*Two design options when PDNS failed to respond:*/
#if 0 //blocked
	  	dns_construct_error_reply(ptr);
	  	dns_write_packet( dns_sock, ptr->src_addr, ptr->src_port, ptr );
	  	dns_request_list = dns_list_remove( dns_request_list, ptr );
        debug("Sent a DNS error message to Client \n");
#else //go through
        strcpy(config.cache_file,config_defaults.cache_file_cat);
        cache_name_append( ptr->cname, PDNS_NORECORD );
        strcpy(config.cache_file,config_defaults.cache_file);
	  	dns_handle_new_query(ptr, 1);
#endif
        ptr = next;
        continue;

	    }
	    else
	    {
            /* Create the new server IP address and relay the query untouched */
            inet_aton( config.name_server_pdns[next_server_index], &in );
            /*!!!*/
            debug("Didn't get a response from last PDNS server\n");
            debug("Sending a new request to %s\n", config.name_server_pdns[next_server_index]);
            /* Send the new request to the next name server */
            dns_write_packet( dns_sock, in, PORT, ptr );
	    }
	}
  }
#endif

#ifdef ACTION_TEC_PARENTCONTROL
    if(cache_lookup_name( ptr->cname, ip2 )){
        debug("Got IP already for %s\n", ptr->cname);
    }
    else
    {
#endif
	if( ( ptr->time_pending % DNS_SERVER_TIMEOUT == 0) &&
	    ( ptr->time_pending < DNS_TIMEOUT) )
	{
          /* Send a request to the next nameserver */
          next_server_index = ptr->time_pending/DNS_SERVER_TIMEOUT;

	  /* If already the maximum number of supported servers have
	    been tried out then remove the request from the list and
	    send a response  back */
          if(next_server_index >= MAX_NAME_SERVER ||
#ifdef ACTION_TEC //fix bug: never be NULL!
             (config.name_server[next_server_index][0]  == '\0' ))
#else
			(config.name_server[next_server_index]  == NULL ))
#endif
            {
        #ifdef ACTION_TEC
                int index_srv = (ptr->time_pending-1)/DNS_SERVER_TIMEOUT;
                if( strlen(config.name_server[index_srv])>=7 )
	        	syslog( LOG_ERR, "No response for DNS request to server %s yet.",
				/*index_srv,*/ config.name_server[index_srv]);
        #endif

	  	/* send error back */
		debug("All Servers Tried: No Response\n");
	  	dns_construct_error_reply(ptr);
	  	dns_write_packet( dns_sock, ptr->src_addr, ptr->src_port, ptr );
	  	dns_request_list = dns_list_remove( dns_request_list, ptr );
        debug("Sent a DNS error message to Client \n");
        #ifdef ACTION_TEC
        syslog( LOG_ERR, "All DNS servers tried, no response.");
        if (!strcmp (config.name_server[0], "0.0.0.0") ) {
            static int num_0 = 0;
            if (num_0 ++ > 2 ) {
                num_0 = 0;
                syslog (LOG_INFO, "wrong dns server, restart..\n");
                exit (1);
            }
        }
        #endif
	    }
	    else
	    {
	#ifdef ACTION_TEC
          	int index_srv = (ptr->time_pending-1)/DNS_SERVER_TIMEOUT;
          	if( strlen(config.name_server[index_srv])>=7 )
	        	syslog( LOG_ERR, "No response for DNS request to server %s yet.",
				/*index_srv,*/ config.name_server[index_srv]);
	#endif

            /* Create the new server IP address and relay the query untouched */
            inet_aton( config.name_server[next_server_index], &in );
            /*!!!*/
            debug("Didn't get a response from last server\n");
            debug("Sending a new request to %s\n", config.name_server[next_server_index]);
            /* Send the new request to the next name server */
            dns_write_packet( dns_sock, in, PORT, ptr );
	    }
    }
#ifdef ACTION_TEC_PARENTCONTROL
    }
#endif

        ptr = next;
      } /* while(ptr) */

      /* purge cache */
      purge_time--;
      if( !purge_time ){
	cache_purge( config.purge_time );

//#ifdef ACTION_TEC_NO_DNSCACHE
//    if (!is_dns_cache())
         purge_time = 5;
//    else
//#else
//	     purge_time = config.purge_time / 60;
//#endif //ACTION_TEC_NO_DNSCACHE

      }

    } /* if (retval) */
  }
  return 0;
}
/*****************************************************************************/
void debug_perror( char * msg ) {
	debug( "%s : %s\n" , msg , strerror(errno) );
}
/*****************************************************************************/
void debug(char *fmt, ...)
{
#define MAX_MESG_LEN 1024

  va_list args;
  char text[ MAX_MESG_LEN ];

  sprintf( text, "[ %d ]: ", getpid());
  va_start (args, fmt);
  vsnprintf( &text[strlen(text)], MAX_MESG_LEN - strlen(text), fmt, args);
  va_end (args);

  if( config.debug_file[0] ){
    FILE *fp;
    fp = fopen( config.debug_file, "a");
    if(!fp){
      syslog( LOG_ERR, "could not open log file %m" );
      return;
    }
    fprintf( fp, "%s", text);
    fclose(fp);
  }

  /** if not in daemon-mode stderr was not closed, use it. */
  if( ! config.daemon_mode ) {
    fprintf( stderr, "%s", text);
  }
}
/*****************************************************************************
 * print usage informations to stderr.
 *
 *****************************************************************************/
void usage(char * program , char * message ) {
  fprintf(stderr,"%s\n" , message );
  fprintf(stderr,"usage : %s [-c <config-file>] [-d] [-h] [-P]\n", program );
  fprintf(stderr,"\t-c <config-file>\tread configuration from <config-file>\n");
  fprintf(stderr,"\t-d \t\trun in debug (=non-daemon) mode.\n");
  fprintf(stderr,"\t-P \t\tprint configuration on stdout and exit.\n");
  fprintf(stderr,"\t-h \t\tthis message.\n");
}
/*****************************************************************************
 * get commandline options.
 *
 * @return 0 on success, < 0 on error.
 *****************************************************************************/
int get_options( int argc, char ** argv )
{
  char c = 0;
  int not_daemon = 0;
  int want_printout = 0;
  char * progname = argv[0];

  conf_defaults();

  while( (c = getopt( argc, argv, "c:dhP")) != EOF ) {
    switch(c) {
	 case 'c':
  		conf_load(optarg);
                if(config.config_file)
                  stat(config.config_file, &conf_stat);
		break;
	 case 'd':
		not_daemon = 1;
		break;
	 case 'h':
		usage(progname,"");
		return -1;
	 case 'P':
		want_printout = 1;
		break;
	 default:
		usage(progname,"");
		return -1;
    }
  }

  /** unset daemon-mode if -d was given. */
  if( not_daemon ) {
	 config.daemon_mode = 0;
  }

  if( want_printout ) {
	 conf_print();
	 exit(0);
  }
  return 0;
}
/*****************************************************************************/
void sig_hup (int signo)
{
  signal(SIGHUP, sig_hup); /* set this for the next sighup */
  conf_load (config.config_file);
}
/*****************************************************************************/
int main(int argc, char **argv)
{

  /* get commandline options, load config if needed. */
  if(get_options( argc, argv ) < 0 ) {
	  exit(1);
  }

  signal(SIGHUP, sig_hup);

  dns_init();

  if (config.daemon_mode) {
    /* Standard fork and background code */
    switch (fork()) {
	 case -1:	/* Oh shit, something went wrong */
		debug_perror("fork");
		exit(-1);
	 case 0:	/* Child: close off stdout, stdin and stderr */
		close(0);
		close(1);
		close(2);
		break;
	 default:	/* Parent: Just exit */
		exit(0);
    }
  }

  dns_main_loop();

  return 0;
}

#ifdef ACTION_TEC_HURL_DEMO
int findip(char *ip){
    FILE *fp;
    char *file="/var/tmp/dhcp_iphost_hurl";
    char tmp[100];
    char state[3];

    fp=fopen(file,"r");

    if (!fp) {
        return 0;
    }
    rewind(fp);

    while(!feof(fp)){
        memset(tmp, 0, 100);
        fscanf(fp,"%s %s\n",tmp,state);
        if ( (tmp[0]!='\0') && (strncmp(tmp,ip,strlen(ip))==0) ) {
         fclose(fp);
         return 1;
        }
    }

    fclose(fp);
    return 0;
}

int isLocalhost(char *hname){
    FILE *fp;
    char *file="/var/tmp/hosts.dhcp";
    char name[100];
    char ip[20];

    fp=fopen(file,"r");

    if (!fp) {
        return 0;
    }
    rewind(fp);

    while(!feof(fp)){
        memset(name, 0, 100);
        memset(ip,0,20);

        fscanf(fp,"%s \t%s\n",ip,name);
        if ( (ip[0]!='\0') && (strncmp(name,hname,strlen(name))==0) ) {
         //kprintf("find host=%s in hosts.dhcp",name);
         fclose(fp);
         return 1;
        }
    }
    fclose(fp);
    return 0;
}
#endif
