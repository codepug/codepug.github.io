#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#ifndef DPROXY_H
#define DPROXY_H

#define PORT 53
#define NAME_SIZE 255
#define MAX_PACKET_SIZE 512
#define BUF_SIZE NAME_SIZE

typedef u_int16_t uint16;
typedef u_int32_t uint32;

#include "dns.h"

#ifndef DNS_TIMEOUT 
#define DNS_TIMEOUT 240
#endif
#ifndef DNS_SERVER_TIMEOUT
#define DNS_SERVER_TIMEOUT 2 
#endif
#ifndef MAX_NAME_SERVER
#define MAX_NAME_SERVER 5
#endif

#ifndef NAME_SERVER_DEFAULT
#define NAME_SERVER_DEFAULT "192.168.1.1"
#endif
#ifndef CONFIG_FILE_DEFAULT 
#define CONFIG_FILE_DEFAULT "/etc/dproxy.conf"
#endif
#ifndef DENY_FILE_DEFAULT 
#define DENY_FILE_DEFAULT "/etc/dproxy.deny"
#endif
#ifndef CACHE_FILE_DEFAULT 
#define CACHE_FILE_DEFAULT "/var/cache/dproxy.cache"
#endif
#ifdef ACTION_TEC_PARENTCONTROL
#ifndef CACHE_FILE_DEFAULT_CAT 
#define CACHE_FILE_DEFAULT_CAT "/var/cache/dproxy_cat.cache"
#endif
#endif
#ifndef HOSTS_FILE_DEFAULT 
#define HOSTS_FILE_DEFAULT "/etc/hosts"
#endif
#ifndef PURGE_TIME_DEFAULT 
//#define PURGE_TIME_DEFAULT 48 * 60 * 60  Original
#ifdef ACTION_TEC_NO_DNSCACHE //Verizon don't want dns cache, see the comments in cache.c
#define PURGE_TIME_DEFAULT 1 * 60
#else
#define PURGE_TIME_DEFAULT 5 * 60
#endif //ACTION_TEC_NO_DNSCACHE

#endif
#ifndef PPP_DEV_DEFAULT 
#define PPP_DEV_DEFAULT "/var/run/ppp0.pid"
#endif
#ifndef DHCP_LEASES_DEFAULT 
#define DHCP_LEASES_DEFAULT "/var/lib/misc/udhcpd.leases"
#endif
#ifndef PPP_DETECT_DEFAULT 
#define PPP_DETECT_DEFAULT 0
#endif
#ifndef DEBUG_FILE_DEFAULT 
#define DEBUG_FILE_DEFAULT "/var/log/dproxy.debug.log"
#endif

void debug_perror( char * msg );
void debug(char *fmt, ...);

#ifdef ACTION_TEC_PARENTCONTROL //xuwei

#ifndef NAME_SERVER_PDNS_DEFAULT
#define NAME_SERVER_PDNS_DEFAULT "209.227.180.89"
#endif

#define DIR_PC          "/var/etc/pc/"
#define PREFIX_PAGE     "gotopage_"
#define FILE_ENABLE_PC  "/var/etc/pc/enable_pc"
#define FILE_LOGONTABLE "/var/etc/pc/logontable"
#define FILE_BLOCKTABLE "/var/etc/pc/blocktable"
#define FILE_PDNSIP     "/var/etc/pc/pdnsip"
#define FILE_LANIP      "/var/etc/pc/lanip"
#define FILE_URL_PC     "/var/etc/pc/report_url"
#define MAX_LINE        255
#define MAX_LEN_USERID  30

#define PDNS_PREFIX "10.10.10."
#define PDNS_NORECORD "10.10.10.254"

int pdns_cat(char *ip_pdns);
int pdns_blocked_cat(char *ip_src, int cat);
int pdns_blocked(char *ip_src, char *ip_pdns);
int get_lanip (char *ip);
void write_log_pc (struct in_addr src_addr, char *website, int blocked);
int set_gotopage(char *ip_src, char *pagename);


#endif

#endif
