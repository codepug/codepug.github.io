#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "dns_construct.h"
#ifdef ACTION_TEC_PARENTCONTROL
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <stdarg.h>
#include <time.h>
#define ACTION_TEC_KPRINTF
int kprintf (const char *fmt, ...)
{
#ifndef ACTION_TEC_KPRINTF
    return 0;
#else
#define MAX_KMSGLEN 80 //defined in led driver
    static char tmp_text[MAX_KMSGLEN+3];
    va_list ap;
    FILE *fproc;

    memset (tmp_text, 0, sizeof (tmp_text));
        va_start(ap, fmt);
        vsnprintf(tmp_text+3, sizeof (tmp_text)-3-1, fmt, ap);
        va_end(ap);
    tmp_text[0] = '9';
    tmp_text[1] = '9';
    tmp_text[2] = ',';
    /* Open /proc/led_mod/led file for LED Operation */
    fproc = fopen("/proc/led_mod/led", "w+");

    if(!fproc) {
      return -1;
    }
    fwrite(tmp_text, 1, strlen (tmp_text), fproc);
    fclose(fproc);
    return 0;
#endif //ACTION_TEC_KPRINTF
}

int pc_enabled (void) 
{
    char buf[5];
    FILE *fp;
    int ret = 0;

    memset (buf, 0, sizeof (buf));
    fp = fopen(FILE_ENABLE_PC, "r");
    if (fp) {
        fgets(buf, sizeof(buf) -1 , fp);
        ret = atoi (buf);
        fclose(fp);
    } 
    return ret;
}

/*
    return 1 --- True, Wan connected
    return 0 --- False, WAN not connected
 * */
int wan_connected (void)
{
    FILE *fp;
    char line[10];
    int ret = 0;

    fp = fopen("/var/etc/pc/wanmode", "r");
    if (fp) {
        if (fgets(line, sizeof (line) -1, fp) != NULL) {
            if (line[0] == '1') 
                ret = 1;
        }
        fclose(fp);
    }

    return ret;
}

int set_gotopage(char *ip_src, char *pagename)
{
    FILE *fp;
    char filename[50];
    int ret = -1;

    sprintf (filename, "%s%s%s", DIR_PC, PREFIX_PAGE, ip_src);
    fp = fopen(filename, "w");
    if (fp) {
        fputs(pagename, fp);
        fclose(fp);
        ret = 0;
    }
    return ret;
}
/*
 * search in the LOGONOFF table (/var/etc/pc/logontable) 
   check wether this src_addr has logoned or not
*/
int is_logoned (struct in_addr src_addr) {
    FILE *fp;
    int logon_already = 0;
    char buf[MAX_LINE];
    char *user_id;
    char *ip;
    char *logon;
    char ip_src[20];

    //if parentcontrol not enabled, means always loggoned
    if (!pc_enabled ()) return 1;
    
    //check if the src ip has logon or not
    fp = fopen (FILE_LOGONTABLE, "r");
    if (fp) {
        strcpy (ip_src, inet_ntoa (src_addr));
        while ((fgets (buf, sizeof (buf)- 1, fp)) != NULL) {
            ip =        strtok (buf, " \t\n");
            logon =     strtok (NULL, " \t\n");
            user_id =   strtok (NULL, " \t\n");
            if (ip && logon && user_id ) 
            {
                if (strcmp (ip_src, ip) == 0) {
                    if (strcmp (logon, "1") == 0 )
                        logon_already = 1;
                    break;
                }
            }
        }
        fclose (fp);
    }

//    kprintf ("logon=%s, %d\n", ip_src, logon_already);
    return logon_already;
}
/*
 *  get lanip to ip
    now we get the lan ip from hurl.conf
   0 - not found, ip no change;
   1 - found, lanip is in ip;
*/
int get_lanip (char *ip) {
    char buf[MAX_LINE];
    FILE *fp;
    int gotip = 0;

    fp = fopen(FILE_LANIP, "r");
    if (fp != NULL) {
        if (fgets(buf, sizeof(buf) -1 , fp) != NULL) {
            char *s;
            s = strtok (buf," \t\n");
//                kprintf ("----got lan ip=%s\n", s);
            strcpy (ip, s);
            gotip = 1;
        }
        fclose(fp);
    } 
    return gotip;
}

/*
 * if ip_src has logonned user, return 1 with the userid in logonuserid
   or return 0;
*/
int get_logonuserid (char *ip_src, char *logonuserid)
{
    FILE *fp;
    char *ip;
    char *logonoff;
    char buf[MAX_LINE];
    char *userid = NULL;

    fp = fopen (FILE_LOGONTABLE,  "r");
    if (fp) {
        while (fgets(buf, sizeof(buf)-1, fp) != NULL) {
            //check if the src ip has logon or not
            ip =  strtok (buf, " \t\n");
            logonoff = strtok (NULL, " \t\n");
            if (ip && 
                (strcmp (ip_src, ip) == 0) &&
                logonoff && 
                (logonoff[0] == '1')) {
                userid = strtok (NULL, " \t\n");
                break;
            }
            memset (buf, 0, sizeof (buf));
        }
        fclose (fp);
    }

    if (userid) {
        strncpy (logonuserid, userid, MAX_LEN_USERID);
        return 1;
    }

    return 0;
}

#include <syslog.h>
#define PREFIX_REPORT_CMS "CMS_RePoRt:"
void write_log_pc (struct in_addr src_addr, char *website, int blocked)
{
    FILE *fp;
    char userid[MAX_LEN_USERID];
    char time_now[30];
    time_t tp;
    
    if (!pc_enabled ()) return;

    tp = time (NULL);
    strftime (time_now, sizeof (time_now) -1, "%Y/%m/%d_%H:%M:%S", localtime (&tp));
    get_logonuserid (inet_ntoa (src_addr), userid);
    syslog (LOG_INFO, "%s %s %s %d %s", PREFIX_REPORT_CMS, userid, website, blocked, time_now);
    return;

#if 0 // writelog to file
    fp = fopen (FILE_URL_PC, "a");
    if (fp) {
        strcpy (userid, "unknown");
        tp = time (NULL);
        strftime (time_now, sizeof (time_now) -1, "%Y/%m/%d_%H:%M:%S", localtime (&tp));
        get_logonuserid (inet_ntoa (src_addr), userid);
        fprintf (fp, "%s %s %d %s\n", userid, website, blocked, time_now);
        fclose (fp);
    }
#endif //writelog to file
}

//xuwei for the following

/*Return value: 
    0-not PDNS value; 
    Positive value: PDNS classification ID*/
int pdns_cat(char *ip_pdns)
{                   
    int cat;
    char *p_cat;
    if (!ip_pdns) return 0;//to be safe
    if(strncmp(ip_pdns, PDNS_PREFIX, strlen(PDNS_PREFIX)) != 0)
        return 0;
    p_cat = ip_pdns+strlen(PDNS_PREFIX);
    if(!p_cat) return 0;
    cat = atoi(p_cat);
    return cat;
}

/*
struct block_table_t{
    char user[16];
    char pass[16];
    int cats;    //category
    int time[7]; //7 days 
} g_block_table[10];


void read_block_table()
{
    FILE* fp;
    char buf[512];
    char *user;
    char *pass;
    char *blocked_cats;
    char user_src[60];
    char *blocked_time;            

    fp = fopen (FILE_BLOCKTABLE, "r");
    if (fp) {
        while ((fgets (buf, sizeof (buf)- 1, fp)) != NULL) {
            user = strtok (buf, ",\n");
            pass = strtok (NULL, ",\n");
            blocked_cats = strtok (NULL, ",\n");
            
            user_src[0] = '\0';
            get_logonuserid(ip_src, user_src);
            debug ("user_src=%s,cat=%i; user=%s,blocked_cats=%s\n", user_src,cat, user, blocked_cats);
            
            if (user && (strcmp (user_src, user) == 0)){ 
                blocked_cat = strtok(blocked_cats, "-");
                while(blocked_cat != NULL){
                    debug("cat=%i, blocked_cat=%s\n",cat, blocked_cat);
                    if(atoi(blocked_cat) == cat) return 1;
                    blocked_cat = strtok(NULL, "-");
                }
            }
        }
        fclose (fp);
    }
}
*/

int is_time_blocked(char *ip_src)
{
    FILE* fp;
    static long int offset = 0;
    int use_GMT = 0;
    time_t now;
    struct tm now2;
    char buf[512];
    char *user;
    char *pass;
    char user_src[60];
    char *blocked_cats;
    char *blocked_times;
    char *blocked_hour;
    int blocked_hour2;

//      if (strstr (msg, "GoTnTp")) 
//          use_GMT = 1;
    
    if(offset == 0){
        debug("read time offset\n");
        fp = fopen("/var/tmp/offset_t", "r");
        if(fp)
        {
            long a1=0, a2=0;
            use_GMT = fscanf(fp, "%li %li", &a1, &a2);
            if(use_GMT==2) offset = a1;
            fclose(fp);
        }
    }
    debug("time offset=%x\n", offset);
    
    if(offset == 0){//NTP not working?
       return 0;
    }else{
        
        time(&now);
        now += offset;
        gmtime_r (&now, &now2); //thread safe version of gmtime 

        user_src[0] = '\0';
        get_logonuserid(ip_src, user_src);

        debug("user: %s;today: %x;hour: %x\n",user_src, now2.tm_wday, now2.tm_hour);

        //analyze block table
        fp = fopen (FILE_BLOCKTABLE, "r");
        if (fp) {
            while ((fgets (buf, sizeof (buf)- 1, fp)) != NULL) {
                user = strtok (buf, ",\n");
                pass = strtok (NULL, ",\n");
                blocked_cats = strtok (NULL, ",\n");
                blocked_times = strtok (NULL, ",\n");

                debug ("user=%s,blocked_times=%s\n", user, blocked_times);
                                                              
                if (blocked_times && user && (strcmp (user_src, user) == 0)){ 
                    int day = 0;
                    blocked_hour = strtok(blocked_times, "-");
                    while(blocked_hour != NULL){
                        if(day == now2.tm_wday){
                            blocked_hour2 = strtol(blocked_hour,NULL,16);
                            debug("blocked_hour2=%x\n",blocked_hour2);
                            if(blocked_hour2 & (1<<now2.tm_hour)) return 1;
                            else return 0;
                        }
                        blocked_hour = strtok(NULL, "-");
                        day++;
                    }
                    break;
                }
            }
            fclose (fp);
        }
        return 0;
    }
    
}


/*
 * search in the BLOCK table (/var/etc/pc/blocktable) 
   check wether for ip, cat has been blocked or not?
*/
int pdns_blocked_cat(char *ip_src, int cat)
{
    FILE *fp;
    char buf[512];
    char *user;
    char *pass;
    char *blocked_cats;
    char *blocked_cat;
    char user_src[60];
    
    user_src[0] = '\0';
    get_logonuserid(ip_src, user_src);
    
    fp = fopen (FILE_BLOCKTABLE, "r");
    if (fp) {
        while ((fgets (buf, sizeof (buf)- 1, fp)) != NULL) {
            user = strtok (buf, ",\n");
            pass = strtok (NULL, ",\n");
            blocked_cats = strtok (NULL, ",\n");
            
            debug ("user_src=%s,cat=%i; user=%s,blocked_cats=%s\n", user_src,cat, user, blocked_cats);
            
            if (blocked_cats && user && (strcmp (user_src, user) == 0)){ 
                blocked_cat = strtok(blocked_cats, "-");
                while(blocked_cat != NULL){
                    debug("cat=%i, blocked_cat=%s\n",cat, blocked_cat);
                    if(atoi(blocked_cat) == cat) return 1;
                    blocked_cat = strtok(NULL, "-");
                }
            }
        }
        fclose (fp);
    }

    return 0;
}

int pdns_blocked(char *ip_src, char *ip_pdns)
{
    int cat;
    cat = pdns_cat(ip_pdns);
    return pdns_blocked_cat(ip_src,cat);
}

#endif //ACTION_TEC_PARENTCONTROL

#define SET_UINT16_TO_N(buf, val, count) *(uint16*)buf = htons(val);count += 2; buf += 2
#define SET_UINT32_TO_N(buf, val, count) *(uint32*)buf = htonl(val);count += 4; buf += 4
/*****************************************************************************/
/* this function encode the plain string in name to the domain name encoding 
 * see decode_domain_name for more details on what this function does. */
int dns_construct_name(char *name, char *encoded_name)
{
  int i,j,k,n;

  k = 0; /* k is the index to temp */
  i = 0; /* i is the index to name */
  while( name[i] ){

	 /* find the dist to the next '.' or the end of the string and add it*/
	 for( j = 0; name[i+j] && name[i+j] != '.'; j++);
	 encoded_name[k++] = j;

	 /* now copy the text till the next dot */
	 for( n = 0; n < j; n++)
		encoded_name[k++] = name[i+n];
	
	 /* now move to the next dot */ 
	 i += j + 1;

	 /* check to see if last dot was not the end of the string */
	 if(!name[i-1])break;
  }
  encoded_name[k++] = 0;
  return k;
}
/*****************************************************************************/
int dns_construct_header(dns_request_t *m)
{
  char *ptr = m->original_buf;
  int dummy;

  SET_UINT16_TO_N( ptr, m->message.header.id, dummy );
  SET_UINT16_TO_N( ptr, m->message.header.flags.flags, dummy );
  SET_UINT16_TO_N( ptr, m->message.header.qdcount, dummy );
  SET_UINT16_TO_N( ptr, m->message.header.ancount, dummy );
  SET_UINT16_TO_N( ptr, m->message.header.nscount, dummy );
  SET_UINT16_TO_N( ptr, m->message.header.arcount, dummy );
  
  return 0;
}
#ifdef CUSTOME_HURL
extern  int hurl_dns_on;
#endif

/*****************************************************************************/
#ifdef ACTION_TEC_PARENTCONTROL
void dns_construct_reply( dns_request_t *m, int logon_already, int cat_blocked, int time_blocked )
#else
void dns_construct_reply( dns_request_t *m )                             
#endif //ACTION_TEC_PARENTCONTROL
{
  int len;

  /* point to end of orginal packet */ 
  m->here = &m->original_buf[m->numread];

  m->message.header.ancount = 1;
  m->message.header.flags.f.question = 1;
  dns_construct_header( m );
#ifdef  ACTION_TEC
  if ((strlen (m->cname) > strlen (".domain_not_set.invalid")) && //for timeout of ".domain_not_set.invalid" patch
        !strcmp (m->cname + strlen (m->cname) - strlen (".domain_not_set.invalid"), ".domain_not_set.invalid") &&
        strcmp (m->cname, "dslmodem.domain_not_set.invalid") )
  {
        struct in_addr in;

        m->message.header.ancount = 0;
        m->message.header.nscount = 1;
        m->message.header.flags.f.recursion_avail = 1;
        dns_construct_header( m );
        inet_aton( m->ip, &in );
        SET_UINT16_TO_N( m->here, 0xc00c, m->numread ); /* pointer to name */
        SET_UINT16_TO_N( m->here, SOA, m->numread );      /* type */
        SET_UINT16_TO_N( m->here, IN, m->numread );     /* class */

        SET_UINT16_TO_N( m->here, 0x0000, m->numread );
        SET_UINT16_TO_N( m->here, 0x0e10, m->numread );
        SET_UINT16_TO_N( m->here, 0x001b, m->numread );
        SET_UINT16_TO_N( m->here, 0x0e64, m->numread );
        SET_UINT16_TO_N( m->here, 0x6f6d, m->numread );
        SET_UINT16_TO_N( m->here, 0x6169, m->numread );
        SET_UINT16_TO_N( m->here, 0x6e5f, m->numread );
        SET_UINT16_TO_N( m->here, 0x6e6f, m->numread );
        SET_UINT16_TO_N( m->here, 0x745f, m->numread );
        SET_UINT16_TO_N( m->here, 0x7365, m->numread );
        SET_UINT16_TO_N( m->here, 0x7407, m->numread );
        SET_UINT16_TO_N( m->here, 0x696e, m->numread );
        SET_UINT16_TO_N( m->here, 0x7661, m->numread );
        SET_UINT16_TO_N( m->here, 0x6c69, m->numread );
        SET_UINT16_TO_N( m->here, 0x6400, m->numread );
        SET_UINT16_TO_N( m->here, 0x0000, m->numread );
        SET_UINT16_TO_N( m->here, 0x0095, m->numread );
        SET_UINT16_TO_N( m->here, 0x1300, m->numread );
        SET_UINT16_TO_N( m->here, 0x000e, m->numread );
        SET_UINT16_TO_N( m->here, 0x1000, m->numread );
        SET_UINT16_TO_N( m->here, 0x000e, m->numread );
        SET_UINT16_TO_N( m->here, 0x1000, m->numread );
        SET_UINT16_TO_N( m->here, 0x000e, m->numread );
        SET_UINT16_TO_N( m->here, 0x1000, m->numread );
        SET_UINT16_TO_N( m->here, 0x000e, m->numread );
        SET_UINT16_TO_N( m->here, 0x1000, m->numread );

        //syslog (LOG_INFO,"===9==%s type = %d, numread=%d\n", m->cname, m->message.question[0].type , m->numread);

        return;
   }

#endif // ACTION_TEC
//  kprintf ("dns %d,%08x,%s\n", m->message.question[0].type, m->src_addr.s_addr, m->ip);
#ifdef ACTION_TEC_PARENTCONTROL
  if (!wan_connected () && pc_enabled ()) {
      get_lanip (m->ip);
      //redirect to unconnected page
      set_gotopage (inet_ntoa (m->src_addr), "pc_unconnected.html");
  }
  else if (!logon_already) { //if not logon yet, set the dns to lan ip and redirect to logon page
      get_lanip (m->ip);
      //redirect to logon page
      set_gotopage (inet_ntoa (m->src_addr), "pc_logon.html");
  }else if(cat_blocked){
      get_lanip (m->ip);
      //redirect to logon page
      set_gotopage (inet_ntoa (m->src_addr), "pc_blocked.html");
  }else if(time_blocked){
      get_lanip (m->ip);
      //redirect to logon page
      set_gotopage (inet_ntoa (m->src_addr), "pc_blocked_time.html");
  }

#endif //ACTION_TEC_PARENTCONTROL 

  if( m->message.question[0].type == A ){
    /* standard lookup so return and IP */
    struct in_addr in;
    
    inet_aton( m->ip, &in );
    SET_UINT16_TO_N( m->here, 0xc00c, m->numread ); /* pointer to name */
    SET_UINT16_TO_N( m->here, A, m->numread );      /* type */
    SET_UINT16_TO_N( m->here, IN, m->numread );     /* class */
#ifdef ACTION_TEC
    if (!strcmp (m->cname, "clearcache.domain_not_set.invalid")) {
        //kprintf ("--- set dns ttl 0\n");
        SET_UINT32_TO_N( m->here, 0, m->numread );	/* ttl */
    }
    else {
#endif // ACTION_TEC
#ifdef CUSTOME_HURL
		if (hurl_dns_on){
			SET_UINT32_TO_N( m->here, 0, m->numread );	/* ttl */
		}
		else{
#ifdef  ACTION_TEC_PARENTCONTROL
            if (!logon_already) {
                SET_UINT32_TO_N( m->here, 0, m->numread );	/* ttl */
            }
            else {
                SET_UINT32_TO_N( m->here, 10000, m->numread );  /* ttl */
            }
#else   //ACTION_TEC_PARENTCONTROL
            SET_UINT32_TO_N( m->here, 10000, m->numread );  /* ttl */
#endif //ACTION_TEC_PARENTCONTROL
		}
#else //CUSTOME_HURL
#ifdef  ACTION_TEC_PARENTCONTROL
    if (!logon_already) {
        SET_UINT32_TO_N( m->here, 0, m->numread );	/* ttl */
    }
    else {
        SET_UINT32_TO_N( m->here, 10000, m->numread );  /* ttl */
    }
#else   //ACTION_TEC_PARENTCONTROL
    SET_UINT32_TO_N( m->here, 10000, m->numread );  /* ttl */
#endif //ACTION_TEC_PARENTCONTROL
#endif  //CUSTOME_HURL


#ifdef ACTION_TEC   //for "clearcache.domain_not_set.invalid"
    }
#endif // ACTION_TEC

    SET_UINT16_TO_N( m->here, 4, m->numread );      /* datalen */
    memcpy( m->here, &in.s_addr, sizeof(in.s_addr) ); /* data */
    m->numread += sizeof( in.s_addr);
  }else if ( m->message.question[0].type == PTR ){
    /* reverse look up so we are returning a name */
    SET_UINT16_TO_N( m->here, 0xc00c, m->numread ); /* pointer to name */
    SET_UINT16_TO_N( m->here, PTR, m->numread );    /* type */
    SET_UINT16_TO_N( m->here, IN, m->numread );     /* class */
#ifdef  ACTION_TEC_PARENTCONTROL
    if (!logon_already) {
        SET_UINT32_TO_N( m->here, 0, m->numread );	/* ttl */
    }
    else {
        SET_UINT32_TO_N( m->here, 10000, m->numread );  /* ttl */
    }
#else
    SET_UINT32_TO_N( m->here, 10000, m->numread );  /* ttl */
#endif //ACTION_TEC_PARENTCONTROL
    len = dns_construct_name( m->cname, m->here + 2 );
    SET_UINT16_TO_N( m->here, len, m->numread );      /* datalen */
    m->numread += len;
  }
}

/*****************************************************************************/
void dns_construct_error_reply(dns_request_t *m)
{
  /* point to end of orginal packet */ 
  m->here = m->original_buf;

  m->message.header.flags.f.question = 1;
  m->message.header.flags.f.rcode = 2;
  dns_construct_header( m );
}
