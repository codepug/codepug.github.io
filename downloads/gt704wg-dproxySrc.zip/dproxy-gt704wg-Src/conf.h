/*
  **
  ** conf.h - function prototypes for the config handling routines
  **
  ** Part of the drpoxy package by Matthew Pratt.
  **
  ** Copyright 2000 Jeroen Vreeken (pe1rxq@chello.nl)
  **
  ** This software is licensed under the terms of the GNU General
  ** Public License (GPL). Please see the file COPYING for details.
  **
  **
*/
#include <stdlib.h>
#include <stdio.h>
#include "dproxy.h"

#define CONF_PATH_LEN 256
/* 
    more parameters may be added later.
 */
struct config {
  char name_server[MAX_NAME_SERVER][CONF_PATH_LEN]; 
#ifdef ACTION_TEC_PARENTCONTROL
  char name_server_pdns[MAX_NAME_SERVER][CONF_PATH_LEN]; 
#endif
  int daemon_mode;
  int ppp_detect;
  int purge_time;
  char config_file[CONF_PATH_LEN];
  char deny_file[CONF_PATH_LEN];
  char cache_file[CONF_PATH_LEN];
#ifdef ACTION_TEC_PARENTCONTROL
  char cache_file_cat[CONF_PATH_LEN];
#endif
  char hosts_file[CONF_PATH_LEN];
  char ppp_device_file[CONF_PATH_LEN];
  char dhcp_lease_file[CONF_PATH_LEN];
  char debug_file[CONF_PATH_LEN];
};

/** 
 * typedef for a param copy function. 
 */
typedef void (* conf_copy_func)(char *, void *);
typedef void (* conf_print_func)(FILE * fp, void *);

/**
 * description for parameters in the config file
 */
typedef struct {
  char * param_name;         /* name for this parameter             */
  char * comment;            /* a comment for this parameter        */
  void * conf_value;         /* pointer to a field in struct config */
  void * def_value;
  conf_copy_func  init;      /* a function to set the value in 'config'*/
  conf_copy_func  copy;      /* a function to set the value in 'config'*/
  conf_print_func print;     /* a function to print the value from 'config'*/
} config_param; 


extern struct config config;
#ifdef ACTION_TEC_PARENTCONTROL                      
extern struct config config_defaults;
#endif
int conf_load (char *conf_file);
void conf_defaults (void);
void conf_cmdparse(char *cmd, char *arg1);
int conf_bool (char *val);

void conf_print();

