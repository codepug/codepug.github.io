/*
  **
  ** cache.c - cache handling routines
  **
  ** Part of the dproxy package by Matthew Pratt. 
  **
  ** Copyright 1999 Matthew Pratt <mattpratt@yahoo.com>
  **
  ** This software is licensed under the terms of the GNU General 
  ** Public License (GPL). Please see the file COPYING for details.
  ** 
  **
*/
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <sys/file.h>
#include <ctype.h>
#include <unistd.h>

#include "cache.h"
#include "conf.h"

/** function prototypes for private functions*/
static int cache_byname(FILE * , char *, char *);
#ifdef CUSTOME_HURL
static int hurl_cache_byname(FILE * , char *, char *);
#endif
/*****************************************************************************
 *  search for a host by its name.
 *  
 *    This function first searches the cache for an entry. If the entry 
 *    was not found there, we will look into a dhcp "leases" file.
 * 
 *  @arg name  - name to find.
 *  @arg ip    - pointer to a buffer where to put the ip adress.
 *  
 *  @return 0 if an entry was found, 1 if not.
*****************************************************************************/
int cache_lookup_name(char *name, char ip[BUF_SIZE])
{
  FILE * fp;
  
  debug( "cache_lookup_name(%s)\n", name);
  
  /** check the cache */
  if( (fp = fopen( config.cache_file , "r")) != NULL) {
	 int result = 0;
	 result = cache_byname(fp,name, ip); 
	 fclose(fp);   
	 if( result > 0 ) {
		return 1;
	 }
  }
  
  return 0;
}

#ifdef ACTION_TEC_PARENTCONTROL
int cache_lookup_cat(char *name, char ip[BUF_SIZE])
{
  FILE * fp;
  
  debug( "cache_lookup_cat(%s)\n", name);
  
  /** check the cache */
  if( (fp = fopen( config.cache_file_cat , "r")) != NULL) {
	 int result = 0;
	 result = cache_byname(fp,name, ip); 
	 fclose(fp);   
	 if( result > 0 ) {
		return 1;
	 }
  }
  return 0;
}
#endif


#ifdef ACTION_TEC

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
/**********************************************************************
 * search for a host by its name in a file
 * *******************************************************************/
int hosts_lookup_name(char *name, char ip[BUF_SIZE])
{
  FILE * fp;
  char *host_name, *host_ip;
  struct in_addr addr;
  char line[BUF_SIZE];

  if(name == NULL || name[0] == '\0')
          return 0;

  debug( "hosts_lookup_name(%s)\n", name);

  /** check the cache */
  if( (fp = fopen( config.hosts_file , "r")) != NULL) {
          rewind(fp);

          while(fgets(line, BUF_SIZE, fp))
          {
                  host_ip = strtok(line, " \t\r\n");
                  if(host_ip && host_ip[0] && inet_aton(host_ip, &addr))
                  {
                        host_name = strtok(NULL, " \t\r\n");
                        if(host_name && !strcasecmp(host_name, name))
                        {
//                              strncpy(ip, host_ip, BUF_SIZE - 1);
                                fclose(fp);
                                return 1;
                        }
                  }
          }
          fclose(fp);
  }

  return 0;
}
#endif

/*****************************************************************************
 *  search for a host by its name.
 *  
 *    This function first searches the cache for an entry. If the entry 
 *    was not found there, we will look into a dhcp "leases" file.
 * 
 *  @arg name  - name to find.
 *  @arg ip    - pointer to a buffer where to put the ip adress.
 *  
 *  @return 1 if an entry was found, 0 if not.
*****************************************************************************/
#ifdef CUSTOME_HURL
int hurl_cache_lookup_name(char *name, char ip[BUF_SIZE])
{
  FILE * fp;
  #define hurl_cache_file "/var/etc/hurl.conf"
  debug( "hurl_cache_lookup_name(%s)\n", name);
             
  /** check the cache */
  if( (fp = fopen( hurl_cache_file, "r")) != NULL) {
	 int result = 0;
	 result = hurl_cache_byname(fp,name, ip); 
	 fclose(fp);   
	 if( result) {/*Found entry*/
		return 1;
	 }
  }

  
  debug( "cache_lookup_name(%s)\n", name);
  
  /** check the cache */
  if( (fp = fopen( config.cache_file , "r")) != NULL) {
	 int result = 0;
	 result = cache_byname(fp,name, ip); 
	 fclose(fp);   
	 if( result > 0 ) {
		return 1;
	 }
  }
  
  return 0;
}
#endif

/*****************************************************************************
 * lookup a hostname in the cache file.
 *
 * This function will not lock the cache ! 
 * 
 *  @arg fp    - open file pointer for the cache file.
 *  @arg name  - name to find.
 *  @arg ip    - pointer to a buffer where to put the ip adress.
 *  
 *  @return 0 if an entry was found, 1 if not.
 *****************************************************************************/
static int cache_byname(FILE * fp, char *name, char ip[BUF_SIZE])
{

  char line[BUF_SIZE];
  char *token;
  int i = 0;

debug("x: by name");
  ip[0] = '1';
  ip[1] = '9';
  ip[2] = '2';
  ip[3] = '.';
  ip[4] = '1';
  ip[5] = '6';
  ip[6] = '8';
  ip[7] = '.';
  ip[8] = '1';
  ip[9] = '.';
  ip[10] = '1';
  ip[11] = 0;
return 1;


  ip[0] = 0;

  /** make shure we are at the start of the cache */
  rewind(fp);

  while( fgets(line, BUF_SIZE, fp) ){
	 token = strtok( line, " ");
	 if( !strcasecmp( token, name) ){
		token = strtok( NULL, " ");
		while( isalnum(*token) || (*token=='.') )ip[i++] = *token++;
		ip[i] = 0;
		return 1;
	 }
  }
 
  return 0;
}
#ifdef CUSTOME_HURL
int hurl_dns_on;
/*****************************************************************************
 * lookup a hostname in the cache file.
 *
 * This function will not lock the cache ! 
 * 
 *  @arg fp    - open file pointer for the cache file.
 *  @arg name  - name to find.
 *  @arg ip    - pointer to a buffer where to put the ip adress.
 *  
 *  @return 1 if an entry was found, 0 if not.
 *****************************************************************************/
static int hurl_cache_byname(FILE * fp, char *name, char ip[BUF_SIZE])
{

  char line[BUF_SIZE];
  char *token;
  int i = 0;
                   
  ip[0] = 0;

  hurl_dns_on = 0;
  /** make shure we are at the start of the cache */
  rewind(fp);

  while( fgets(line, BUF_SIZE, fp) ){
	 token = strtok( line, " ");
	 if( !strcasecmp( token, "WANOFF") ){
/*
    For dial up on demand, we should issue a ping to fire connect.
 * 
 */
         system ("ping_connect&");

		token = strtok( NULL, " ");
		while( isalnum(*token) || (*token=='.') )ip[i++] = *token++;
		ip[i] = 0;
		hurl_dns_on = 1;
		return 1;
	 }
  }

  return 0;
}
#endif
/*****************************************************************************/
int cache_lookup_ip(char *ip, char result[BUF_SIZE])
{
  FILE *fp;
  char line[BUF_SIZE];
  char *token;
  int i = 0;
debug("X: reverse lookup");
result[0]='1';
result[1]='9';
result[2]='2';
result[3]='.';
result[4]='1';
result[5]='6';
result[6]='8';
result[7]='.';
result[8]='1';
result[9]='.';
result[10]='1';
result[11]=0;

//result[0]='d';
//result[1]='s';
//result[2]='l';
//result[3]='m';
//result[4]='o';
//result[5]='d';
//result[6]='e';
//result[7]='m';
//result[8]='.';
//result[9]='d';
//result[10]='o';
//result[11]='m';
//result[12]='a';
//result[13]='i';
//result[14]='n';
//result[15]=0;
return 1;

  if( ip[0] == 0 )return 0;
  result[0] = 0;
  
  fp = fopen( config.cache_file , "r");
  if(!fp)return 0;
  while( fgets(line, BUF_SIZE, fp) ){
	 strtok( line, " ");
	 token = strtok( NULL, " ");
	 if( !strncasecmp( token, ip, strlen(ip) ) ){
		while( isalnum(line[i]) || (line[i]=='.') )result[i] = line[i++];
		result[i] = 0;
		fclose(fp);
		return 1;
	 }
  }
  fclose(fp);
  
  return 0;
}

#ifdef ACTION_TEC_NO_DNSCACHE
/*
    replace the ip address with newip in the cache (name_site matched)
*/
void cache_replace (char *name_site, char *ip_new)
{
  FILE *in_fp, *out_fp;
  char line[BUF_SIZE];
  char old_cache[1024];
  char *name, *ip, *time_made;

  debug("enter cache_purge()\n");

  in_fp = fopen( config.cache_file , "r");
  if(!in_fp){
	 debug_perror("Could not open old cache file");
	 /*return;*/
  }

  if( in_fp ) {

    sprintf( old_cache, "%s.old", config.cache_file );
    if( rename( config.cache_file, old_cache ) < 0 ){
	 debug_perror("Could not move cache file");
	 fclose(in_fp);
	 return;
    }
  }

  out_fp = fopen( config.cache_file , "w");
  if(!out_fp){
	 if( in_fp ) {
	 	fclose(in_fp);
	 }
	 debug_perror("Could not open new cache file");
	 return;
  }

  cache_add_hosts_entries(out_fp);

  if( in_fp ) {
      memset (line, 0 ,sizeof (line));
      while( fgets(line, BUF_SIZE, in_fp) ){
          name = strtok( line, " ");
          ip = strtok( NULL, " ");
          time_made = strtok( NULL, " ");
          if(!time_made || !atoi( time_made ))continue;
          if (!strcmp (name_site, name)) {
              fprintf( out_fp, "%s %s %ld\n", name, ip_new, time_made );
//              kprintf ("repl %s with %s\n", ip, ip_new);
          }
          else {
              fprintf( out_fp, "%s %s %ld\n", name, ip, time_made );
          }
          memset (line, 0 ,sizeof (line));
      }

      fclose(in_fp);
      unlink(old_cache);
  }

  fclose(out_fp);
}
#endif //ACTION_TEC_NO_DNSCACHE

/*****************************************************************************
* save the name to the list.
* 
*
*****************************************************************************/
void cache_name_append(char *name, char *ip)
{

  FILE *fp;
  char dummy[BUF_SIZE];

#ifdef ACTION_TEC //fix bug "duplicate entries"
  if (!ip || !strlen (ip)) {  //or wrong response would block later correct one
      //kprintf ("empty ip %s, no append\n", name);
      return;
  }

  fp = fopen( config.cache_file, "a+");
#else
  fp = fopen( config.cache_file, "a");
#endif
  if(!fp){
	 debug("Could not open cache file '%s' for writing",
		      config.cache_file);
	 return;
  }

  /** check if another process already added this host to the cache */
  if( cache_byname(fp, name, dummy) != 0 ) {
	  fclose(fp);
#ifdef ACTION_TEC_NO_DNSCACHE //Verizon don't want DNS Cache
                          // we can't just clear cache for this because cache value are used for
                          // reverse requests also.
                          // So we send dns request every time and if the value is different from the
                          // cache, we replace it. And we decrease the cache time from 5m to 1m.
//          kprintf ("--dummy=%s,ip=%s\n", dummy, ip);
      if (ip && strcmp (ip, dummy)) { // cache exist but ip is different
          cache_replace (name, ip);
      }
#endif //ACTION_TEC_NO_DNSCACHE
	  return;
  }

  /** make shure that we at the end of the file. */
  fseek(fp,0,SEEK_END);

  /** write new entry */
  fprintf( fp, "%s %s %ld\n", name, ip, time(NULL) );

  fclose(fp);
}
/*****************************************************************************/
#ifdef ACTION_TEC_PARENTCONTROL
void _cache_purge(int older_than)
#else
void cache_purge(int older_than)
#endif
{
  FILE *in_fp, *out_fp;
  char line[BUF_SIZE];
  char old_cache[1024];
  char *name, *ip, *time_made;

  debug("enter cache_purge()\n");

  in_fp = fopen( config.cache_file , "r");
  if(!in_fp){
	 debug_perror("Could not open old cache file");
	 /*return;*/
  }

  if( in_fp ) {

    sprintf( old_cache, "%s.old", config.cache_file );
    if( rename( config.cache_file, old_cache ) < 0 ){
	 debug_perror("Could not move cache file");
	 fclose(in_fp);
	 return;
    }
  }

  out_fp = fopen( config.cache_file , "w");
  if(!out_fp){
	 if( in_fp ) {
	 	fclose(in_fp);
	 }
	 debug_perror("Could not open new cache file");
	 return;
  }

  cache_add_hosts_entries(out_fp);

  if( in_fp ) {
    while( fgets(line, BUF_SIZE, in_fp) ){
	 name = strtok( line, " ");
	 ip = strtok( NULL, " ");
	 time_made = strtok( NULL, " ");
	 if(!time_made)continue;
	 if( time(NULL) - atoi( time_made ) < older_than )
		fprintf( out_fp, "%s %s %s", name, ip, time_made );
    }

    fclose(in_fp);
    unlink(old_cache);
  }

  fclose(out_fp);
}


#ifdef ACTION_TEC_PARENTCONTROL
void cache_purge(int older_than)
{
    //purge cat cache
    strcpy(config.cache_file, config_defaults.cache_file_cat);
    _cache_purge(older_than);
    //purge real cache
    strcpy(config.cache_file, config_defaults.cache_file);
    _cache_purge(older_than);
}
#endif


/*****************************************************************************/
void cache_add_hosts_entries(FILE *cache_file)
{
  FILE *hosts_fp;
  char line[BUF_SIZE];
  char *ip, *name;

  debug("cache_add_hosts_entreies()\n");

  hosts_fp = fopen( config.hosts_file , "r");
  if( !hosts_fp ) {
	debug_perror("can not open 'hosts'-file ");
	return;
  }

  while( fgets(line, BUF_SIZE, hosts_fp) ){
	 line[strlen(line) - 1] = 0; /* get rid of '\n' */
	 ip = strtok( line, " \t");
	 if( ip == NULL ) continue;  /* ignore blank lines */
	 if( ip[0] == '#' )continue; /* ignore comments */
	 while( (name = strtok( NULL, " \t" )) ){
	   if(name[0] == '#')break;
		fprintf( cache_file, "%s %s %ld\n", name, ip, 0L );
	 }
	 
  }
  fclose(hosts_fp);
  debug("cache_add_hosts_entreies(): done\n");
}



