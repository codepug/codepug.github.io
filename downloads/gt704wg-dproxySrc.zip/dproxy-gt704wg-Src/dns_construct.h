#include "dproxy.h"

#ifdef ACTION_TEC_PARENTCONTROL
void dns_construct_reply( dns_request_t *m, int logon_already, int cat_blocked, int time_blocked );
#else
void dns_construct_reply( dns_request_t *m );
#endif //ACTION_TEC_PARENTCONTROL
void dns_construct_error_reply(dns_request_t *m);
