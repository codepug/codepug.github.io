//<applet code="Password" width=200 height=70></applet>
import java.awt.*;
import java.applet.*;

public class Password extends Applet {
	boolean b;

public void init(){
	setBackground( Color.red );
	b = false;	
}

public boolean keyDown(Event evt, int key){
	b = false;
	if (key == 'y')
		b = true;

	repaint();
	return true;
}

public void paint(Graphics g){
	
	g.drawString("Do you know the password?",20,50);
	if (b)
		g.drawString("Sure you do.",20,65);    
	
}
} 