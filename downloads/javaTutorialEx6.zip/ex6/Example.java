//<applet code="Example" width=300 height=300></applet>

import java.awt.*;
import java.applet.*;

public class Example extends Applet{
	Image myImage;
	boolean showImageForMe;
	int scaleFactor;
public void init(){
	add(new Button("Click here for an image"));
	myImage = getImage(getCodeBase(),"image.jpg");
	showImageForMe = false;
	scaleFactor = 100;
}

public void paint(Graphics g){

	g.drawImage(myImage,0,0,scaleFactor,scaleFactor,this);
}

public boolean action(Event evt, Object arg){
	scaleFactor = scaleFactor+100;		

	repaint();
	return true;
	
}


}