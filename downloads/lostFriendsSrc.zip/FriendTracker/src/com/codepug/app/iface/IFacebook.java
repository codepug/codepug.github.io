/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app.iface;

import java.io.IOException;

import com.google.code.facebookapi.FacebookException;

public interface IFacebook {

	/**
	 * Retrieve the friends for the logged in user
	 * 
	 * @return List
	 * @throws FacebookException
	 * @throws IOException
	 */
	public void getFriendsUpdate(FacebookUpdateListener listener);
	
	/**
	 * Callback method
	 * 
	 * @param sessionKey
	 * @param secretSessionKey
	 */
	public void tryAgain(String sessionKey, String secretSessionKey);
}
