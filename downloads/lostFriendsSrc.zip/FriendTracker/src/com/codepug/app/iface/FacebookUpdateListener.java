package com.codepug.app.iface;

import com.codepug.app.friend.Friends;

public interface FacebookUpdateListener {

	public void updatePerformed(Friends updatedFriends);
	
}
