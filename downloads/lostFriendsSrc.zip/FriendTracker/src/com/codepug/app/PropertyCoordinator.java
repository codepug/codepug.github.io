/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class PropertyCoordinator {
	private static File propertyFile;
	private static Properties prop;

	public PropertyCoordinator(String fileName) {
		try {
			prop = new Properties();
			String tempPath = System.getProperty("java.io.tmpdir");
			String path = tempPath + fileName;
			propertyFile = new File(path);
			if (!propertyFile.exists()) {
				propertyFile.createNewFile();
			} else {
				prop.load(new FileInputStream(propertyFile));
			}
		} catch (Exception e) {
			System.err.println("Problem");
		}
	}

	public void set(String key, String value) {
		prop.setProperty(key, value);
	}

	public void set(String key, JTextField value) {
		set(key, value.getText());
	}

	public void set(String key, JPasswordField value) {
		set(key, String.valueOf(value.getPassword()));
	}

	public String get(String key) {
		String result = prop.getProperty(key);
		if (result == null) {
			result = "";
		}
		return result;
	}

	public void save() {
		try {
			prop.store(new FileOutputStream(propertyFile), null);
		} catch (Exception e) {
			System.err.println("Problem");
		}
	}
}
