/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app.integration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.List;

import com.codepug.app.friend.Friends;
import com.codepug.app.iface.FacebookUpdateListener;
import com.codepug.app.iface.IFacebook;
import com.google.code.facebookapi.FacebookException;
import com.google.code.facebookapi.FacebookJaxbRestClient;
import com.google.code.facebookapi.IFacebookRestClient;
import com.google.code.facebookapi.ProfileField;
import com.google.code.facebookapi.schema.FriendsGetResponse;
import com.google.code.facebookapi.schema.User;
import com.google.code.facebookapi.schema.UsersGetInfoResponse;

public class FriendRetriever implements IFacebook {

	private IFacebookRestClient<?> client;
	private static EnumSet<ProfileField> myEnum = EnumSet.allOf(ProfileField.class);
	private User loggedInUser = null;
	private String apiKey;
	private String secretKey;
	private FacebookUpdateListener callback;

	public FriendRetriever(String apiKey, String sessionKey, String secretSessionKey) {
		secretKey = secretSessionKey;
		client = new FacebookJaxbRestClient(apiKey, secretSessionKey, sessionKey);
		this.apiKey = apiKey;
		client.setIsDesktop(true);
	}

	private List<User> getFriends(User u) throws FacebookException, IOException {
		FriendsGetResponse friendsResp = (FriendsGetResponse) client.friends_get(u.getUid());
		client.users_getInfo(friendsResp.getUid(), myEnum);
		UsersGetInfoResponse uresp = (UsersGetInfoResponse) client.getResponsePOJO();
		return uresp.getUser();
	}

	private User getLoggedUser() throws FacebookException, IOException {
		if (loggedInUser == null) {
			long loggedInUserId = client.users_getLoggedInUser();
			Collection<Long> users = new ArrayList<Long>();
			users.add(loggedInUserId);
			client.users_getInfo(users, myEnum);
			UsersGetInfoResponse u = (UsersGetInfoResponse) client.getResponsePOJO();
			loggedInUser = u.getUser().get(0);
		}
		return loggedInUser;
	}

	public void getFriendsUpdate(FacebookUpdateListener listener) {
		this.callback = listener;
		try {
			sendUpdatePerformed(client.getCacheSessionKey(), secretKey);
		} catch (FacebookException e) {
			SessionRetriever.getNewSession(this,apiKey);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void tryAgain(String sessionKey, String secretSessionKey) {
		secretKey = secretSessionKey;
		client = new FacebookJaxbRestClient(apiKey, secretSessionKey, sessionKey);
		try {
			sendUpdatePerformed(sessionKey, secretSessionKey);
		} catch (FacebookException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void sendUpdatePerformed(String sessionKey, String secretSessionKey) throws FacebookException, IOException {
		Friends friends = new Friends(getFriends(getLoggedUser()));
		friends.secretSessionKey = secretSessionKey;
		friends.sessionKey = sessionKey;
		callback.updatePerformed(friends);
	}
}
