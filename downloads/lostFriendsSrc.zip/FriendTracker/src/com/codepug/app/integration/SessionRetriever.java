/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app.integration;

import java.awt.event.WindowEvent;

import javax.swing.BoxLayout;
import javax.swing.JFrame;

import org.lobobrowser.gui.BrowserPanel;
import org.lobobrowser.gui.FramePanel;
import org.lobobrowser.gui.ResponseEvent;
import org.lobobrowser.gui.ResponseListener;
import org.lobobrowser.html.domimpl.HTMLDocumentImpl;
import org.lobobrowser.main.PlatformInit;

import com.codepug.app.iface.IFacebook;

class SessionRetriever extends JFrame {
	private static final long serialVersionUID = 9084450251685876037L;
	private static final String BASE_URL = "http://www.facebook.com/login.php";
	private static final String NEXT_URL = "http://www.facebook.com/connect/login_success.html";
	private IFacebook caller;
	
	public static void getNewSession(IFacebook caller,String API_KEY) {

		// This step is necessary for extensions (including HTML) to work:
		try {
			PlatformInit.getInstance().init(false, false);

			// Create window with a specific size.
			JFrame frame = new SessionRetriever("Facebook Login", buildURL(API_KEY),caller);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.setSize(600, 400);
			frame.setVisible(true);
		} catch (Exception e) {
				// Do nothing
		}
	}

	private static String buildURL(String API_KEY) {
		StringBuilder sb = new StringBuilder();
		sb.append(BASE_URL);
		sb.append("?api_key=").append(API_KEY);
		sb.append("&connect_display=").append("popup");
		sb.append("&v=").append("1.0");
		sb.append("&next=").append(NEXT_URL);
		sb.append("&fbconnect=").append("true");
		sb.append("&return_session=").append("true");
		sb.append("&session_key_only=").append("true");
		return sb.toString();
	}

	public SessionRetriever(String title, String url, IFacebook caller) throws Exception {
		this.setTitle(title);
		this.caller = caller;
		
		// Create a BrowserPanel and set a default home page.
		final BrowserPanel bp = new BrowserPanel();
		bp.navigate(url);

		// Add a response listener.
		bp.addResponseListener(new LocalResponseListener());

		// Add top-level components to window.
		this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
		this.add(bp);

		this.addWindowListener(new java.awt.event.WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				bp.windowClosing();
			}
		});
	}

	private class LocalResponseListener implements ResponseListener {

		@Override
		public void responseProcessed(ResponseEvent event) {
			FramePanel p = (FramePanel) event.getSource();
			HTMLDocumentImpl doc = null;
			while (doc == null) {
				doc = (HTMLDocumentImpl) p.getContentObject();
			}
			if (doc != null) {
				System.err.println("Found:" + doc.getDocumentURL());
				String url = doc.getDocumentURL().toString();
				if (url.startsWith(NEXT_URL)) {
					String sessionKey = getParameter(url,
							"session_key%22%3A%22");
					String sessionSecretKey = getParameter(url,
							"secret%22%3A%22");
					System.err.println(sessionKey + " " + sessionSecretKey);
					p.closeWindow();
					if (caller != null){
						caller.tryAgain(sessionKey, sessionSecretKey);
					}
				}
			}
		}
	}

	private String getParameter(String url, String param) {
		int pos = url.indexOf(param) + param.length();
		String value = url.substring(pos, url.length());
		value = value.substring(0, value.indexOf("%22"));
		return value;
	}
}
