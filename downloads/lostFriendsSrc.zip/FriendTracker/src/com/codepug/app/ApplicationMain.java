/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import com.codepug.app.friend.FriendFilter;
import com.codepug.app.friend.FriendSort;
import com.codepug.app.friend.Friends;
import com.codepug.app.iface.FacebookUpdateListener;
import com.codepug.app.iface.IFacebook;
import com.codepug.app.integration.FriendRetriever;
import com.codepug.app.swing.AppPanel;

public class ApplicationMain extends AppPanel implements FacebookUpdateListener {
	private static final long serialVersionUID = 8020992811041511125L;
	private static final String API_KEY = "60896191ffa82d4c58b10691a692398b";
	private static final String PROP_FILE = "friends2.txt";
	private static final String APP_TITLE = "CodePug.com - Find Lost Facebook Friends";
	private PropertyCoordinator prop;

	private String SESSION_KEY;
	private String SECRET_SESSION_KEY;

	private IFacebook so;
	private Friends friends;
	private FriendSort sort;

	public static void main(String[] args) throws Exception {
		new ApplicationMain();
	}

	public ApplicationMain() {
		initFrame(this, APP_TITLE, 417, 370);
		prop = new PropertyCoordinator(PROP_FILE);
		jtfEmail.setText(prop.get("EMAIL"));
		jtfPassword.setText(prop.get("PASSWORD"));
		friends = new Friends(prop.get("FRIENDS"));
		SESSION_KEY = prop.get("SESSION_KEY");
		SECRET_SESSION_KEY = prop.get("SECRET_SESSION_KEY");
		sort = FriendSort.BY_NAME;
		sort.updateTable(friends.getFilteredFriends(), jtaResults.getModel());
		setColumnWidth(0, 200);
		so = new FriendRetriever(API_KEY, SESSION_KEY, SECRET_SESSION_KEY);
	}

	private void setColumnWidth(int vColIndex, int width) {
		TableColumn col = jtaResults.getColumnModel().getColumn(vColIndex);
		col.setPreferredWidth(width);
	}

	private void initFrame(JPanel content, String title, int width, int height) {
		JFrame f = new JFrame(title);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(width, height);
		f.add(content);
		f.setVisible(true);
		jrbAll.setSelected(true);
		addSortableColumnListener(jtaResults);
	}

	private void addSortableColumnListener(JTable table) {
		JTableHeader header = table.getTableHeader();

		header.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JTableHeader h = (JTableHeader) e.getSource();
				int nColumn = h.columnAtPoint(e.getPoint());

				if (nColumn != -1)
					sortColumn(nColumn, h.getTable().getModel());
			}

			void sortColumn(int nColumn, TableModel model) {
				System.err.println("Sorting col: " + nColumn);
				jtaResults.clearSelection();
				if (nColumn == 0) {
					sort = FriendSort.BY_NAME;
					sort.updateTable(friends.getFilteredFriends(), model);
				} else if (nColumn == 1) {
					sort = FriendSort.BY_DATE_START;
					sort.updateTable(friends.getFilteredFriends(), model);
				} else if (nColumn == 2) {
					sort = FriendSort.BY_DATE_END;
					sort.updateTable(friends.getFilteredFriends(), model);
				}
			}
		});
	}

	@Override
	protected void jbExitActionPerformed(java.awt.event.ActionEvent evt) {
		saveFields();
		System.exit(0);
	}

	@Override
	protected void jbConnectActionPerformed(java.awt.event.ActionEvent evt) {
//		try {
//			alert("Connecting to facebook to retrieve data...");
			so.getFriendsUpdate(this);
//		} catch (Exception e) {
//			alert("Technical difficulty.  Sorry!" + e.getMessage());
//		}
	}

	public void updatePerformed(Friends updatedFriends){
		friends.setDateEnd(updatedFriends);
		friends.setDateStart(updatedFriends);
		friends = friends.add(updatedFriends);
		sort.updateTable(friends.getFilteredFriends(), jtaResults.getModel());

		SESSION_KEY = updatedFriends.sessionKey;
		SECRET_SESSION_KEY = updatedFriends.secretSessionKey;
		saveFields();
	}
	
	@Override
	protected void jrbAllActionPerformed(java.awt.event.ActionEvent evt) {
		jtaResults.clearSelection();
		friends.FILTER = FriendFilter.RETURN_ALL;
		sort.updateTable(friends.getFilteredFriends(), jtaResults.getModel());
	}

	@Override
	protected void jrbAddedActionPerformed(java.awt.event.ActionEvent evt) {
		jtaResults.clearSelection();
		friends.FILTER = FriendFilter.RETURN_ADDED;
		sort.updateTable(friends.getFilteredFriends(), jtaResults.getModel());
	}

	@Override
	protected void jrbRemovedActionPerformed(java.awt.event.ActionEvent evt) {
		jtaResults.clearSelection();
		friends.FILTER = FriendFilter.RETURN_REMOVED;
		sort.updateTable(friends.getFilteredFriends(), jtaResults.getModel());
	}

	private void saveFields() {
//		prop.set("EMAIL", jtfEmail);
//		prop.set("PASSWORD", jtfPassword);
		prop.set("FRIENDS", friends.toString());
		prop.set("SESSION_KEY", SESSION_KEY);
		prop.set("SECRET_SESSION_KEY", SECRET_SESSION_KEY);
		prop.save();
	}

	private void alert(String msg) {
		System.err.println(msg);
		// jtaResults.setText(msg);
	}
}
