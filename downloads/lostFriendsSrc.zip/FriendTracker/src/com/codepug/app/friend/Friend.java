/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app.friend;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.google.code.facebookapi.schema.User;

public class Friend {

	private static final String DELIMETER = ",";
	private static final String EMPTY_DATE = "00-00-00";
	private static final SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yy");

	private String uid;
	private String name;
	private String dateStart;
	private String dateEnd;

	public Friend(User user) {
		uid = "" + user.getUid();
		name = user.getName();
		setDateStart();
	}

	/**
	 * Restore User list from props file
	 * 
	 * @param data
	 */
	public Friend(String name, String uid, String dateStart, String dateEnd) {
		this.name = name;
		this.uid = uid;
		this.dateStart = dateStart;
		this.dateEnd = dateEnd;
	}

	public static Friend getEmptyFriend(String uid) {
		return new Friend("EMPTY_NAME", uid, EMPTY_DATE, EMPTY_DATE);
	}

	public boolean isDateEndSet(){
		return !EMPTY_DATE.equals(dateEnd);
	}
	
	public boolean isDateStartRecent(){
		boolean result = false;
		Calendar now = Calendar.getInstance();
		now.add(Calendar.MONTH,-1);
		try {
			Date date = formatter.parse(dateStart);
			result = date.after(now.getTime());
		} catch (ParseException e) {
			// Do nothing
		}
		return result;
	}
	
	public String getStringRepresentation() {
		StringBuffer sb = new StringBuffer();
		sb.append(name).append(DELIMETER);
		sb.append(uid).append(DELIMETER);
		sb.append(dateStart).append(DELIMETER);
		sb.append(dateEnd).append(DELIMETER);
		return sb.toString();
	}

	public String getUid() {
		return uid;
	}

	public String getName() {
		return name;
	}

	public String getDateStart() {
		return dateStart;
	}

	public String getDateEnd() {
		return dateEnd;
	}

	public Object[] getRow() {
		List<String> list = new ArrayList<String>();
		list.add(name);
		list.add(dateStart);
		list.add(dateEnd.equals(EMPTY_DATE) ? "" : dateEnd);
		return list.toArray();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj != null && obj instanceof Friend) {
			return ((Friend) obj).uid.equals(uid);
		}
		return false;
	}

	@Override
	public int hashCode() {
		return uid.hashCode();
	}

	@Override
	public String toString() {
		return getStringRepresentation();
	}

	public void setDateStart() {
		dateStart = formatter.format(new Date());
		dateEnd = EMPTY_DATE;
	}

	public void setDateEnd() {
		if (!isDateEndSet()){
			dateEnd = formatter.format(new Date());
		}
	}
	public void resetDateEnd() {
		dateEnd = EMPTY_DATE;
	}
}
