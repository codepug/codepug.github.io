/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app.friend;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;


public class FriendFilter {
	public static final FriendFilter RETURN_ALL = new FriendFilter();

	private FriendFilter() {
		// Do nothing
	}
	
	public static final FriendFilter RETURN_ADDED = new FriendFilter() {
		@Override
		public List getFilteredFriends(Collection friends) {
			List result = new ArrayList();
			Iterator<Friend> iter = friends.iterator();
			while (iter.hasNext()) {
				Friend f = iter.next();
				if (f.isDateStartRecent()) {
					result.add(f);
				}
			}
			return result;
		}
	};
	public static final FriendFilter RETURN_REMOVED = new FriendFilter() {
		@Override
		public List getFilteredFriends(Collection friends) {
			System.err.println("Lost");
			List result = new ArrayList();
			Iterator<Friend> iter = friends.iterator();
			while (iter.hasNext()) {
				Friend f = iter.next();
				if (f.isDateEndSet()) {
					result.add(f);
				}
			}
			return result;
		}
	};

	public List getFilteredFriends(Collection friends) {
		return new ArrayList(friends);
	}
}
