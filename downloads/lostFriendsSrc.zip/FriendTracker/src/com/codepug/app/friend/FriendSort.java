/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app.friend;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class FriendSort {
	public static final FriendSort BY_NAME = new FriendSort(new FriendNameComparator());
	public static final FriendSort BY_DATE_START = new FriendSort(new FriendDateStartComparator());
	public static final FriendSort BY_DATE_END = new FriendSort(new FriendDateEndComparator());

	private final Comparator comparator;

	public FriendSort(Comparator comparator) {
		this.comparator = comparator;
	}

	private List<Friend> sort(Collection listOfFriends) {
		List<Friend> list = new ArrayList(listOfFriends);
		Collections.sort(list, comparator);
		return list;
	}

	/*
	 * Usage: updateTable((DefaultTableModel)jtaResults.getModel());
	 */
	public void updateTable(List list, TableModel model) {
		clearTable(model);
		Iterator<Friend> iter = sort(list).iterator();
		while (iter.hasNext()) {
			((DefaultTableModel) model).addRow(iter.next().getRow());
		}
		((DefaultTableModel) model).fireTableDataChanged();
	}

	private void clearTable(TableModel model) {
		((DefaultTableModel) model).getDataVector().removeAllElements();
	}

	private static class FriendNameComparator implements Comparator<Friend> {
		@Override
		public int compare(Friend friend1, Friend friend2) {
			return friend1.getName().compareTo(friend2.getName());
		}
	}

	private static class FriendDateEndComparator implements Comparator<Friend> {

		@Override
		public int compare(Friend friend1, Friend friend2) {
			return friend1.getDateEnd().compareTo(friend2.getDateEnd());
		}
	}

	private static class FriendDateStartComparator implements Comparator<Friend> {

		@Override
		public int compare(Friend friend1, Friend friend2) {
			return friend1.getDateStart().compareTo(friend2.getDateStart());
		}
	}
}
