/********************************************
 *  @site http://www.codePug.com
 *  @version 2009.0217
 ********************************************/
package com.codepug.app.friend;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.google.code.facebookapi.schema.User;

public class Friends {

	private static final String DELIMETER = ",";
	private Set<Friend> friends;
	public FriendFilter FILTER = FriendFilter.RETURN_ALL;
	public String sessionKey;
	public String secretSessionKey;

	public Friends() {
		friends = new LinkedHashSet<Friend>();
	}

	public Friends(List<User> users) {
		this();
		Iterator<User> i = users.iterator();
		while (i.hasNext()) {
			this.friends.add(new Friend(i.next()));
		}
	}

	/**
	 * Restore User list from props file
	 * 
	 * @param data
	 */
	public Friends(String stringRepresentation) {
		this();
		Friend user;
		String[] dataArray = stringRepresentation.split(DELIMETER);
		for (int i = 0; i < dataArray.length && dataArray.length > 1; i += 4) {
			user = new Friend(dataArray[i], dataArray[i + 1], dataArray[i + 2], dataArray[i + 3]);
			friends.add(user);
		}
	}

	public void setDateEnd(Friends newFriendsList) {
		Iterator<Friend> iter = friends.iterator();
		while (iter.hasNext()) {
			Friend f = iter.next();
			if (!newFriendsList.friends.contains(f)) {
				f.setDateEnd();
			} else {
				f.resetDateEnd();
			}
		}
	}

	public void setDateStart(Friends newFriendsList) {
		Iterator<Friend> iter = newFriendsList.friends.iterator();
		while (iter.hasNext()) {
			Friend f = iter.next();
			if (!friends.contains(f)) {
				f.setDateStart();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public List<Friend> getFilteredFriends() {
		return FILTER.getFilteredFriends(friends);
	}

	public Friends add(Friends friendsToAdd) {
		friends.addAll((Set<Friend>) friendsToAdd.friends);
		return this;
	}

	public int size() {
		return friends.size();
	}

	public String getStringRepresentation() {
		StringBuffer sb = new StringBuffer();
		Iterator<Friend> i = friends.iterator();
		while (i.hasNext()) {
			sb.append(i.next().toString());
		}
		return sb.toString();
	}

	public String toString() {
		return getStringRepresentation();
	}

	public String getUidByName(String name) {
		String result = "";
		Iterator<Friend> i = friends.iterator();
		while (i.hasNext()) {
			Friend f = i.next();
			if (name.equals(f.getName())) {
				result = f.getUid();
			}
		}
		return result;
	}
}
