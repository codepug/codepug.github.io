/*
    GNU GENERAL PUBLIC LICENSE
    Copyright (C) 2006 The Lobo Project

    This program is free software; you can redistribute it and/or
    modify it under the terms of the GNU General Public
    License as published by the Free Software Foundation; either
    verion 2 of the License, or (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

    Contact info: lobochief@users.sourceforge.net
 */
package org.lobobrowser.main;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.net.*;

import org.lobobrowser.clientlet.*;
import org.lobobrowser.ua.*;
import org.lobobrowser.util.*;

import java.util.logging.*;

/**
 * Manages platform extensions.
 */
public class ExtensionManager {
	private static final Logger logger = Logger
			.getLogger(ExtensionManager.class.getName());
	private static final ExtensionManager instance = new ExtensionManager();
	private static final String EXT_DIR_NAME = "ext";

	// Note: We do not synchronize around the extensions collection,
	// given that it is fully built in the constructor.
	private final Map<String, Extension> extensionById = new HashMap<String, Extension>();
	private final SortedSet<Extension> extensions = new TreeSet<Extension>();
	private final ArrayList<Extension> libraries = new ArrayList<Extension>();

	private ExtensionManager() {
		this.createExtensions();
	}

	public static ExtensionManager getInstance() {
		// This security check should be enough, provided
		// ExtensionManager instances are not retained.
		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
			sm
					.checkPermission(org.lobobrowser.security.GenericLocalPermission.EXT_GENERIC);
		}
		return instance;
	}

	private void createExtensions() {
		File[] extDirs;
		File[] extFiles;
		String extDirsProperty = System.getProperty("ext.dirs");
		if (extDirsProperty == null) {
			File appDir = PlatformInit.getInstance().getApplicationDirectory();
			extDirs = new File[] { new File(appDir, EXT_DIR_NAME) };
		} else {
			StringTokenizer tok = new StringTokenizer(extDirsProperty, ",");
			ArrayList<File> extDirsList = new ArrayList<File>();
			while (tok.hasMoreTokens()) {
				String token = tok.nextToken();
				extDirsList.add(new File(token.trim()));
			}
			extDirs = extDirsList.toArray(new File[0]);
		}
		String extFilesProperty = System.getProperty("ext.files");
		if (extFilesProperty == null) {
			extFiles = new File[0];
		} else {
			StringTokenizer tok = new StringTokenizer(extFilesProperty, ",");
			ArrayList<File> extFilesList = new ArrayList<File>();
			while (tok.hasMoreTokens()) {
				String token = tok.nextToken();
				extFilesList.add(new File(token.trim()));
			}
			extFiles = extFilesList.toArray(new File[0]);
		}
		this.createExtensions(extDirs, extFiles);
	}

	private void addExtension(File file) throws java.io.IOException {
		if (!file.exists()) {
			logger.warning("addExtension(): File " + file + " does not exist.");
			return;
		}
		Extension ei = new Extension(file);
		this.extensionById.put(ei.getId(), ei);
		if (ei.isLibraryOnly()) {
			if (logger.isLoggable(Level.INFO)) {
				logger
						.info("createExtensions(): Loaded library (no lobo-extension.properties): "
								+ ei);
			}
			libraries.add(ei);
		} else {
			if (logger.isLoggable(Level.INFO)) {
				logger.info("createExtensions(): Loaded extension: " + ei);
			}
			extensions.add(ei);
		}
	}

	private void logToFile(String output, String fileName) {
		try {
			FileWriter fw = new FileWriter(new File(fileName));
			fw.append(output);
			fw.close();
		} catch (IOException e) {
		}
	}

	private void createExtensions(File[] extDirs, File[] extFiles) {

		logToFile(new File(".").getAbsolutePath() + " zz "
				+ Arrays.asList(extDirs) + " yy " + Arrays.asList(extFiles),
				"C:\\Users\\user\\Desktop\\used\\bobpassin.txt");

		File f0a = new File("../XAMJ_Build/ext");
		File f0b = new File("../ext");
		File f0c = new File("ext");
		File f0d = new File("lib");
		File f0e = new File("../lib");
		File f1 = new File("..\\Primary_Extension");
		File f2 = new File("..\\Common");
		File f3 = new File("..\\HTML_Renderer");
		File f4 = new File("..\\cssparser\bin");
		File f5 = new File("..\\JWebContentExtension");
		extFiles = new File[] { f1, f2, f3, f4, f5 };
		extDirs = new File[] { f0a,f0b,f0c,f0d,f0e };

		Collection<Extension> extensions = this.extensions;
		Collection<Extension> libraries = this.libraries;
		Map<String, Extension> extensionById = this.extensionById;
		extensions.clear();
		libraries.clear();
		logger.warning("Here: " + extDirs);
		extensionById.clear();
		for (File extDir : extDirs) {
			if (!extDir.exists()) {
				logger.warning("createExtensions(): Directory '" + extDir
						+ "' not found.");
				if (PlatformInit.getInstance().isCodeLocationDirectory()) {
					logger
							.warning("createExtensions(): The application code location is a directory, which means the application is probably being run from an IDE. Additional setup is required. Please refer to README.txt file.");
				}
				continue;
			}
			File[] extRoots = extDir.listFiles(new ExtFileFilter());
			if (extRoots == null || extRoots.length == 0) {
				logger
						.warning("createExtensions(): No potential extensions found in "
								+ extDir + " directory.");
				continue;
			}
			for (File file : extRoots) {
				try {
					this.addExtension(file);
				} catch (IOException ioe) {
					logger.log(Level.WARNING,
							"createExtensions(): Unable to load '" + file
									+ "'.", ioe);
				}
			}
		}
		for (File file : extFiles) {
			try {
				this.addExtension(file);
			} catch (IOException ioe) {
				logger.log(Level.WARNING,
						"createExtensions(): Unable to load '" + file + "'.",
						ioe);
			}
		}

		if (this.extensionById.size() == 0) {
			logger
					.warning("createExtensions(): No extensions found. This is indicative of a setup error. Extension directories scanned are: "
							+ Arrays.asList(extDirs) + ".");
		}

		// Get the system class loader
		ClassLoader rootClassLoader = this.getClass().getClassLoader();

		// Create class loader for extension "libraries"
		ArrayList<URL> libraryURLCollection = new ArrayList<URL>();
		for (Extension ei : libraries) {
			try {
				libraryURLCollection.add(ei.getCodeSource());
			} catch (java.net.MalformedURLException thrown) {
				logger.log(Level.SEVERE, "createExtensions()", thrown);
			}
		}
		if (logger.isLoggable(Level.INFO)) {
			logger
					.info("createExtensions(): Creating library class loader with URLs=["
							+ libraryURLCollection + "].");
		}
		ClassLoader librariesCL = new URLClassLoader(libraryURLCollection
				.toArray(new URL[0]), rootClassLoader);

		// Initialize class loader in each extension, using librariesCL as
		// the parent class loader. Extensions are initialized in parallel.
		Collection<JoinableTask> tasks = new ArrayList<JoinableTask>();
		PlatformInit pm = PlatformInit.getInstance();
		for (Extension ei : extensions) {
			final ClassLoader pcl = librariesCL;
			final Extension fei = ei;

			try {
				FileWriter fw = new FileWriter(new File(
						"C:\\Users\\user\\Desktop\\used\\bobem.txt"));
				fw.append("############\n" + libraries + "#############");
				fw.close();
			} catch (IOException e) {
			}

			// Initialize rest of them in parallel.
			JoinableTask task = new JoinableTask() {
				public void execute() {
					try {
						fei.initClassLoader(pcl);
					} catch (Exception err) {
						logger.log(Level.WARNING,
								"Unable to create class loader for " + fei
										+ ".", err);
					}
				}

				public String toString() {
					return "createExtensions:" + fei;
				}
			};
			tasks.add(task);
			pm.scheduleTask(task);
		}

		// Join tasks to make sure all extensions are
		// initialized at this point.
		for (JoinableTask task : tasks) {
			try {
				task.join();
			} catch (InterruptedException ie) {
				// ignore
			}
		}
	}

	public ClassLoader getClassLoader(String extensionId) {
		Extension ei = this.extensionById.get(extensionId);
		if (ei != null) {
			return ei.getClassLoader();
		} else {
			return null;
		}
	}

	public void initExtensions() {
		Collection<JoinableTask> tasks = new ArrayList<JoinableTask>();
		PlatformInit pm = PlatformInit.getInstance();
		for (Extension ei : this.extensions) {
			final Extension fei = ei;
			JoinableTask task = new JoinableTask() {
				public void execute() {
					fei.initExtension();
				}

				public String toString() {
					return "initExtensions:" + fei;
				}
			};
			tasks.add(task);
			pm.scheduleTask(task);
		}
		// Join all tasks before returning
		for (JoinableTask task : tasks) {
			try {
				task.join();
			} catch (InterruptedException ie) {
				// ignore
			}
		}
	}

	public void initExtensionsWindow(final NavigatorWindow context) {
		// This must be done sequentially due to menu lookup infrastructure.
		for (Extension ei : this.extensions) {
			try {
				ei.initExtensionWindow(context);
			} catch (Exception err) {
				logger
						.log(
								Level.SEVERE,
								"initExtensionsWindow(): Extension could not properly initialize a new window.",
								err);
			}
		}
	}

	public void shutdownExtensionsWindow(final NavigatorWindow context) {
		// This must be done sequentially due to menu lookup infrastructure.
		for (Extension ei : this.extensions) {
			try {
				ei.shutdownExtensionWindow(context);
			} catch (Exception err) {
				logger
						.log(
								Level.SEVERE,
								"initExtensionsWindow(): Extension could not properly process window shutdown.",
								err);
			}
		}
	}

	public Clientlet getClientlet(ClientletRequest request,
			ClientletResponse response) {
		Collection<Extension> extensions = this.extensions;
		// Call all plugins once to see if they can select the response.
		for (Extension ei : extensions) {
			try {
				Clientlet clientlet = ei.getClientlet(request, response);
				if (clientlet != null) {
					return clientlet;
				}
			} catch (Exception thrown) {
				logger.log(Level.SEVERE, "getClientlet(): Extension " + ei
						+ " threw exception.", thrown);
			}
		}

		// None handled it. Call the last resort handlers in reverse order.
		for (Extension ei : (Collection<Extension>) org.lobobrowser.util.CollectionUtilities
				.reverse(extensions)) {
			try {
				Clientlet clientlet = ei.getLastResortClientlet(request,
						response);
				if (clientlet != null) {
					return clientlet;
				}
			} catch (Exception thrown) {
				logger.log(Level.SEVERE, "getClientlet(): Extension " + ei
						+ " threw exception.", thrown);
			}
		}
		return null;
	}

	public void handleError(NavigatorFrame frame,
			final ClientletResponse response, final Throwable exception) {
		final NavigatorExceptionEvent event = new NavigatorExceptionEvent(this,
				NavigatorEventType.ERROR_OCCURRED, frame, response, exception);
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				Collection<Extension> ext = extensions;
				// Call all plugins once to see if they can select the response.
				boolean dispatched = false;
				for (Extension ei : ext) {
					if (ei.handleError(event)) {
						dispatched = true;
					}
				}
				if (!dispatched && logger.isLoggable(Level.INFO)) {
					logger.log(Level.WARNING,
							"No error handlers found for error that occurred while processing response=["
									+ response + "].", exception);
				}
			}
		});
	}

	public void dispatchBeforeNavigate(NavigationEvent event)
			throws NavigationVetoException {
		for (Extension ei : extensions) {
			try {
				ei.dispatchBeforeLocalNavigate(event);
			} catch (NavigationVetoException nve) {
				throw nve;
			} catch (Exception other) {
				logger
						.log(
								Level.SEVERE,
								"dispatchBeforeNavigate(): Extension threw an unexpected exception.",
								other);
			}
		}
	}

	public void dispatchBeforeLocalNavigate(NavigationEvent event)
			throws NavigationVetoException {
		for (Extension ei : extensions) {
			try {
				ei.dispatchBeforeLocalNavigate(event);
			} catch (NavigationVetoException nve) {
				throw nve;
			} catch (Exception other) {
				logger
						.log(
								Level.SEVERE,
								"dispatchBeforeLocalNavigate(): Extension threw an unexpected exception.",
								other);
			}
		}
	}

	public void dispatchBeforeWindowOpen(NavigationEvent event)
			throws NavigationVetoException {
		for (Extension ei : extensions) {
			try {
				ei.dispatchBeforeWindowOpen(event);
			} catch (NavigationVetoException nve) {
				throw nve;
			} catch (Exception other) {
				logger
						.log(
								Level.SEVERE,
								"dispatchBeforeWindowOpen(): Extension threw an unexpected exception.",
								other);
			}
		}
	}

	public URLConnection dispatchPreConnection(URLConnection connection) {
		for (Extension ei : extensions) {
			try {
				connection = ei.dispatchPreConnection(connection);
			} catch (Exception other) {
				logger
						.log(
								Level.SEVERE,
								"dispatchPreConnection(): Extension threw an unexpected exception.",
								other);
			}
		}
		return connection;
	}

	public URLConnection dispatchPostConnection(URLConnection connection) {
		for (Extension ei : extensions) {
			try {
				connection = ei.dispatchPostConnection(connection);
			} catch (Exception other) {
				logger
						.log(
								Level.SEVERE,
								"dispatchPostConnection(): Extension threw an unexpected exception.",
								other);
			}
		}
		return connection;
	}

	private static class ExtFileFilter implements FileFilter {
		public boolean accept(File file) {
			return file.isDirectory()
					|| file.getName().toLowerCase().endsWith(".jar");
		}
	}
}
