// <applet code="TAApplet" width=300 height=300></applet>
import java.awt.*;
import java.applet.*;

public class TAApplet extends Applet {
	Button button1;
	TextArea ta;
	TextField tf;

	public void init(){
		// Create and add the user interface components
		button1 = new Button("Process");
		ta  = new TextArea(5,40);
		tf = new TextField(20);
		add(ta);
		add(tf);
		add(button1);

		// Enter two lines of text into the TextArea
		ta.setText("Enter stuff here\n and here\n");
		setBackground(Color.red);
	}

	public boolean action(Event evt, Object arg){
		// React to button1 being pressed & change the TextArea
		if (evt.target == button1)
			ta.setText("Thanks for clicking that.\n Have a nice day!");
		if (evt.target == tf)
		    ta.setText("Thanks for pressing return.\n Have a nice day!");

		return true;
	}
} 
