//<applet code="SmileySound" width=400 height=400></applet>
import java.awt.*;
import java.applet.*;
public class SmileySound extends Applet {
	int a;
	int b;
	boolean bob;
	AudioClip ac;
public void init(){ 
	setBackground(Color.green);
	ac = getAudioClip(getCodeBase(),"zoinks.wav");
	a=0;
	b=0;
	bob = false;
}
public boolean mouseDown(Event evt, int x, int y){
	a=x-50;
	b=y-50;
	ac.play();
	bob = true;
	repaint();
	return true;	
}
public boolean mouseUp(Event evt, int x, int y){
	bob = false;
	repaint();
	return true;
}
public void update(Graphics g){paint(g);}
public void paint(Graphics g){
	if (bob)
		g.setColor(Color.red);
	else
		g.setColor(Color.yellow);
	g.fillOval(a,b,50,50);

	g.setColor(Color.black);
	g.drawOval(a,b,50,50);
	g.fillOval(a+11,b+10,9,9);
	g.fillOval(a+32,b+10,9,9);
	g.drawArc(a+11,b+10,30,30,190,160);
}}