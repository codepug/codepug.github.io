//<applet code="HelloWorld" width=200 height=70></applet>
import java.io.*;
import java.awt.*;
import java.applet.*;

public class HelloWorld extends Applet {
	int x=0;

public void init(){
	
}

public boolean keyDown(Event evt, int key){
	x++;
	repaint();
	return true;
}

public void paint(Graphics g){
	g.drawString("Please click here and begin typing.",10,35);
	g.drawString("# of keys pressed: "+x,10,50);
}

} // end class

