// <applet code="HelloWorld" width="300" height="100">
import java.awt.*;
import java.applet.*;


public class HelloWorld extends Applet{
	int hamsterBiteCount;

public void init(){
	hamsterBiteCount=5;
}

public boolean keyDown(Event evt, int key){
	hamsterBiteCount++;
	repaint();
	return true;
}

public void paint(Graphics g){
g.drawString("My pet hamster wants to bite you "
+hamsterBiteCount +" times.",20,40);

}

}

