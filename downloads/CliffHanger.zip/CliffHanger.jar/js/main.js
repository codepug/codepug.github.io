 var nick = [];
for (var i=0;i<8;i++){
    nick.push(awt.getImage('res/'+i+'.gif'));
}
 var fallImg = awt.getImage('res/fallguy.gif');
 var stats = awt.getImage('res/trial.jpg');
 var xpos, ypos,trialComplete,characterImgIndex;
 var winsNum=0, losesNum=0, forwardNum=0, backNum=0;
 var trialComplete = false;
 
 var soundSprite = new AudioSprite("res/AllAudioClips.mp3", [ { start: 0.1, length: 3400 }, { start: 3701, length: 1012 } ]); 

 
 reset();
 function reset(){
   xpos = 250;
   ypos = 14;
   forwardNum = 0;
   backNum = 0;
   trialComplete = false;
   characterImgIndex = 0;
 }
 
 function paint(ctx, timeDiff) {
	if (characterImgIndex > 6){
		characterImgIndex = 0;
	} else if (characterImgIndex > 0){
		characterImgIndex++;
	}

	if (trialComplete){
	    // To the left and losing
		if(ypos < 550 && xpos < 250){
			ypos+=10;
			xpos-=5;
			awt.drawImage(fallImg,xpos,ypos);
		}
		// To the right and winning
		if (xpos > 400){
			awt.drawStringAs("#FF0000",62,"You Win!",40,180);
		}
	} else {
		awt.drawImage(nick[characterImgIndex],xpos,ypos);
	}
	
	// Draw Stats
	awt.drawImage(stats,400,0);
	awt.drawString(winsNum+losesNum,490,30);
	awt.drawString(winsNum,490,68);
	awt.drawString(losesNum,490,94);
    awt.drawString(forwardNum,505,169);
	awt.drawString(backNum,505,186);
	awt.drawString(forwardNum+backNum,505,202);
}

function moveGuy(){
    if(trialComplete){
        return;
    }
    var move = Math.floor((Math.random() * 3) + 1); 
    if (move == 1){
      xpos-=10;
      forwardNum++;
    } else {
      xpos+=10;
      backNum++;
    }
    characterImgIndex++;
    checkIfWin();
}


function checkIfWin(){
	if (!trialComplete && xpos > 400) 
	{					// If win
		trialComplete = true;
		soundSprite.play(0);
		//winSnd.play();
		winsNum++;
	}	 

	if (!trialComplete && xpos < 250) 
	{					// If fall
		trialComplete = true;
		soundSprite.play(1);
		//loseSnd.play();
		losesNum++;
		xpos -= 10;
	}
}
