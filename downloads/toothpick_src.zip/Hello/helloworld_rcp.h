// Defines for the Hello world application

#define MainForm	1000
#define kidMenu1  1010
#define AboutForm 1200
#define kidOk 	1201
#define kidBitmap 1300
#define iconBitmap 1302
#define kidHelp1  1443
