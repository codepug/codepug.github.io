#include <System/SysAll.h>
#include <UI/UIAll.h>
#include "helloworld_rcp.h"

// Global Variables
int lastSelected;
int currentMax;
SWord 	pickx[50],
		picky[50];
Boolean	rotated[50];

Boolean penWasDown,
	  rotateNext;

	// Init()
	Boolean StartApplication(void) {
		reset();
  		FrmGotoForm(MainForm);
		repaint();
  		return false;
   	} 

	// Destroy()
	void StopApplication(void) {
	  	FrmCloseAllForms();
	} 

	void repaint() {
		int i = 0;
		drawString("Toothpick Box",3,23);
		drawString("# of Toothpicks: ", 3, 140);
		drawInt((currentMax+1), 73, 140);
	
		draw3DRect(1,21,65,18);
	
		// Draw All Toothpicks
		for (i=0;i<currentMax;i++){
			drawToothPick2(pickx[i],picky[i],i);


		}

		//WinDrawBitmap(kidBitmap,50,50);
		//DrawBitmap(0,0,kidBitmap);
	}

	int drawToothPick2(int x, int y, int z) {
		if (!rotated[z]) {
			WinDrawLine(x-9,y+1,x+9,y+1); 
			WinDrawLine(x-10,y,x+10,y); 
			WinDrawLine(x-9,y-1,x+9,y-1);
		} else {
			WinDrawLine(x+1,y-9,x+1,y+9); 
			WinDrawLine(x,y-10,x,y+10); 
			WinDrawLine(x-1,y-9,x-1,y+9);
		}
		return 0;
	}

	int drawToothPick(int x, int y, Boolean rotateIt) {
		if (!rotateIt) {
			WinDrawLine(x-9,y+1,x+9,y+1); 
			WinDrawLine(x-10,y,x+10,y); 
			WinDrawLine(x-9,y-1,x+9,y-1);
		} else {
			WinDrawLine(x+1,y-9,x+1,y+9); 
			WinDrawLine(x,y-10,x,y+10); 
			WinDrawLine(x-1,y-9,x-1,y+9);
		}
		return 0;
	}

	int eraseToothPick(int x, int y, Boolean rotateIt) {
		if (!rotateIt) {
			WinEraseLine(x-9,y+1,x+9,y+1); 
			WinEraseLine(x-10,y,x+10,y); 
			WinEraseLine(x-9,y-1,x+9,y-1);
		} else {
			WinEraseLine(x+1,y-9,x+1,y+9); 
			WinEraseLine(x,y-10,x,y+10); 
			WinEraseLine(x-1,y-9,x-1,y+9);
		}
		return 0;
	}

int mouseUp(){
	lastSelected = -1;
	repaint();
	return 0;
}

int mouseDown(SWord x, SWord y){
	if (rotateNext){
		if (moveObject(x,y)) {
			rotateNext = false;
			eraseToothPick(pickx[lastSelected],picky[lastSelected],rotated[lastSelected]);
			rotated[lastSelected] = !rotated[lastSelected];
			repaint();
			drawToothPick(pickx[lastSelected],picky[lastSelected],rotated[lastSelected]);
		}
		return 0;
	}

	if (moveObject(x,y)) {
		//drawToothPick(pickx[lastSelected],picky[lastSelected],rotated[lastSelected]);
		repaint();
		return 0;
	}

	if (y > 0 && y < 15)
		if (x > 140) {
			rotateNext = true;
			return 0;
		}

	if (x > 0 && x< 65)
		if (y > 20 && y < 38) {
			addPick(x,y);
			rotateNext = false;
		}
	repaint();
	return 0;
}

int mouseDrag(SWord x, SWord y){ 
	if (lastSelected >= 0) {
		eraseToothPick(pickx[lastSelected],picky[lastSelected],rotated[lastSelected]);
		pickx[lastSelected]=x;
		picky[lastSelected]=y;
		drawToothPick(pickx[lastSelected],picky[lastSelected],rotated[lastSelected]);
		repaint();
	}
	return 0;
}

int addPick(SWord x, SWord y){
	currentMax++;
	pickx[currentMax] = x;
	picky[currentMax] = y;
	rotated[currentMax] = false;
	lastSelected = currentMax;
	drawToothPick(pickx[lastSelected],picky[lastSelected],rotated[lastSelected]);
	return 0;
}

Boolean moveObject(SWord x, SWord y){
	int i=0;
	for (i=0;i<=currentMax;i++) {
		if (!rotated[i]){
			if (x > pickx[i]-10 && x< pickx[i]+10)
				if (y > picky[i]-2 && y < picky[i]+2){
					lastSelected = i;
					return true;
				}
		} else {
			if (y > picky[i]-10 && y< picky[i]+10)
				if (x > pickx[i]-2 && x < pickx[i]+2){
					lastSelected = i;
					return true;
				}
		}
	}
	lastSelected = -1;
	return false;
}

// draw a bitmap at x,y
// This function is not used directly, but we have made a 'wrapper' function to make it neater.
int DrawBitmap(Int x, Int y, Int id)
{
    VoidHand h;
    BitmapPtr p;
    h = DmGet1Resource('Tbmp', id);
    if (h != NULL) {
        p = (BitmapPtr) MemHandleLock(h);
        WinDrawBitmap(p, x, y);
        MemHandleUnlock(h);
        DmReleaseResource(h);
    }
	return 0;
}


void reset(){
	int i;
	currentMax 	 = -1;
	lastSelected = -1;
	penWasDown 	 = false;
	rotateNext 	 = false;
for (i=0;i<50;i++)
	rotated[i]=true;

}

// Event Handlers
	Boolean MainFormHandleEvent(EventPtr event) {
	  FormPtr frm;      
	  Boolean handled = false;
     	//  FrmDrawForm(frm);

	  switch (event->eType) {
	    	case frmOpenEvent:
	      	frm = FrmGetActiveForm();
		    	  FrmDrawForm(frm);
	      	handled = true;
			repaint();
	      	break;
		case penUpEvent:
			mouseUp();
			break;
		case penDownEvent:
				mouseDown(event->screenX,event->screenY);
			break;
		case penMoveEvent:
			if (event->screenY > 20 && event->screenY < 155)
				if (event->screenX > 3 && event->screenX < 154)
					mouseDrag(event->screenX,event->screenY);
			break;
		case menuEvent:
			switch (event->data.menu.itemID){
				case 5002:
					reset();
					clearScreenLower();
					repaint();
					break;
				case 5001:
				frm = FrmInitForm(AboutForm);
				FrmDoDialog(frm);
				FrmDeleteForm(frm);
				break;
			}
		break;
	  } // event->eType
	  return handled;
	} 

	Boolean ApplicationHandleEvent(EventPtr event) {
  		FormPtr frm;
  		Int     formId;
  		Boolean handled = false;

  		if (event->eType == frmLoadEvent) {
  	  		// get the form ID number
    			formId = event->data.frmLoad.formID;
   
			// load the form (get it's pointer)
    			frm = FrmInitForm(formId);
    
			// make the form active
    			FrmSetActiveForm(frm);

			switch (formId) {
				case MainForm:
			      FrmSetEventHandler(frm, MainFormHandleEvent);
	      		//FrmDrawForm(frm);
				//repaint();
			      break;
			}
		  	handled = true;
		}
		return handled;
	} 


// Palm Main()
	DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
	  	EventType event;
		Word error;


	  	if (cmd == sysAppLaunchCmdNormalLaunch) 
    			if (0 == StartApplication()) {
	      		do {
	        			EvtGetEvent(&event, evtWaitForever);
		        		if (!SysHandleEvent(&event)) 
						if (!MenuHandleEvent(0,&event,&error))
					          	// Check if the form was changed
          						if (!ApplicationHandleEvent(&event))
            						// Handle events for the current form
						            FrmDispatchEvent(&event);

		      	} while (event.eType != appStopEvent);
			      //StopApplication();
    			}
		return 0;
	} 
