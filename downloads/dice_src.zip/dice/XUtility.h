#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

void drawRect(int x, int y, int w, int h);
void draw3DRect(int x, int y, int w, int h); 
void checkPen();
void drawString(char c[],int x, int y);
void repaint();
void paint();
Boolean moveObject(SWord x, SWord y);
void reset();
void addPick(SWord x, SWord y);
void clearScreen();
void mouseDown(SWord x, SWord y);
void mouseDrag(SWord x, SWord y);
void mouseUp();
void drawInt(int num, int x, int y);
void clearScreenLower();


