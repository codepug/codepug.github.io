package com.codepug.loveCalc;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class KeyboardKey {
	public static KeyboardKey keyA = new KeyboardKey("A", 33, 146, 88, 182);
	public static KeyboardKey keyB = new KeyboardKey("B", 256, 187, 302, 223);
	public static KeyboardKey keyC = new KeyboardKey("C", 167, 187, 211, 223);
	public static KeyboardKey keyD = new KeyboardKey("D", 128, 146, 174, 182);
	public static KeyboardKey keyE = new KeyboardKey("E", 117, 103, 153, 141);
	public static KeyboardKey keyF = new KeyboardKey("F", 175, 146, 221, 182);
	public static KeyboardKey keyG = new KeyboardKey("G", 222, 146, 266, 182);
	public static KeyboardKey keyH = new KeyboardKey("H", 267, 146, 312, 182);
	public static KeyboardKey keyI = new KeyboardKey("I", 317, 103, 354, 141);
	public static KeyboardKey keyJ = new KeyboardKey("J", 313, 146, 347, 182);
	public static KeyboardKey keyK = new KeyboardKey("K", 348, 146, 393, 182);
	public static KeyboardKey keyL = new KeyboardKey("L", 394, 146, 451, 182);
	public static KeyboardKey keyM = new KeyboardKey("M", 351, 187, 401, 223);
	public static KeyboardKey keyN = new KeyboardKey("N", 303, 187, 350, 223);
	public static KeyboardKey keyO = new KeyboardKey("O", 355, 103, 402, 141);
	public static KeyboardKey keyP = new KeyboardKey("P", 403, 103, 451, 141);
	public static KeyboardKey keyQ = new KeyboardKey("Q", 33, 103, 74, 141);
	public static KeyboardKey keyR = new KeyboardKey("R", 153, 103, 191, 141);
	public static KeyboardKey keyS = new KeyboardKey("S", 89, 146, 127, 182);
	public static KeyboardKey keyT = new KeyboardKey("T", 192, 103, 230, 141);
	public static KeyboardKey keyU = new KeyboardKey("U", 273, 103, 316, 141);
	public static KeyboardKey keyV = new KeyboardKey("V", 212, 187, 255, 223);
	public static KeyboardKey keyW = new KeyboardKey("W", 74, 103, 117, 141);
	public static KeyboardKey keyX = new KeyboardKey("X", 115, 187, 166, 223);
	public static KeyboardKey keyY = new KeyboardKey("Y", 231, 103, 272, 141);
	public static KeyboardKey keyZ = new KeyboardKey("Z", 78, 187, 114, 223);
	public static KeyboardKey keySPACE = new KeyboardKey(" ", 187, 230, 312,263);
	public static KeyboardKey keyENTER = new KeyboardKey("\\n", 347, 227, 454,265);
	public static KeyboardKey keyDELETE = new KeyboardKey("\\d", 409, 64, 451, 100);

	public static KeyboardKey[] KEYS = new KeyboardKey[] { keyA, keyB, keyC,
			keyD, keyE, keyF, keyG, keyH, keyI, keyJ, keyK, keyL, keyM, keyN,
			keyO, keyP, keyQ, keyR, keyS, keyT, keyU, keyV, keyW, keyX, keyY,
			keyZ, keySPACE, keyENTER,keyDELETE };
	private int x, y, x1, y1;
	private String value;

	private KeyboardKey(String value, int x, int y, int x1, int y1) {
		this.x = x;
		this.y = y;
		this.x1 = x1;
		this.y1 = y1;
		this.value = value;
	}

	public static String getKeyAt(int inX, int inY) {
		String str = "";
		for (KeyboardKey key : KEYS) {
			if (inX > key.x && inX < key.x1) {
				if (inY > key.y && inY < key.y1) {
					System.err.println("hit" + key.value);
					str += key.value;
				}
			}
		}
		return str;
	}
}
