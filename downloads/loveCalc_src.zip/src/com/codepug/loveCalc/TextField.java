package com.codepug.loveCalc;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class TextField extends AbstractScreenControl {
	private int x, y, x1, y1;
	@SuppressWarnings("unused")
	private int cursorPosition;

	public TextField(int x, int y, int x1, int y1) {
		this.x = x;
		this.y = y;
		this.x1 = x1;
		this.y1 = y1;
		cursorPosition = x + 2;
		value = "";
		isActive = false;
		font = new Font("Arial", Font.PLAIN, 32);
	}

	public void paint(Graphics g) {
		if (isActive) {
			if ("".equals(value)){
				g.setColor(Color.black);
				g.setFont(font);
				g.drawString("|", x+5, y+30);
			}
//			g.drawLine(cursorPosition, y, cursorPosition, y1);
		}
		g.setColor(Color.black);
		g.setFont(font);
		g.drawString(value, x+5, y+33);
	}

	public boolean mousePressed(int inX, int inY) {
		isActive = false;
		if (inX > x && inX < x1) {
			if (inY > y && inY < y1) {
				isActive = true;
			}
		}
		return isActive;
	}
	
	public void deactivate(){
		isActive = false;
	}
}
