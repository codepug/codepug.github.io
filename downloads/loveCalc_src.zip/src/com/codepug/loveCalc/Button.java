package com.codepug.loveCalc;

import java.awt.Graphics;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class Button extends AbstractScreenControl {
	private int x, y, x1, y1;
	private MyPanel callback;

	public Button(MyPanel callback, int x, int y, int x1, int y1) {
		this.x = x;
		this.y = y;
		this.x1 = x1;
		this.y1 = y1;
		this.callback = callback;
	}

	public void paint(Graphics g) {
		// Do nothing
	}

	public boolean mousePressed(int inX, int inY) {
		isActive = false;
		if (inX > x && inX < x1) {
			if (inY > y && inY < y1) {
				callback.callback();
				return true;
			}
		}
		return isActive;
	}
	
	public void deactivate(){
		// Do nothing
	}
}
