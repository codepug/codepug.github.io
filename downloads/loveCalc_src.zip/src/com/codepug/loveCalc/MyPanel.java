package com.codepug.loveCalc;

import java.applet.Applet;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import com.codepug.loveCalc.ui.NoFlickerPanel;

/**
 * <applet codebase="." code="Game" width="272" height="480"> Java enabled browser required.</applet>
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class MyPanel extends NoFlickerPanel {

	private static final long serialVersionUID = -8674931340846441392L;
	private List<ScreenControl> controls = new ArrayList<ScreenControl>();
	private Image backgroundImg;
	private Image keyboardImg;
	private Image scoreImg;
	private Keyboard keyboard;
	private Button btn1;
	private TextField tf1;
	private TextField tf2;
	private ScoreControl sc1;

	/**
	 * @param width
	 * @param height
	 */
	public MyPanel(Applet parent) {
		super(parent.getSize().width, parent.getSize().height);
		backgroundImg = parent.getImage(parent.getCodeBase(), "background.png");
		keyboardImg = parent.getImage(parent.getCodeBase(), "keyboard.png");
		scoreImg = parent.getImage(parent.getCodeBase(), "score.png");
		tf1 = new TextField(261, 92, 443, 134);
		tf2 = new TextField(261, 174, 441, 217);
		btn1 = new Button(this, 194, 230, 434, 252);
		sc1 = new ScoreControl(scoreImg);
		controls.add(tf1);
		controls.add(tf2);
		controls.add(sc1);
		keyboard = new Keyboard(keyboardImg);
	}

	public void paint(Graphics g) {
		g.drawImage(backgroundImg, 0, 0, this);
		for (ScreenControl control : controls) {
			control.paint(g);
		}
		keyboard.paint(g);
	}

	public void mousePressed(MouseEvent e) {
		int inX = e.getX();
		int inY = e.getY();
		sc1.deactivate();
		if (!keyboard.isActive()) {
			for (ScreenControl control : controls) {
				if (control.mousePressed(inX, inY)) {
					keyboard.activate(control);
				}
			}
			btn1.mousePressed(inX, inY);
		}
		keyboard.mousePressed(inX, inY);
	}

	@Override
	public void keyPressed(KeyEvent event) {
		sc1.deactivate();
		if (keyboard.isActive) {
			keyboard.keyPressed(event.getKeyChar());
		} else {
			if (tf1.isActive()) {
				tf1.isActive = false;
				tf2.isActive = true;
				keyboard.activate(tf2);
			} else {
				tf2.isActive = false;
				tf1.isActive = true;
				keyboard.activate(tf1);
			}
		}
	}

	public void callback() {
		sc1.activate(tf1.value, tf2.value);
	}
}
