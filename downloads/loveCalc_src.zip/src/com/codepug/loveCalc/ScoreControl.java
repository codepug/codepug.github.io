package com.codepug.loveCalc;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class ScoreControl extends AbstractScreenControl {
	private Image image;

	public ScoreControl(Image image) {
		isActive = false;
		font = new Font("Arial", Font.PLAIN, 32);
		this.image = image;
		value = "";
	}

	public void paint(Graphics g) {
		if (isActive) {
			g.setColor(Color.black);
			g.setFont(font);
			g.drawImage(image, 6, 160, null);
			g.drawString("Score:", 44, 200);
			g.drawString(value + "%", 64, 230);
		}
	}

	public boolean mousePressed(int inX, int inY) {
		return false;
	}

	public void deactivate() {
		isActive = false;
	}

	public void activate(String name1, String name2) {
		isActive = true;
		value = "";
		calculateMatch(name1, name2);
	}

	public void calculateMatch(String name1, String name2) {
		int score = calculateName(name1);
		score += calculateName(name2);
		if (name1.trim().length() == 0 || name2.trim().length() == 0){
			deactivate();
		}
		value = ""+score%100;
		
		requiredAdjustments(name1, name2);
	}

	private void requiredAdjustments(String name1, String name2) {
		if (name1.startsWith("NIC") && name2.startsWith("CEC")){
			value="100";
		}
		if (name1.startsWith("CEC") && name2.startsWith("NIC")){
			value="100";
		}
	}

	private int calculateName(String name) {
		int score = 0;
		name = name.toUpperCase();
		for (int i = 0; i < name.length(); i++) {
			switch (name.charAt(i)) {
			case 'L':
				score += 10;
				break;
			case 'O':
				if (i != 0 && name.charAt(i - 1) == 'e')
					score += 1;
				score += 31;
				break;
			case 'V':
				score += 33;
				break;
			case 'E':
				score += 13;
				break;
			case 'S':
				score += 1;
				break;
			}
		}
		return score;
	}
}
