package com.codepug.loveCalc;

import java.awt.Graphics;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public interface ScreenControl {
	public boolean mousePressed(int inX, int inY);

	public void paint(Graphics g);
	
	public void setValue(String value);
	
	public boolean isActive();

	public void setValueOn(ScreenControl control);
	
	public void deactivate();
	
	public void activate();
}
