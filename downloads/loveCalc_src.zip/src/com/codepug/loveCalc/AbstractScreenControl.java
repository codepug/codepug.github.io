package com.codepug.loveCalc;

import java.awt.Font;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public abstract class AbstractScreenControl implements ScreenControl {

	protected String value;
	protected boolean isActive;
	protected Font font;
	
	@Override
	public void setValue(String value) {
		this.value = value;
	}
	
	@Override
	public void setValueOn(ScreenControl control) {
		control.setValue(value);
	}
	
	@Override
	public void activate(){
		isActive = true;
	}

	@Override
	public boolean isActive() {
		return isActive;
	}
}
