package com.codepug.loveCalc;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class Keyboard extends AbstractScreenControl {
	private Image keyboard;
	private int top;
	private int speed = 5;
	private int cursorPosition;
	private ScreenControl controlFocus;

	public Keyboard(Image keyboard) {
		this.keyboard = keyboard;
		top = 272;
		isActive = false;
		value = "";
		cursorPosition = 36;
		font = new Font("Arial", Font.PLAIN, 32);
	}

	public void paint(Graphics g) {
		if (isActive) {
			g.setColor(Color.black);
			g.setFont(font);
			if (top > 0) {
				top -= speed;
			} else {
				g.drawLine(cursorPosition, 66, cursorPosition, 97);
			}
			g.drawImage(keyboard, 0, top, null);
			g.drawString(value, 36, top + 96);
		} else {
			if (top < 272) {
				top += speed;
				g.drawImage(keyboard, 0, top, null);
			}
		}
	}

	public boolean mousePressed(int inX, int inY) {
		if (isActive && top <= 0) {
			String key = KeyboardKey.getKeyAt(inX, inY);
			if (!key.startsWith("\\")){
				value += key;
			}
			// Enter
			if ("\\n".equals(key)) {
					deactivate();
			}
			// Delete
			if ("\\d".equals(key)){
					deleteLastCharacter();
			}
		}
		return isActive;
	}

	public void deactivate() {
		isActive = false;
		controlFocus.setValue(value);
	}

	private void deleteLastCharacter() {
		int len = value.length();
		if (len > 0){
			value = value.substring(0,len-1);
		}
	}

	public void activate(ScreenControl control) {
		controlFocus = control;
		isActive = true;
		control.setValueOn(this);
	}

	public void keyPressed(char keyChar) {
		if (Character.isLetter(keyChar)){
			value+= Character.toUpperCase(keyChar);
		} else if (keyChar == 8){
			deleteLastCharacter();
		} else if (keyChar == 10){
			deactivate();
		}
		
		System.err.println((int)keyChar);
	}
}
