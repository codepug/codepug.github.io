package com.codepug.loveCalc.ui;

import java.applet.Applet;

import com.codepug.loveCalc.MyPanel;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2010
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class MyApplet extends Applet {

	private static final long serialVersionUID = -3321311141075373690L;

	public void init() {
		add(new MyPanel(this));
	}
}
