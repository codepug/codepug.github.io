package com.codepug.loveCalc.ui;

import java.awt.Panel;
import java.awt.event.*;
import java.awt.*;
import java.util.Collections;

/**
 * Job: Provides a threaded, mouseListener, keyboardListener and double buffered
 * panel
 * 
 * @author www.CodePug.com 
 * All Code copyright CodePug C. 2010 
 * Any use of this code must include a reference to www.CodePug.com authorship
 */
public class NoFlickerPanel extends Panel implements Runnable, MouseListener,
		KeyListener {

	private static final long serialVersionUID = -1807801542350179184L;
	
	// Global Variables for Double buffering
	private Image offscreenImg;
	private Graphics h;
	private int width, height;

	// Global Variables for Thread & Timing
	static int fps = 10;
	protected boolean threadRun = true;
	protected Thread runner;

	public NoFlickerPanel(int width, int height) {
		this.width = width;
		this.height = height;
		init();
	}

	@SuppressWarnings("unchecked")
	public void init() {
		Frame frame = new Frame();
		frame.addNotify();
		offscreenImg = frame.createImage(width, height);
		h = offscreenImg.getGraphics();

		this.addMouseListener(this);
		this.addKeyListener(this);
		this.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,
				Collections.EMPTY_SET);
		start();
	}

	// Handle double buffering of screen
	public void update(Graphics g) {
		h.setColor(getBackground());
		h.fillRect(0, 0, width, height);
		paint(h);
		g.drawImage(offscreenImg, 0, 0, this);
	}

	// Methods to handle thread loop
	public void run() {
		while (threadRun)
			try {
				repaint();
				Thread.sleep(fps);
			} catch (InterruptedException e) {
				// Do nothing
			}
	}

	public void start() {
		if (runner == null) {
			runner = new Thread(this);
			runner.start();
			threadRun = true;
		}
	}

	public synchronized void stop() {
		if (runner != null) {
			threadRun = false;
			runner = null;
		}
	}

	// Methods to set the panel size within the container
	@Override
	public Dimension getPreferredSize() {
		return new Dimension(width, height);
	}

	@Override
	public Dimension getMaximumSize() {
		return getPreferredSize();
	}

	@Override
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	// Methods to handle mouse input events
	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("X: " + e.getX() + " Y: " + e.getY());
		repaint();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// Do nothing
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// Do nothing
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// Do nothing
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// Do nothing
	}
	
	// Methods to handle keyboard input events
	@Override
	public void keyPressed(KeyEvent arg0) {
		// Do nothing
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// Do nothing
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// Do nothing
	}
}
