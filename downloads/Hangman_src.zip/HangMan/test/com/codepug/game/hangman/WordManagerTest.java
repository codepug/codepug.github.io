package com.codepug.game.hangman;

import junit.framework.TestCase;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2009
 */
public class WordManagerTest extends TestCase {

	
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testGetNumberOfGuesses() {
		WordManager wm = new WordManager("UNITED STATES");
		assertEquals(0,wm.getIncorrectGuessCount());
		wm.updateWordUsingGuess('Z');
		assertEquals("______ ______",wm.displayAbleWord());
		assertEquals(1,wm.getIncorrectGuessCount());
		wm.updateWordUsingGuess('Z');
		assertEquals("______ ______",wm.displayAbleWord());
		assertEquals(1,wm.getIncorrectGuessCount());
		wm.updateWordUsingGuess('Y');
		assertEquals("______ ______",wm.displayAbleWord());
		assertEquals(2,wm.getIncorrectGuessCount());
	}

	public void testGetWordUsingGuess() {
		WordManager wm = new WordManager("United States");
		assertEquals("______ ______",wm.displayAbleWord());
		wm.updateWordUsingGuess('U');
		assertEquals("U_____ ______",wm.displayAbleWord());
		wm.updateWordUsingGuess('T');
		assertEquals("U__T__ _T_T__",wm.displayAbleWord());
		wm.updateWordUsingGuess('n');
		assertEquals("UN_T__ _T_T__",wm.displayAbleWord());
	}

}
