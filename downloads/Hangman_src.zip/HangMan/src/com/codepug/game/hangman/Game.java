package com.codepug.game.hangman;

import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;

/**
 * <applet codebase="." code="Game" width="272" height="480"> Java enabled
 * browser required. </applet>
 * 
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2009
 */
public class Game extends Applet {

	private static Font font = new Font("TimesRoman", Font.BOLD, 30);
	// private String words[]=new
	// String[]{"China","India","United States","Indonesia","Brazil","Pakistan","Bangladesh","Nigeria",
	// "Russia","Japan","Mexico","Phillipines","Vietnam","Germany","Ethiopia","Egypt","Iran",
	// "Turkey","France","Thailand","United Kingdon","Italy","Myanmar","South Africa",
	// "South Korea","Ukraine","Spain","Colombia","Tanzania"};
	private String words[] = new String[] { "China", "India", "United States",
			"Brazil", "Nigeria", "Russia", "Japan", "Mexico", "Vietnam",
			"Germany", "Ethiopia", "Egypt", "Iran", "Turkey", "France",
			"United Kingdon", "Italy", "Myanmar", "South Africa",
			"South Korea", "Ukraine", "Spain" };
	private Image backgroundImg;
	private Image blankLetterImg;
	private Image coverImg;
	private Image youWinImg;
	private Image youLoseImg;
	private Image sadFaceImg;
	private AudioClip clickSnd;
	// Double buffering Global Variables
	private Image offscreenImg;
	private Graphics h;
	private WordManager wm;

	
	@Override
	public void init() {
		super.init();

		// Setup double-buffering variables
		offscreenImg = createImage(this.size().width, this.size().height);
		h = offscreenImg.getGraphics();

		loadMyMedia();
		reset();
	}

	public void reset() {
		String word = words[(int) Math
				.round(Math.random() * (words.length - 1))];
		wm = new WordManager(word);
	}

	public void loadMyMedia() {
		Graphics g = getGraphics();
		g.drawString("Loading...", 100, 100);

		MediaTracker tracker = new MediaTracker(this);
		backgroundImg = getImage(getCodeBase(), "/content/hangMan.png");
		blankLetterImg = getImage(getCodeBase(), "/content/blankLetter.png");
		coverImg = getImage(getCodeBase(), "/content/coverImg.png");
		youWinImg = getImage(getCodeBase(), "/content/youWin.png");
		youLoseImg = getImage(getCodeBase(), "/content/youLose.png");
		sadFaceImg = getImage(getCodeBase(), "/content/sadFace.png");
		clickSnd = getAudioClip(getCodeBase(), "/content/click.au");

		tracker.addImage(backgroundImg, 96);
		tracker.addImage(blankLetterImg, 97);
		tracker.addImage(coverImg, 98);
		tracker.addImage(youWinImg, 99);
		tracker.addImage(youLoseImg, 100);
		tracker.addImage(sadFaceImg, 101);

		// Load images
		try {
			for (int i = 96; i <= 101; i++)
				tracker.waitForID(i);
		} catch (InterruptedException e) {
		}
	}

	public void paint(Graphics g) {
		// Draw background
		g.drawImage(backgroundImg, 0, 0, this);
		drawCover(g, wm.getIncorrectGuessCount());

		// Draw String
		g.setFont(font);
		drawStringWithSpaces(g, wm.displayAbleWord(), 25, 253);
		drawGuessed(g);
		if (wm.getIncorrectGuessCount() >= 6) {
			g.drawImage(youLoseImg, 61, 102, this);
			g.drawImage(sadFaceImg, 198, 74, this);
		}
		if (wm.isWordCompleted()) {
			g.drawImage(youWinImg, 61, 102, this);
		}
	}

	private void drawCover(Graphics g, int numberOfGuesses) {
		switch (6 - numberOfGuesses) {
		case 6:
			// head
			g.drawImage(coverImg, 192, 67, this);
		case 5:
			// body
			g.drawImage(coverImg, 193, 93, this);
			g.drawImage(coverImg, 193, 103, this);
		case 4:
			// right arm
			g.drawImage(coverImg, 208, 106, this);

		case 3:
			// left arm
			g.drawImage(coverImg, 164, 106, this);

		case 2:
			// right leg
			g.drawImage(coverImg, 208, 146, this);

		case 1:
			// left leg
			g.drawImage(coverImg, 164, 146, this);
		default:
		}

	}

	public void drawGuessed(Graphics g) {
		for (char i = 'A'; i < 'A' + 26; i++) {
			if (wm.isLetterGuessed(i)) {
				// result = (char)('A'+((y-325)/38)*7+(x/39));
				int index = i - 'A';
				int x = (index % 7) * 39;
				int y = (index / 7) * 39 + 325;
				System.err.println("Guessed" + i + " X:" + x + " Y:" + y);
				g.drawImage(blankLetterImg, x, y, this);
			}
		}
	}

	public void drawStringWithSpaces(Graphics g, String s, int x, int y) {
		FontMetrics fm = g.getFontMetrics();
		String c = "";
		for (int i = 0; i < s.length(); i++) {
			c = "" + s.charAt(i);
			if (c.equals(" ")) {
				x = 25;
				y += fm.getHeight();
				c = "" + s.charAt(++i);
			}
			int width = fm.stringWidth(c);
			g.drawString(c, x + (20 / 2) - (width / 2), y);
			x += 30;
		}
	}

	// Call paint and send buffer to screen
	public void update(Graphics g) {
		paint(h);
		g.drawImage(offscreenImg, 0, 0, this);
	}

	public boolean mouseDown(Event evt, int x, int y) {
		System.err.println("X:" + x + " Y: " + y);
		char c = getPressedCharacter(x, y);
		System.err.println("Pressed: " + c);
		if (wm.getIncorrectGuessCount() < 6 && !wm.isWordCompleted()
				&& c != '?') {
			clickSnd.play();
			wm.updateWordUsingGuess(c);
		}
		repaint();
		return true;
	}

	public boolean keyDown(Event evt, int key) {
		System.err.println((char) key);
		char c = (char) Character.toUpperCase(key);
		if (c >= 'A' && c <= 'Z') {
			if (wm.getIncorrectGuessCount() < 6 && !wm.isWordCompleted()
					&& c != '?') {
				clickSnd.play();
				wm.updateWordUsingGuess(c);
				repaint();
			}
		}
		return true;
	}

	public char getPressedCharacter(int x, int y) {
		char result = '?';
		if (x > 0 && x < 272) {
			if (y > 325 && y < 480) {
				result = (char) ('A' + ((y - 325) / 38) * 7 + (x / 39));
				if (result == 'Z' + 1 || result == 'Z' + 2) {
					// result = '?';
					// System.exit(0);
					result = '?';
					reset();
				}
			}
		}
		return result;
	}
}
