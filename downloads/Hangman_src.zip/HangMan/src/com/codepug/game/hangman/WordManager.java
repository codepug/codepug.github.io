package com.codepug.game.hangman;

/**
 * @author www.CodePug.com
 * All Code copyright CodePug C. 2009
 */
public class WordManager {

	private static final String START_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private String currentWord;
	private String displayAbleWord;
	private String remainingLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private int incorrectGuessCount;

	public WordManager(String currentWord) {
		this.currentWord = currentWord.toUpperCase();
		remainingLetters = START_LETTERS;
		updateWordUsingGuess('~');
		incorrectGuessCount = 0;
	}

	public int getIncorrectGuessCount() {
		// return START_LETTERS.length() - remainingLetters.length();
		return incorrectGuessCount;
	}

	public boolean isLetterGuessed(char c) {
		return remainingLetters.indexOf(c) < 0;
	}

	public void updateWordUsingGuess(char c) {
		c = Character.toUpperCase(c);
		String s = "";
		boolean removed = false;
		if (remainingLetters.indexOf(c) > -1) {
			remainingLetters = remainingLetters.replaceAll("" + c, "");
			removed = true;
		}
		for (int i = 0; i < currentWord.length(); i++) {
			if (remainingLetters.indexOf(currentWord.charAt(i)) > -1) {
				s += "_";
			} else {
				s += currentWord.charAt(i);
			}
		}
		displayAbleWord = s;

		// Update misses
		if (currentWord.indexOf(c) < 0 && removed) {
			incorrectGuessCount++;
		}
	}

	public boolean isWordCompleted() {
		return displayAbleWord.indexOf("_") < 0;
	}

	public String displayAbleWord() {
		return displayAbleWord;
	}
}
