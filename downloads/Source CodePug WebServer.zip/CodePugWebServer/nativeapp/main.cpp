﻿/*  ______   ______   ______   ______   ______   __  __   _______    
 * /_____/\ /_____/\ /_____/\ /_____/\ /_____/\ /_/\/_/\ /______/\   
 * \   __\/ \   _ \ \\   _ \ \\    _\/_\   _ \ \\ \ \ \ \\   __\/__ 
 *  \ \ \  __\ \ \ \ \\ \ \ \ \\ \/___/\\ (_) \ \\ \ \ \ \\ \ /____/\
 *   \ \ \/_/\\ \ \ \ \\ \ \ \ \\  ___\/_\  ___\/ \ \ \ \ \\ \\_  _\/
 *    \ \_\ \ \\ \_\ \ \\ \/  | |\ \____/\\ \ \    \ \_\ \ \\ \_\ \ \
 *     \_____\/ \_____\/ \____/_/ \_____\/ \_\/     \_____\/ \_____\/
 *  
 * main.cpp
 * Copyright (c) 2010 CodePug
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 * 
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO
 * EVENT SHALL CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include <assert.h>
#include <compclient.h>
#include <float.h>
#include <math.h>
#include <stdio.h>
#include <windows.h>
#include <zdkinput.h>
#include <zdkgl.h>
#include <zdksystem.h>
#include <zdknet.h>
#include <zam.h>
#include <znet.h>
#include <wininet.h>
#include <winsock2.h>
#include "xutility.h"
#include "httpd.h"
int main(int argc, char *argv[])
{

	ZDK_INPUT_STATE input;
	SuppressReboot();
	ZDKSystem_ShowSplashScreen(false);

	alert(getIpAddress());
	openPort(80);
	while (true)
	{
		// Tap on the screen to exit
		ZDKInput_GetState(&input);
		if (input.TouchState.Count > 0)
			break;
	}
	return 0;
}