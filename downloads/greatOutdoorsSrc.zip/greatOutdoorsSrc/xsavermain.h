/*<---------------------------------------------------------------------->*/
// Hamster Fight, vers. 2.0a
// Author: CodePug (www.codepug.com)
// Last updated: 2/19/2003
// Compiler: Win32 LCC
// Java-like skeleton header file for double buffered screensaver app
/*<---------------------------------------------------------------------->*/

#ifndef _XSAVERMAIN_H				// If we haven't included this file
#define _XSAVERMAIN_H				// Set a flag saying we included it

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include "screenres.h"
#include "xgraphics.h"
#include "xres.h"
/*<----------------------Default Settings ------------------------------------->*/
BOOL 			noStretch        = TRUE,
				BLANKBACKGROUND  = TRUE,
				DEBUGAPP         = FALSE;
int             GAMESPEED        = 100,
				DEFAULTRESWIDTH  = 640,
				DEFAULTRESHEIGHT = 480;

HINSTANCE       hInst;			// Instance handle
HWND            hwndMain;		// Main window

HDC             h,
				g,
				temp,
				h2;
RECT            screenSize;

HANDLE myMutex;
HBRUSH hb;
POINT pt,
      p;

// Function prototypes
void            init();
void            deinit();
void            paint();
void            GameLoop();
void 			shutdown();
//////////// Method Prototypes ////////////////
//
HDC             getGraphics(HWND myHwnd);
BOOL            setScreenSize(int width, int height);
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam);

/*<---------------------------------------------------------------------->*/
static BOOL     InitApplication(void){
   WNDCLASS        wc;

   memset(&wc, 0, sizeof(WNDCLASS));
   wc.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
   wc.lpfnWndProc = (WNDPROC) MainWndProc;
   wc.hInstance = hInst;
   wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
   wc.lpszClassName = "hamster1WndClass";
   //wc.lpszMenuName = MAKEINTRESOURCE(IDMAINMENU);
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(IDAPPLICON));
   if (!RegisterClass(&wc))
	  return 0;
   return 1;
}

/*<---------------------------------------------------------------------->*/
HWND            Createhamster1WndClassWnd(void){
   return CreateWindow("hamster1WndClass",
					   "Hamster Fight v1 by Nicholas Exner",
					   //WS_MINIMIZEBOX | WS_CLIPSIBLINGS |
					   //WS_CLIPCHILDREN | WS_MAXIMIZEBOX | WS_CAPTION |
					   //WS_BORDER | WS_SYSMENU | WS_THICKFRAME,
					   WS_POPUP,
					   100, 100, DEFAULTRESWIDTH,
					   DEFAULTRESHEIGHT, NULL, NULL, hInst, NULL);
}

/*<---------------------------------------------------------------------->*/
// Add menu commands here
void            MainWndProc_OnCommand(HWND hwnd, int id, HWND hwndCtl,
									  UINT codeNotify){
   switch (id)  {
   	case IDM_OPEN:
		// Not in template
CreateDialog(hInst,MAKEINTRESOURCE(DLG_0400),hwnd,MainWndProc);


		break;

	case IDM_ABOUT:
		MessageBox(hwnd,"Created by Nicholas Exner, C.2002-2003","About Hamster Fight",MB_OK);
		break;
   case IDM_EXIT:
	  PostMessage(hwnd, WM_CLOSE, 0, 0);
	  break;
   }
}

/*<---------------------------------------------------------------------->*/
LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam,
							 LPARAM lParam) {
   switch (msg) {
		case WM_KEYUP:
   		case WM_LBUTTONDOWN:
		case WM_DESTROY:
	   		shutdown();
	   		break;

		case WM_COMMAND:
	  		HANDLE_WM_COMMAND(hwnd, wParam, lParam, MainWndProc_OnCommand);
	  		break;

   		default:
	  		return DefWindowProc(hwnd, msg, wParam, lParam);
   }

   return 0;
}

/*<---------------------------------------------------------------------->*/
int WINAPI      WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
						LPSTR lpCmdLine, INT nCmdShow){
   MSG             msg;
   HANDLE          hAccelTable;

	// Check to make sure that only one screensaver is running
	myMutex = CreateMutex(NULL,FALSE,"SCREENSAVER");
	if  ( GetLastError() == ERROR_ALREADY_EXISTS ) {
		PostQuitMessage(0);
		return msg.wParam;
	}

	// Deactivate system screensaver respawn
	SystemParametersInfo(SPI_SETSCREENSAVEACTIVE,TRUE,NULL,0);

   hInst = hInstance;
   if (!InitApplication())
	  return 0;
   hAccelTable = LoadAccelerators(hInst, MAKEINTRESOURCE(IDACCEL));
   if ((hwndMain = Createhamster1WndClassWnd()) == (HWND) 0)
	  return 0;

	  // Parse lpCmdLine here
	while(*lpCmdLine != '\0' && *lpCmdLine != '-' && *lpCmdLine != '/')
		lpCmdLine++;

	if(*lpCmdLine == '\0'){
		return 0;// DialogBox(hInstance, "ConfigDialog", NULL, DialogProc);
	}else	{
		lpCmdLine++;
		switch(*lpCmdLine){
			case 'c':
			case 'C':
//if (CreateDialog(hInst,MAKEINTRESOURCE(DLG_0400),hwndMain,MainWndProc) == NULL)
				MessageBox(hwndMain,"No settings to configure.","Settings...",MB_OK);
				return 0;
				break;
			case 's':
			case 'S':
				break;
			case 'a':
			case 'A':
				MessageBox(hwndMain, "This screensaver doesn't support passwords", "Error", MB_OK | MB_ICONERROR);
				return 0;

			default:
				return 0;
		}
	}


	  if (noStretch)
		  setResolutionSize(DEFAULTRESWIDTH, DEFAULTRESHEIGHT);

   	// Get's the size of the screen
	SystemParametersInfo(SPI_GETWORKAREA,0,&screenSize,0);
	SetWindowPos(hwndMain,HWND_TOPMOST,0,0,screenSize.right,screenSize.bottom,SWP_SHOWWINDOW);


   	// Load double buffering graphics contexts for g, temp, and h
  	getGraphics(hwndMain);
   	hb = GetStockObject(BLACK_BRUSH);

   	// Call init method to load starting data
   	init();

   	ShowWindow(hwndMain, SW_SHOW);
   	GetCursorPos(&p);
	ShowCursor(FALSE);

   	// Begin loop
   	GameLoop();

   	return msg.wParam;
}

// Repeating action of game code here
void            GameLoop() {
   MSG             msg;
   PeekMessage(&msg, NULL, 0U, 0U, PM_NOREMOVE);

   while (msg.message != WM_QUIT) {
	  if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE)) {
		 // Process message
		 TranslateMessage(&msg);
		 DispatchMessage(&msg);
	  } else if (RenderNextFrame((int) GAMESPEED)) {
		 // Calculate the fps of our app
		 CalculateFrameRate((HWND) hwndMain);

		 	// Clear buffer
			if (BLANKBACKGROUND){
				SelectObject(h,hb);
				Rectangle(h,0,0,screenSize.right,screenSize.bottom);
			}

		 	paint();

		if (DEBUGAPP){
			drawString("DEMO VERSION", 10, 10, h);
		}
		// Check for mouse movements
		GetCursorPos(&pt);
		if (pt.x -p.x > 5 || pt.x-p.x < -5)
			shutdown();

		if (!noStretch){
			StretchBlt(h2,0,0,screenSize.right,screenSize.bottom,h,0,0,640,480,SRCCOPY);

		 	// Update screen from offscreenImg
		 	BitBlt(g,0,0,screenSize.right,screenSize.bottom,h2,0,0,SRCCOPY);
		} else {
			BitBlt(g,0,0,screenSize.right,screenSize.bottom,h,0,0,SRCCOPY);
		}
	  } // end RenderNextFrame
   }	// end while
} // end GameLoop

HDC             getGraphics(HWND myHwnd){
   // Global dependencies
   // RECT screenSize;
   // HDC g, h, temp; // (screen, offscreen, & temp graphics)
   HBITMAP         hBitmap,hBitmap2;

   // Get window size
   GetClientRect(myHwnd, &screenSize);

   g = GetDC(myHwnd);
   h = CreateCompatibleDC(g);
   h2 = CreateCompatibleDC(g);
//   hStretch = CreateCompatibleDC(g);
   temp = CreateCompatibleDC(g);

   	// Standardize pixel PLAYERs for both screens
   	SetMapMode(h, GetMapMode(g));
    SetMapMode(h2, GetMapMode(g));
   	SetMapMode(temp, GetMapMode(g));

   	// Create DIB Sections for offscreenGraphics & paint to offscreen Graphics
   	hBitmap = CreateCompatibleBitmap(g, screenSize.right, screenSize.bottom);
	hBitmap2 = CreateCompatibleBitmap(g, screenSize.right, screenSize.bottom);

   	SelectObject(h, hBitmap);
	SelectObject(h2, hBitmap2);

   // Cleanup
   DeleteObject(hBitmap);

   // Return offscreenGraphics h
   return h;
}

BOOL            setScreenSize(int width, int height) {
   screenSize.left = 0;
   screenSize.right = width;
   screenSize.top = 0;
   screenSize.bottom = height;
   SetWindowPos(hwndMain, HWND_TOPMOST, 0, 0, screenSize.right,
				screenSize.bottom, SWP_SHOWWINDOW);
   return TRUE;
}

void shutdown(){
	if (noStretch)
		resetResolution();

	// Reactivate screensaver
	SystemParametersInfo(SPI_SETSCREENSAVEACTIVE,TRUE,NULL,0);

	deinit();
	ReleaseDC(hwndMain,g);
	DeleteDC(h);
	DeleteDC(temp);
	PostQuitMessage(0);
}
#endif
