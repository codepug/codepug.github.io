/*<---------------------------------------------------------------------->*/
// XRES.h, vers. 1.0a
// Author: codePug (www.codepug.com)
// Last updated: 2/22/2003
// Compiler: Win32 LCC
// Include this header to adjust the screen resolution
/*<---------------------------------------------------------------------->*/

#ifndef _XRES_H				// If we haven't included this file
#define _XRES_H				// Set a flag saying we included it

#include <winuser.h>
void setResolutionSize(int width, int height);
void resetResolution();

void resetResolution(){
	ChangeDisplaySettings(0,0);
//	ChangeToFullScreen(1024,768);
}

void setResolutionSize(int width, int height){
	DEVMODE dmSettings;									// Device Mode

	memset(&dmSettings,0,sizeof(dmSettings));			// Makes Sure Memory's Cleared

	// Get current settings --
	if(!EnumDisplaySettings(NULL,ENUM_CURRENT_SETTINGS,&dmSettings))
	{
		MessageBox(NULL, "Could Not Enum Display Settings", "Error", MB_OK);
		return;
	}

	dmSettings.dmPelsWidth	= width;				// Selected Screen Width
	dmSettings.dmPelsHeight	= height;			// Selected Screen Height

	// CDS_FULLSCREEN Gets Rid Of Start Bar.
	int result = ChangeDisplaySettings(&dmSettings,CDS_FULLSCREEN);

	if(result != DISP_CHANGE_SUCCESSFUL)
	{
		MessageBox(NULL, "Display Mode Not Compatible", "Error", MB_OK);
		PostQuitMessage(0);
	}
}





// Function prototypes
//void initr();
//void deinitr();
//void ChangeRes(int width, int height, int depth);
//void RestoreResolution();
//void ListResolutions();
/*
//private:
//	DEVMODE m_Current;
//	std::list<DEVMODE> m_stdDeviceModes;
//DEVMODE m_stdDeviceModes;
void ChangeRes(int width, int height, int depth){
	DEVMODE dm;

	memset(dm,0,sizeof(dm));
	dm.dmSize = sizeof(dm);
	dm.dmBitsPerPel	Bits per pixel
	dm.dmPelsWidth	Pixel width
	dm.dmPelsHeight	Pixel height
	dm.dmDisplayFlags	Mode flags
	dm.dmDisplayFrequency

	ChangeDisplaySettings(&(*dm), 0);

}

void initr(){
	int  nModeExist;
	DEVMODE devMode;

	devMode.dmSize = sizeof(DEVMODE);

	// Get the current list of Available DevModes and store them into
	for (int i=0; ;i++){
		nModeExist = EnumDisplaySettings(NULL, i, &devMode);

		if (nModeExist != 1) {
			// End of modes.  bail out.
			break;
		} else {
			// Add the driver to the list.
			//m_stdDeviceModes.push_front(devMode);
		}
	}
}


void deinitr(){
 // clean out the list of DeviceModes
    //if (m_stdDeviceModes.size() > 0) {
	//m_stdDeviceModes.erase(m_stdDeviceModes.begin(), m_stdDeviceModes.end());
    //}
}




*/
#endif
