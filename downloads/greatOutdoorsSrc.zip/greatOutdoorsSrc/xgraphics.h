// Author:   CodePug (www.codepug.com)
// Purpose:  Advanced graphics routines
// Filename: xgraphics.h
// Compiler: Win32 Lcc
// Note: If you use this code, you must show credit to the original
//       author, Nicholas Exner.  Any exceptions to this
//	     will be considered illegal.
//
// Last updated: March 3 2003

#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include <mmsystem.h>
#include "stdio.h"

#ifndef _XGRAPHICS_H				// If we haven't included this file
#define _XGRAPHICS_H				// Set a flag saying we included it

///////////// Global Variables /////////////////
//
HFONT hFont;

//////////// Method Prototypes ////////////////
//
// Graphics timing methods
void CalculateFrameRate(HWND hWnd);
BOOL RenderNextFrame(int desiredFrameRate);

// Image retrieval methods
HBITMAP LoadABitmap(LPSTR szFileName);
HBITMAP LoadAndFlipBitmap(HBITMAP myImage,HWND myHwnd);
HBITMAP CreateBitmapMask(HBITMAP hbmColour, COLORREF crTransparent);

// Text methods
void drawString(LPSTR s, int x, int y, HDC myHDC);


//////////// Method Definitions  ////////////////
//
HBITMAP LoadABitmap(LPSTR szFileName){
	// Load the bitmap and return the handle to the bitmap we just loaded
	return (HBITMAP)LoadImage(NULL, szFileName, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
}

// Method borrowed from a tutorial on an animated flame
void CalculateFrameRate(HWND hWnd){
	//	static float fFPS      = 0.0f;
	static float fLastTime = 0.0f;
	static DWORD dwFrames  = 0;
	char strFrameRate[55] = { 0	};

	// Keep track of the time lapse and frame count and convert to seconds
	float fTime = GetTickCount() * 0.001f;
	++dwFrames;

	// If our current time minus the last recorded time is great than 1 second, start over
	if( fTime - fLastTime > 1.0f){
		// Store the current time to test again
		fLastTime = fTime;

		// Store our Frames Per Second Into a buffer
		wsprintf(strFrameRate, "Frames Per Second: %d", dwFrames);

		// Display the Frames Per Second in our window title
		SetWindowText(hWnd, strFrameRate);

		// Reset the frames
		dwFrames  = 0;
	}
}

// Method borrowed from a tutorial on an animated flame
BOOL RenderNextFrame(int desiredFrameRate){
	static float lastTime = 0.0f;
	float elapsedTime = 0.0;

	// Get current time in seconds  (milliseconds * .001 = seconds)
	float currentTime = GetTickCount() * 0.001f;

	// Get the elapsed time by subtracting the current time from the last time
	elapsedTime = currentTime - lastTime;

	// Check if the time since we last checked is over (1 second / framesPerSecond)
	if( elapsedTime > (1.0f / desiredFrameRate) ){
		// Reset the last time
		lastTime = currentTime;

		// Return TRUE, to animate the next frame of animation
		return TRUE;
	}

	// We don't animate right now.
	return FALSE;
}



HBITMAP LoadAndFlipBitmap(HBITMAP myImage,HWND myHwnd){
	BITMAP bm;
	HDC myHDC,
	    myHDC2;
	HBITMAP myBitmap;

	myHDC = CreateCompatibleDC(GetDC(myHwnd));
	myHDC2 = CreateCompatibleDC(GetDC(myHwnd));

	GetObject( myImage, sizeof( bm ), &bm );

	myBitmap = CreateBitmap(bm.bmWidth, bm.bmHeight, bm.bmPlanes, bm.bmBitsPixel, NULL);

	SelectObject(myHDC2,myImage);
	SelectObject(myHDC,myBitmap);
	StretchBlt(myHDC, 0,0,bm.bmWidth,bm.bmHeight,myHDC2,bm.bmWidth-1, 0, -bm.bmWidth, bm.bmHeight, SRCCOPY );

	DeleteObject(myHDC2);
	DeleteObject(myHDC);
	return myBitmap;
}

// Method borrowed from a tutorial on transparent bitmaps
// i.e. CreateBitmapMask(myBitmap, RGB(0,0,0));
//
HBITMAP CreateBitmapMask(HBITMAP hbmColour, COLORREF crTransparent){
    HDC hdcMem,
	    hdcMem2;
    HBITMAP hbmMask;
    BITMAP bm;

    // Create monochrome (1 bit) mask bitmap.

    GetObject(hbmColour, sizeof(BITMAP), &bm);
    hbmMask = CreateBitmap(bm.bmWidth, bm.bmHeight, 1, 1, NULL);

    // Get some HDCs that are compatible with the display driver

    hdcMem = CreateCompatibleDC(0);
    hdcMem2 = CreateCompatibleDC(0);

    SelectBitmap(hdcMem, hbmColour);
    SelectBitmap(hdcMem2, hbmMask);

    // Set the background colour of the colour image to the colour
    // you want to be transparent.
    SetBkColor(hdcMem, crTransparent);

    // Copy the bits from the colour image to the B+W mask... everything
    // with the background colour ends up white while everythig else ends up
    // black...Just what we wanted.

    BitBlt(hdcMem2, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem, 0, 0, SRCCOPY);

    // Take our new mask and use it to turn the transparent colour in our
    // original colour image to black so the transparency effect will
    // work right.
    BitBlt(hdcMem, 0, 0, bm.bmWidth, bm.bmHeight, hdcMem2, 0, 0, SRCINVERT);

    // Clean up.
    DeleteDC(hdcMem);
    DeleteDC(hdcMem2);

    return hbmMask;
}

void drawString(LPSTR s, int x, int y, HDC myHDC){

	// GetTextMetrics ( hDC, &tm);
  // xchar = tm.tmMaxCharWidth;
   //ychar = tm.tmHeight;
if (hFont == NULL)
	// Create Game Font
	hFont = CreateFont ( 46, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                        ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                        DEFAULT_QUALITY, FIXED_PITCH | FF_SWISS, "ARIAL" );//HELV

//SelectObject(myHDC,GetStockObject(WHITE_BRUSH));
	SelectObject ( myHDC, hFont);
	SetBkMode(myHDC, TRANSPARENT);


	TextOut(myHDC,x,y,s,strlen(s));
}






#endif
