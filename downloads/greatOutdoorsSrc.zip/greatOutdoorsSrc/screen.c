// Author:   CodePug (www.codepug.com)
// Purpose:  Advanced graphics routines
// Filename: screen.c
// Compiler: Win32 Lcc
// Note: If you use this code, you must show credit to the original
//       author, CodePug .  Any exceptions to this
//	     will be considered illegal.
//
// Last updated: Feb 19 2003

#include "screenres.h"
#include "xsavermain.h"
#include "xgraphics.h"
#include "xdate.h"
#include "xsprite.h"

int FINALMONTH=6;
int FINALDAY  =14;  // Saturday midnight, actually 12 hours before this
int FINALYEAR =2015;
int FINALHOUR = 12;

// Global variables
HGLOBAL mysound;
int ix,
    iy;
char output[256];
SPRITE mainCharacter, background,background2, background3, backgroundSand,tree;
void switchScenes();

// Method definitions
void init(){
	char tempBitmapName[256];
	GAMESPEED = 50;
	transparentColor = RGB(254,2,254);
	mysound = LoadResource(hInst,FindResource(hInst,MAKEINTRESOURCE(IDSOUND),RT_RCDATA));
	//PlaySound(mysound,NULL,SND_MEMORY+SND_ASYNC);



	// Setup main sprite character
	wsprintf(tempBitmapName,"%d",IDBITMAP1);
	mainCharacter=createAnimatedSprite(tempBitmapName, TRUE, FALSE,1);
	setPosition(&mainCharacter,0,150);
	addSprite(&mainCharacter);
	setCourse(&mainCharacter, screenSize.right+200,150+mainCharacter.height/2, 1);

	wsprintf(tempBitmapName,"%d",IDTREE);
	tree=createSprite(tempBitmapName,TRUE,FALSE);
	setPosition(&tree,0,0);
	addSprite(&tree);

	wsprintf(tempBitmapName,"%d",IDBITMAP2);
	background = createSprite(tempBitmapName,FALSE,FALSE);
	setPosition(&background,0,0);
	setCourse(&background, -640,background.height/2, 1);
	addSprite(&background);

	background2 = createSprite(tempBitmapName,FALSE,FALSE);
	setPosition(&background2,640,0);
	setCourse(&background2, -640,background.height/2, 1);
	addSprite(&background2);

	wsprintf(tempBitmapName,"%d",IDBITMAP3);
	background3 = createSprite(tempBitmapName,FALSE,FALSE);
	setPosition(&background3,0,240);
	addSprite(&background3);

	wsprintf(tempBitmapName,"%d",671);
	backgroundSand = createSprite(tempBitmapName,FALSE,FALSE);
	setPosition(&backgroundSand,0,0);
	addSprite(&backgroundSand);
	backgroundSand.isActive=FALSE;

}

void switchScenes(){
	if (tree.isActive){
		background.isActive=FALSE;
		background2.isActive=FALSE;
		background3.isActive=FALSE;
		tree.isActive=FALSE;
		backgroundSand.isActive = TRUE;
	} else {
		backgroundSand.isActive = FALSE;
		background.isActive=TRUE;
		background2.isActive=TRUE;
		background3.isActive=TRUE;
		tree.isActive=TRUE;
	}
}
void paint(){
	POINT z;
	static int changeSceneCount=0;

	if(getPostion(&background).x == -640)
		setPosition(&background,640,0);

	if(getPostion(&background2).x == -640)
		setPosition(&background2,640,0);

	followCourse(&background);
	followCourse(&background2);

	if(!followCourse(&mainCharacter)){
		setPosition(&mainCharacter,-200,100);
		changeSceneCount++;
		if (changeSceneCount > 2){
			changeSceneCount = 0;
			switchScenes();
		}
	}

	paintSprite(h, temp);

	SetTextColor(h,RGB(255,0,0));
	wsprintf(output,"%d days, %d hours, %d minutes",daysUntil(FINALMONTH,FINALDAY-1,FINALYEAR),hoursUntil(23),minutesUntil(59));
	drawString(output,25,390,h);
	wsprintf(output,"%d Seconds, %d Milliseconds",secondsUntil(59),mSecondsUntil(999));
	drawString(output,25,425,h);

	// Reset background to black for masking operations
	SetTextColor(h,RGB(0,0,0));

}

void deinit(){
	void deleteAllSpriteObjects();
	DeleteObject(mysound);
}
