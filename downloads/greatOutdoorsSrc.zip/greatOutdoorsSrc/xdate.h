//#include <winbase.h>

BOOL isLeapYear(int year);
int zeller(int d, int m, int y);
int daysBetween(int m1, int d1, int y1,int m, int d, int y);
int calculateDayOfYear(int d, int m, int y);
int daysUntil(int m, int d, int y);
int hoursUntil(int h);
int minutesUntil(int min);
int secondsUntil(int min);
int mSecondsUntil(int min);

int daysUntil(int m, int d, int y){
	SYSTEMTIME st;
	GetLocalTime(&st);
	return daysBetween((int)st.wMonth,(int)st.wDay,(int)st.wYear,m,d,y);
	//return daysBetween(m,d,y,(int)st.wMonth,(int)st.wDay,(int)st.wYear);
}

int hoursUntil(int h){
	int hours;
	SYSTEMTIME st;
	GetLocalTime(&st);
	hours = (int)st.wHour;
	return abs(hours-h);
}

int minutesUntil(int min){
	int hours;
	SYSTEMTIME st;
	GetLocalTime(&st);
	hours = (int)st.wMinute;
	return abs(hours-min);
}

int secondsUntil(int min){
	int hours;
	SYSTEMTIME st;
	GetLocalTime(&st);
	hours = (int)st.wSecond;
	return abs(hours-min);
}

int mSecondsUntil(int min){
	int hours;
	SYSTEMTIME st;
	GetLocalTime(&st);
	hours = (int)st.wMilliseconds;
	hours = abs(hours-min);
	if (hours < 100)
		hours+=100;
	hours+=rand()%9;
	if (hours > 999)
		hours -= rand()%120;
	return hours;
}

int daysBetween(int m1, int d1, int y1, int m, int d, int y){
	int totalDaysUntil = 0;
	int dayOfYear      = 0;
	int dayOfYear1     = 0;
	int i = 0;

	// Process days in year differences & account for leap years
	for (i = y1; i > y; i--)
		if (isLeapYear(i))
			totalDaysUntil += 366;
		else
			totalDaysUntil+=365;

	// Find the position of each day in current year
	dayOfYear  = calculateDayOfYear(d,m,y);
	dayOfYear1 = calculateDayOfYear(d1,m1,y1);
	totalDaysUntil += (dayOfYear - dayOfYear1);
	if (totalDaysUntil < 0)
		return 0;
	return totalDaysUntil;
}

int calculateDayOfYear(int d, int m, int y){
	int dayNumber = 0;
	switch(m){
case 12:
	dayNumber += 31;

case 11:
	dayNumber += 30;

case 10:
	dayNumber += 31;

case 9:
	dayNumber += 30;

case 8:
	dayNumber += 31;

case 7:
	dayNumber += 31;

case 6:
	dayNumber += 30;

case 5:
	dayNumber += 31;

case 4:
	dayNumber += 30;

case 3:
	dayNumber += 31;

case 2:
	if (isLeapYear(y))
		dayNumber += 29;
	else
		dayNumber += 28;

case 1:
	dayNumber += 31;

	} // end switch
	return (dayNumber+d);
}

BOOL isLeapYear(int year){
    if(year%4==0 && (year%100 || !(year%400)))
		return TRUE;
    return FALSE;
}

int zeller(int d, int m, int y){
	int c,f;

   m-=2;                           // Subtract two from month?
   if (m<=0) {                     // Prior year?
     m+=12;                        // adjust month
     y--;                          // adjust year
   }
   c=y/100;                        // Extract century
   y%=100;                         // extract year in century

   f = ((int)(2.6*m-0.2) + d + y + (y/4) + (c/4) - 2*c)%7; // Zellers

   f+= f<0 ? 7 : 0;                // fix for negative number.
	return f;
}

void outputZeller(){
int zy = 2003;
	char c[256];

	wsprintf(c,"day num: %i",zeller(2003,2,21));
	//ShowWindow(hwndMain,SW_MINIMIZE);
	//MessageBox(NULL,c,c,MB_OK);
}
